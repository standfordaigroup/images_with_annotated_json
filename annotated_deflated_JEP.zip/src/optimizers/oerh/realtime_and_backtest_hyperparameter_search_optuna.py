"""
🎯 RULE-BASED TECHNICAL FORECASTING SYSTEM (JIT-ACCELERATED)
====================================================================================================
🔧 ENHANCED: Added "floor", "short_any", "ceiling", "any_2B", "any_2B_for_sell", "any_4B" and "any_4B_for_sell" target modes

📋 OVERVIEW
-----------
This system implements a multi-indicator, rule-based forecasting engine for financial time series.
It combines adaptive signal smoothing, momentum/reversion logic, and flexible target labeling to
generate actionable trading signals with configurable lookahead horizons.

🔧 CORE ALGORITHMS
------------------

1️⃣ ONE-EURO FILTER (Adaptive Smoothing)
   ├─ Purpose: Reduce noise while preserving rapid price movements
   ├─ Mechanism: Dynamic cutoff frequency based on signal derivative
   ├─ Parameters:
   │  • one_euro_min  : Minimum cutoff frequency (Hz) – controls baseline smoothing
   │  • one_euro_factor: Beta factor – adapts smoothing to signal volatility
   └─ Output: Smoothed price series used as dynamic support/resistance reference

2️⃣ RSI – RELATIVE STRENGTH INDEX (Wilder's Method) [✅ JIT-ACCELERATED]
   ├─ Purpose: Measure momentum and identify overbought/oversold conditions
   ├─ Two Operating Modes:
   │  • "momentum"  : Buy when RSI > overbought (trend continuation)
   │  • "reversion" : Buy when RSI < oversold (mean reversion)
   ├─ Parameters:
   │  • rsi_period    : Lookback window for RSI calculation (default: 14)
   │  • rsi_oversold  : Lower threshold for oversold signal (default: 30)
   │  • rsi_overbought: Upper threshold for overbought signal (default: 70)
   └─ Output: Oscillator [0–100] used in conjunction with trend filters

3️⃣ MACD – MOVING AVERAGE CONVERGENCE DIVERGENCE [✅ JIT-ACCELERATED]
   ├─ Purpose: Identify trend direction, strength, and potential reversals
   ├─ Components:
   │  • MACD Line     : EMA(fast) − EMA(slow)
   │  • Signal Line   : EMA of MACD Line
   │  • Histogram     : MACD − Signal (momentum accelerator)
   ├─ Parameters:
   │  • macd_fast   : Fast EMA period (default: 12)
   │  • macd_slow   : Slow EMA period (default: 26)
   │  • macd_signal : Signal line EMA period (default: 9)
   └─ Output: Trend confirmation + momentum divergence signals

4️⃣ TARGET LABELING STRATEGIES (Forecast Ground Truth)
   ├─ Purpose: Define what constitutes a "successful" prediction
   ├─ Eleven Modes:
   │  • "exact"      : Price must exceed threshold EXACTLY at t + lookahead_bars
   │  • "any"        : Price must exceed threshold ANYWHERE in [t+1, t+lookahead_bars]
   │  • "any_half_B" : Price must exceed threshold in SECOND HALF of window [t+B//2+1, t+B]
   │  • "any_half_B_for_sell" : Price must drop below threshold in SECOND HALF of window [t+B//2+1, t+B]
   │  • "floor"      : Price must NEVER fall below threshold in [t+1, t+lookahead_bars]
   │  • "short_any"  : Price must drop below threshold ANYWHERE in [t+1, t+lookahead_bars]
   │  • "ceiling"    : Price must NEVER rise above threshold in [t+1, t+lookahead_bars]
   │  • "any_2B"     : Price must exceed threshold in the LAST TWO BARS of the window [t+B-1, t+B]
   │  • "any_2B_for_sell" : Price must drop below threshold in the LAST TWO BARS of the window [t+B-1, t+B]
   │  • "any_4B"     : Price must exceed threshold in the LAST FOUR BARS of the window [t+B-3, t+B]
   │  • "any_4B_for_sell" 🆕 : Price must drop below threshold in the LAST FOUR BARS of the window [t+B-3, t+B]
   ├─ Parameters:
   │  • lookahead_bars : Forecast horizon in bars (default: 5)
   │  • threshold_pct  : Minimum price move to trigger positive label (default: 0.01 = 1%)
   └─ Output: Binary labels (1 = target met, 0 = not met) for signal evaluation

⚙️ SIGNAL GENERATION LOGIC [✅ OPTIONAL JIT]
--------------------------
A trading signal is generated when ALL of the following conditions align:

🟢 LONG SIGNAL (Signal = +1):
   ✓ Price > One-Euro Filter (uptrend confirmation)
   ✓ RSI condition (mode-dependent):
       - momentum: RSI > overbought AND rising vs. previous bar
       - reversion: RSI < oversold AND rising vs. previous bar
   ✓ MACD Histogram > 0 AND increasing vs. previous bar (bullish momentum)

🔴 SHORT SIGNAL (Signal = -1):
   ✓ Price < One-Euro Filter (downtrend confirmation)
   ✓ RSI condition (mode-dependent):
       - momentum: RSI < 50 (bearish territory) AND falling vs. previous bar (relaxed for better short signal generation)
       - reversion: RSI > overbought AND falling vs. previous bar
   ✓ MACD Histogram < 0 AND decreasing vs. previous bar (bearish momentum)

⚪ NO SIGNAL (Signal = 0): Default when conditions are not met

📊 EVALUATION METRICS
---------------------
After signal generation, the system computes:
   • Overall Accuracy     : % of signals where prediction matched actual outcome
   • Long Accuracy        : % of long signals that correctly predicted upward move
   • Short Accuracy       : % of short signals that correctly predicted downward move
   • Signal Frequency     : Total signals generated vs. total bars analyzed

====================================================================================================
"""

try:
    from version import sys__name, sys__version
except ImportError:
    # Fallback: dynamically add parent directory to path if 'version' module isn't found
    import sys
    import pathlib

    current_dir = pathlib.Path(__file__).resolve()
    parent_dir = current_dir.parent.parent.parent
    sys.path.insert(0, str(parent_dir))
    from version import sys__name, sys__version
from optuna.storages import JournalStorage
from optuna.storages.journal import JournalFileBackend
import numpy as np
import pandas as pd
from functools import lru_cache
from numba import njit, prange
import math
import copy
import matplotlib.pyplot as plt
from typing import Optional, Tuple
import pickle
import argparse
from utils import get_filename_for_dataset
from fetchers.data_factory import factory_load_data
import os
import warnings
import optuna
from sklearn.model_selection import TimeSeriesSplit
import datetime
import sys

# Suppress Optuna & pandas_ta debug logs
optuna.logging.set_verbosity(optuna.logging.WARNING)
pd.options.mode.chained_assignment = None
# ============================================
# 1. ONE-EURO FILTER (Adaptive Smoothing)
# ============================================
from algorithms.one_euro_filter import one_euro_filter
from utils import get_next_step


# ============================================
# JIT-ACCELERATED NUMERICAL CORES
# ============================================

@njit(cache=True, fastmath=True)
def _rsi_numba(values: np.ndarray, period: int) -> np.ndarray:
    """Numba-accelerated RSI using Wilder's smoothing method."""
    n = len(values)
    rsi = np.empty(n, dtype=np.float64)
    rsi[:] = np.nan

    if n < 2:
        return rsi

    # Calculate price deltas
    delta = np.empty(n, dtype=np.float64)
    delta[0] = 0.0
    for i in range(1, n):
        delta[i] = values[i] - values[i - 1]

    # Separate gains and losses
    gain = np.zeros(n, dtype=np.float64)
    loss = np.zeros(n, dtype=np.float64)

    for i in range(1, n):
        if delta[i] > 0:
            gain[i] = delta[i]
        else:
            loss[i] = -delta[i]

    # Initial average (simple mean for first period)
    if n > period:
        avg_gain = np.mean(gain[1:period + 1])
        avg_loss = np.mean(loss[1:period + 1])
    else:
        avg_gain = np.mean(gain[1:])
        avg_loss = np.mean(loss[1:])

    # Wilder's smoothing: RSI calculation
    for i in range(period, n):
        if i > period:
            avg_gain = (avg_gain * (period - 1) + gain[i]) / period
            avg_loss = (avg_loss * (period - 1) + loss[i]) / period

        if avg_loss == 0:
            rsi[i] = 100.0
        else:
            rs = avg_gain / avg_loss
            rsi[i] = 100.0 - (100.0 / (1.0 + rs))

    return rsi


@njit(cache=True, fastmath=True)
def _ema_numba(values: np.ndarray, span: int) -> np.ndarray:
    """Numba-accelerated exponential moving average (Wilder's style)."""
    n = len(values)
    result = np.empty(n, dtype=np.float64)
    result[:] = np.nan

    if n == 0:
        return result

    # Alpha for EMA: same as pandas ewm(span=span, adjust=False)
    alpha = 2.0 / (span + 1)
    result[0] = values[0]

    for i in range(1, n):
        result[i] = alpha * values[i] + (1.0 - alpha) * result[i - 1]

    return result


@njit(cache=True, fastmath=True)
def _macd_numba(close: np.ndarray, fast: int, slow: int, signal: int) -> tuple:
    """Compute MACD components - returns (macd_line, signal_line, histogram)."""
    ema_fast = _ema_numba(close, fast)
    ema_slow = _ema_numba(close, slow)
    macd_line = np.empty(len(close), dtype=np.float64)

    for i in range(len(close)):
        if np.isnan(ema_fast[i]) or np.isnan(ema_slow[i]):
            macd_line[i] = np.nan
        else:
            macd_line[i] = ema_fast[i] - ema_slow[i]

    signal_line = _ema_numba(macd_line, signal)
    histogram = np.empty(len(close), dtype=np.float64)

    for i in range(len(close)):
        if np.isnan(macd_line[i]) or np.isnan(signal_line[i]):
            histogram[i] = np.nan
        else:
            histogram[i] = macd_line[i] - signal_line[i]

    return macd_line, signal_line, histogram


@njit(cache=True, parallel=True, fastmath=True)
def _generate_candidates_numba(
        close: np.ndarray,
        one_euro: np.ndarray,
        rsi: np.ndarray,
        histogram: np.ndarray,
        rsi_oversold: float,
        rsi_overbought: float,
        rsi_mode_momentum: bool,
) -> np.ndarray:
    """Pass 1: Numba-accelerated candidate signal generation with parallel processing."""
    n = len(close)
    candidates = np.zeros(n, dtype=np.int8)

    for i in prange(1, n):
        # Skip if any required value is NaN
        if (np.isnan(rsi[i]) or np.isnan(histogram[i]) or
                np.isnan(one_euro[i]) or np.isnan(close[i])):
            continue

        # Handle previous values with fallback
        rsi_prev = rsi[i - 1] if not np.isnan(rsi[i - 1]) else rsi[i]
        hist_prev = histogram[i - 1] if not np.isnan(histogram[i - 1]) else histogram[i]

        # RSI condition based on mode
        if rsi_mode_momentum:
            long_rsi = (rsi[i] > rsi_overbought) and (rsi[i] > rsi_prev)
            short_rsi = (rsi[i] < 50.0) and (rsi[i] < rsi_prev)  # Relaxed short momentum: bearish territory and falling
        else:  # reversion mode
            long_rsi = (rsi[i] < rsi_oversold) and (rsi[i] > rsi_prev)
            short_rsi = (rsi[i] > rsi_overbought) and (rsi[i] < rsi_prev)

        # Long signal condition
        if ((close[i] > one_euro[i]) and long_rsi and
                (histogram[i] > 0) and (histogram[i] > hist_prev)):
            candidates[i] = 1
        # Short signal condition
        elif ((close[i] < one_euro[i]) and short_rsi and
              (histogram[i] < 0) and (histogram[i] < hist_prev)):
            candidates[i] = -1

    return candidates


@njit(cache=True, fastmath=True)
def _apply_cooldown(candidates: np.ndarray, cooldown: int) -> np.ndarray:
    """Pass 2: Sequential sweep to enforce minimum bars between signals."""
    n = len(candidates)
    signals = np.zeros(n, dtype=np.int8)
    if cooldown <= 0:
        for i in range(n):
            signals[i] = candidates[i]
        return signals

    last_signal_idx = -cooldown - 1
    for i in range(n):
        if candidates[i] != 0:
            if i - last_signal_idx >= cooldown:
                signals[i] = candidates[i]
                last_signal_idx = i
    return signals


# ============================================
# PANDAS WRAPPERS FOR JIT FUNCTIONS
# ============================================

def calculate_rsi(close: pd.Series, period: int = 14) -> pd.Series:
    """Calculate RSI using Wilder's smoothing - JIT-accelerated core."""
    values = close.to_numpy(dtype=np.float64)
    rsi_array = _rsi_numba(values, period)
    return pd.Series(rsi_array, index=close.index, name='RSI', dtype=float)


def calculate_macd(close: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9) -> pd.DataFrame:
    """Calculate MACD line, signal line, and histogram - JIT-accelerated core."""
    values = close.to_numpy(dtype=np.float64)
    macd_arr, sig_arr, hist_arr = _macd_numba(values, fast, slow, signal)

    return pd.DataFrame({
        'MACD': pd.Series(macd_arr, index=close.index, dtype=float),
        'Signal': pd.Series(sig_arr, index=close.index, dtype=float),
        'Histogram': pd.Series(hist_arr, index=close.index, dtype=float)
    })


# ============================================
# MODEL SAVING & LOADING & REAL-TIME EXECUTION
# ============================================
def load_model(model_path: str) -> dict:
    """Load a saved model file and return its parameters."""
    import os
    if not os.path.exists(model_path):
        raise FileNotFoundError(f"Model file not found: {model_path}")

    with open(model_path, 'rb') as f:
        model_data = pickle.load(f)
    return model_data


def save_best_model(output_dir, best_params, metrics_train, metrics_val, args, signal_density, command_line):
    """Save the best model parameters and metadata to a pickle file."""
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    if args.optimize_target == "put_credit":
        metric = "long_accuracy"
    elif args.optimize_target == "call_credit":
        metric = "short_accuracy"
    else:
        metric = "accuracy"
    score = metrics_val.get(metric, 0.0)
    model_name = f"oerh__m{metric}__la{args.lookahead_bars}__th{args.threshold_pct:.5f}__tt{args.target_type}__twr{score:.4f}__sd{signal_density:.4f}__ds{args.dataset_id}__cdb{best_params.get('cooldown_bars', 0)}__{args.ticker}__{timestamp}.pkl"
    model_filename = os.path.join(output_dir, model_name)
    model_data = {
        'best_params': best_params,
        'metadata': {
            'lookahead_bars': args.lookahead_bars,
            'dataset_id': args.dataset_id,
            'ticker': args.ticker,
            'threshold_pct': args.threshold_pct,
            'target_type': args.target_type,
            'metric': metric
        },
        'user_attrs': {
            'signal_ratio': signal_density,
            'metric_used': metric,
            'train_long_win_rate': metrics_train.get('long_accuracy', 0.0),
            'val_long_win_rate': metrics_val.get('long_accuracy', 0.0),
            'train_short_win_rate': metrics_train.get('short_accuracy', 0.0),
            'val_short_win_rate': metrics_val.get('short_accuracy', 0.0),
            'train_accuracy': metrics_train.get('accuracy', 0.0),
            'val_accuracy': metrics_val.get('accuracy', 0.0),
        },
        'command_line': command_line,
    }
    os.makedirs(output_dir, exist_ok=True)
    with open(model_filename, 'wb') as f:
        pickle.dump(model_data, f)

    print(f"\n💾 Best model saved as: {model_filename}")


def _describe_target_mode(target_type: str, lookahead_bars: int) -> str:
    """Human-readable description of a target labeling mode (used by --realtime)."""
    B = lookahead_bars
    if target_type == "any":
        return f"any point in window [t+1, t+{B}]"
    if target_type == "any_half_B":
        return f"any point in second half [t+{B // 2 + 1}, t+{B}]"
    if target_type == "any_half_B_for_sell":
        return f"any point in second half [t+{B // 2 + 1}, t+{B}] (bearish)"
    if target_type == "floor":
        return f"NEVER falls below floor [t+1, t+{B}] 🛡️"
    if target_type == "short_any":
        return f"price drops below threshold ANYWHERE in window [t+1, t+{B}] 📉"
    if target_type == "ceiling":
        return f"NEVER rises above ceiling [t+1, t+{B}] 🧢"
    if target_type == "any_2B":
        win_size = min(2, B)
        first = B - win_size + 1
        return f"only the LAST {win_size} bar(s) count: price exceeds threshold in [t+{first}, t+{B}] 🎯"
    if target_type == "any_2B_for_sell":
        win_size = min(2, B)
        first = B - win_size + 1
        return f"only the LAST {win_size} bar(s) count: price drops below threshold in [t+{first}, t+{B}] 📉"
    if target_type == "any_4B":
        win_size = min(4, B)
        first = B - win_size + 1
        return f"only the LAST {win_size} bar(s) count: price exceeds threshold in [t+{first}, t+{B}] 🎯"
    if target_type == "any_4B_for_sell":
        win_size = min(4, B)
        first = B - win_size + 1
        return f"only the LAST {win_size} bar(s) count: price drops below threshold in [t+{first}, t+{B}] 📉"
    return "exact future point"


def run_realtime(model_path: str, output_signal_only: bool, verbose: bool, clip_n: int, use_realtime_data: bool, return_values_as_dict: bool):
    """Run forecast in real-time mode using saved model parameters."""
    # Load model
    model_data = load_model(model_path)
    command_line = model_data['command_line'] if 'command_line' in model_data else ""
    params = model_data['best_params']
    metadata = model_data.get('metadata', {})
    assert 'lookahead_bars' in metadata
    lookahead_bars = params.get('lookahead_bars', metadata.get('lookahead_bars', 5))
    dataset_id = metadata.get('dataset_id')
    ticker = metadata.get('ticker')

    df = factory_load_data(_dataset_id=dataset_id, _ticker=ticker, _args={"clip_n": clip_n, "realtime": use_realtime_data})
    assert isinstance(df.columns, pd.MultiIndex)
    df.columns = ['_'.join(str(c) for c in col).strip('_') for col in df.columns]
    price_col = f'Close_{ticker}'

    test_signal_ratio = model_data['user_attrs']['signal_ratio']  # C'est la valeur de test
    metric_used = model_data['user_attrs']['metric_used']
    assert 'threshold_pct' in metadata
    threshold_pct = params.get('threshold_pct', metadata.get('threshold_pct', 0.))
    if metric_used == 'long_accuracy':
        train_win_rate = model_data['user_attrs']['train_long_win_rate']
        val_win_rate = model_data['user_attrs']['val_long_win_rate']
    elif metric_used == 'short_accuracy':
        train_win_rate = model_data['user_attrs']['train_short_win_rate']
        val_win_rate = model_data['user_attrs']['val_short_win_rate']
    elif metric_used == 'accuracy':
        train_win_rate = model_data['user_attrs'].get('train_accuracy', 0.0)
        val_win_rate = model_data['user_attrs'].get('val_accuracy', 0.0)
    else:
        print(model_data)
        assert False, f"TODO: {metric_used}"
    if verbose:
        print(f"\n🛠 Command Line: {command_line}")
        print(f"\n📊 Dataset Loaded: {ticker} | {dataset_id} | Lookahead {lookahead_bars} bars | {metric_used} @ {threshold_pct:.4%}")
        print(f"   Bars: {len(df):,} | Range: {df.index[0].strftime('%Y%m%d_%H%M')}  ->  {df.index[-1].strftime('%Y%m%d_%H%M')} | Train Win Rate: {train_win_rate:.2%} "
              f":: Test Win Rate: {val_win_rate:.2%} @{test_signal_ratio:.2%} signal density")
        if use_realtime_data: print(f"   Using realtime data (actual value is {df.iloc[-1][price_col]:.1f})")

    # Determine minimum history needed for indicators
    assert 'rsi_period' in params and 'macd_slow' in params
    min_history = max(
        params.get('rsi_period', 14),
        params.get('macd_slow', 26),
        params.get('rsi_period', 14) + params.get('macd_slow', 26),  # safety margin
        100
    )

    # Get latest window of data (needed for indicator calculations)
    latest_df = df.iloc[-min_history:].copy()

    # Extract parameters for run_forecast (filter only valid ones)
    valid_params = {k: v for k, v in params.items() if k in [
        'rsi_period', 'rsi_oversold', 'rsi_overbought', 'rsi_mode',
        'macd_fast', 'macd_slow', 'macd_signal',
        'one_euro_min', 'one_euro_factor',
        'lookahead_bars', 'threshold_pct', 'target_type', 'cooldown_bars'
    ]}
    assert 'target_type' in metadata
    target_type = metadata['target_type']
    valid_params.update({'target_type': target_type})

    # Run forecast on the window
    df_results, _ = run_forecast(
        df=latest_df,
        price_col=price_col,
        ticker=str(ticker),
        **valid_params
    )

    # Get the very latest signal
    latest_row = df_results.iloc[-1]
    signal = latest_row['Signal']
    current_price = latest_row[price_col]
    current_date = latest_row.name  # Index is datetime

    # Get config values (prefer params, fallback to metadata)
    assert 'metric' in metadata
    the_metric = params.get('metric', metadata.get('metric', 'long_accuracy'))
    assert the_metric == metric_used

    # Handle signal safely whether it's scalar or array
    if hasattr(signal, 'item'):
        signal = signal.item()
    elif hasattr(signal, 'values'):
        signal = signal.values[0]
    signal = int(signal)

    if signal == 1 and the_metric in ['long_accuracy', 'accuracy']:
        signal = 1
    elif signal == -1 and the_metric in ['short_accuracy', 'accuracy']:  # Sell signal
        signal = -1
    else:
        signal = 0

    # Calculate target price and date
    if signal == 1:
        target_price = current_price * (1 + threshold_pct)
        direction = "BuySignal"
        operator = ">"
    elif signal == -1:  # Sell signal
        target_price = current_price * (1 - threshold_pct)
        direction = "SellSignal"
        operator = "<"
    else:
        target_price = None
        direction = "NoSignal"
        operator = ""

    # Estimate target date
    target_date = get_next_step(the_date=current_date, dataset_id=dataset_id, nn=lookahead_bars)

    # Format output
    ticker_display = ticker if ticker != "^GSPC" else "SPX500"
    if verbose:
        if output_signal_only:
            # Minimal output for automation/scripts
            if signal == 1:
                print(f"BUY|{current_date.strftime('%Y-%m-%d')}|{current_price:.2f}|+{lookahead_bars}bars|{target_price:.2f}")
            elif signal == -1:
                print(f"SELL|{current_date.strftime('%Y-%m-%d')}|{current_price:.2f}|+{lookahead_bars}bars|{target_price:.2f}")
            else:
                print(f"HOLD|{current_date.strftime('%Y-%m-%d')}|{current_price:.2f}")
        else:
            # Human-readable output
            if signal != 0:
                target_mode_desc = _describe_target_mode(target_type, lookahead_bars)
                print(f"\n🎯 Real-Time Signal Detected:")
                print(f"On {current_date.strftime('%Y-%m-%d_%H%M')} {ticker_display} is at {current_price:.2f} and {direction} activated for +{lookahead_bars}Bars , {ticker_display} {operator} {target_price:.2f} on {target_date.strftime('%Y-%m-%d_%H%M')}")
                print(f"   Threshold: {threshold_pct * 100:.2f}% | Target Mode: '{target_type}' ({target_mode_desc}) | Model: {os.path.basename(model_path)}\n")
            else:
                print(f"\n⏸️  No signal on {current_date.strftime('%Y-%m-%d_%H%M')}: {ticker_display} at {current_price:.2f}")
                print(f"   (Threshold: {threshold_pct * 100:.4f}%, Lookahead: {lookahead_bars} bars, Target Mode: '{target_type}', Metric: {the_metric})\n")
    if return_values_as_dict:
        return {"signal": signal,
                "current_price": current_price,
                "current_date": current_date.strftime("%Y-%m-%d"),
                "target_price": target_price,
                "target_date": target_date,
                "train_win_rate": train_win_rate,
                "val_win_rate": val_win_rate,
                "threshold_pct": threshold_pct,
                "metric_target_type": f"{metric_used}::{target_type}",
                "dataset_id": dataset_id,
                "ticker": ticker,
                "lookahead_bars": lookahead_bars, }
    else:
        return signal, current_price, current_date.strftime('%Y-%m-%d'), target_price, target_date, train_win_rate, val_win_rate, threshold_pct, f"{metric_used}::{target_type}", dataset_id, ticker, lookahead_bars


# ============================================
# 4. LOOK-AHEAD LABELING (Forecast Target)
# ============================================
def create_target_exact(close: pd.Series, lookahead_bars: int, threshold_pct: float = 0.0) -> pd.Series:
    """Exact: Checks price exactly at t + lookahead_bars"""
    future_close = close.shift(-lookahead_bars)
    labels = (future_close > close * (1 + threshold_pct)).astype(float)
    labels.iloc[-lookahead_bars:] = np.nan
    return labels


def create_target_any(close: pd.Series, lookahead_bars: int, threshold_pct: float = 0.0) -> pd.Series:
    """
    Any: Checks if price EXCEEDS threshold at ANY point from t to t+lookahead_bars.
    Uses a forward-looking rolling maximum for efficient vectorized computation.
    """
    # Version optimisée (Exclut le prix actuel t, regarde uniquement de t+1 à t+lookahead_bars)
    future_max = close.iloc[::-1].rolling(window=lookahead_bars, min_periods=lookahead_bars).max().iloc[::-1].shift(-1)

    # True if max in window > threshold
    labels = (future_max > close * (1 + threshold_pct)).astype(float)

    # Mask out last lookahead_bars where future data is incomplete
    labels.iloc[-lookahead_bars:] = np.nan

    return labels


def create_target_any_at_half_B(close: pd.Series, lookahead_bars: int, threshold_pct: float = 0.0) -> pd.Series:
    """
    Any at half B: Checks if price EXCEEDS threshold at ANY point from t+B//2+1 to t+B.
    (i.e., the second half of the lookahead window, excluding the midpoint itself)
    Uses a forward-looking rolling maximum for efficient vectorized computation.

    Parameters
    ----------
    close : pd.Series
        Closing prices series
    lookahead_bars : int
        Number of bars to look ahead (B)
    threshold_pct : float, optional
        Percentage threshold for target (default: 0.0)

    Returns
    -------
    pd.Series
        Binary labels (1 if threshold exceeded in window, 0 otherwise), with NaN for incomplete windows
    """
    half_B = lookahead_bars // 2
    window_size = lookahead_bars - half_B  # Size of window from t+half_B+1 to t+B inclusive

    # Handle edge case where window would be empty
    if window_size <= 0:
        return pd.Series(np.nan, index=close.index, dtype=float)

    # Get max over the window [t+half_B+1, t+B] for each t
    # Reverse series, apply rolling max, reverse back, then shift to align window
    future_max = close.iloc[::-1].rolling(window=window_size, min_periods=window_size).max().iloc[::-1].shift(-(half_B + 1))

    # True if max in window > threshold
    labels = (future_max > close * (1 + threshold_pct)).astype(float)

    # Mask out last lookahead_bars where future data is incomplete
    labels.iloc[-lookahead_bars:] = np.nan

    return labels


def create_target_any_at_half_B_for_sell(close: pd.Series, lookahead_bars: int, threshold_pct: float = 0.0) -> pd.Series:
    """
    Any at half B (bearish): Checks if price DROPS BELOW threshold at ANY point
    from t+B//2+1 to t+B (i.e., the second half of the lookahead window).
    Uses a forward-looking rolling minimum for efficient vectorized computation.

    Parameters
    ----------
    close : pd.Series
        Closing prices series
    lookahead_bars : int
        Number of bars to look ahead (B)
    threshold_pct : float, optional
        Percentage threshold for target (default: 0.0)

    Returns
    -------
    pd.Series
        Binary labels (1 if threshold breached in window, 0 otherwise), with NaN for incomplete windows
    """
    half_B = lookahead_bars // 2
    window_size = lookahead_bars - half_B  # Size of window from t+half_B+1 to t+B inclusive

    # Handle edge case where window would be empty
    if window_size <= 0:
        return pd.Series(np.nan, index=close.index, dtype=float)

    # Get MIN over the window [t+half_B+1, t+B] for each t
    # Reverse series, apply rolling min, reverse back, then shift to align window
    future_min = close.iloc[::-1].rolling(window=window_size, min_periods=window_size).min().iloc[::-1].shift(-(half_B + 1))

    # True if min in window < threshold
    labels = (future_min < close * (1 + threshold_pct)).astype(float)

    # Mask out last lookahead_bars where future data is incomplete
    labels.iloc[-lookahead_bars:] = np.nan

    return labels


def create_target_floor(close: pd.Series, lookahead_bars: int, threshold_pct: float = 0.0) -> pd.Series:
    """
    FLOOR MODE: Label = 1 only if price NEVER falls below threshold
    throughout the entire lookahead window [t+1, t+B].

    Ideal for put credit spreads / defined-risk bullish strategies where you profit
    if price stays ABOVE your short put strike (the "floor").

    ⚠️ IMPORTANT: Use NEGATIVE threshold_pct for floor mode!
       • threshold_pct = -0.015 means floor = entry_price × 0.985 (1.5% below entry)
       • Label = 1 only if price MINIMUM in window > floor level

    Parameters
    ----------
    close : pd.Series
        Closing prices series
    lookahead_bars : int
        Number of bars to look ahead (B)
    threshold_pct : float, optional
        Percentage threshold for floor (default: 0.0)
        For floor protection: use NEGATIVE value (e.g., -0.015 = -1.5% floor)

    Returns
    -------
    pd.Series
        Binary labels (1 if price NEVER fell below floor, 0 otherwise),
        with NaN for incomplete windows
    """
    # Get MINIMUM price in forward window [t+1, t+lookahead_bars]
    # Reverse series → rolling min → reverse back → shift to exclude current bar
    future_min = close.iloc[::-1].rolling(window=lookahead_bars, min_periods=lookahead_bars).min().iloc[::-1].shift(-1)

    # Label = 1 if minimum stays ABOVE floor level throughout window
    # floor_level = entry_price × (1 + threshold_pct)
    # For threshold_pct = -0.015: floor = entry × 0.985
    labels = (future_min > close * (1 + threshold_pct)).astype(float)

    # Mask out last lookahead_bars where future data is incomplete
    labels.iloc[-lookahead_bars:] = np.nan

    return labels


def create_target_short_any(close: pd.Series, lookahead_bars: int, threshold_pct: float = 0.0) -> pd.Series:
    """
    SHORT ANY MODE: Checks if price DROPS below threshold at ANY point from t+1 to t+lookahead_bars.
    A win (1) means the price successfully dropped by threshold_pct.
    Symmetrical to "any" mode but for short targets.
    """
    future_min = close.iloc[::-1].rolling(window=lookahead_bars, min_periods=lookahead_bars).min().iloc[::-1].shift(-1)
    # For shorts, we want the minimum to be LOWER than (1 + threshold_pct)
    labels = (future_min < close * (1 + threshold_pct)).astype(float)
    labels.iloc[-lookahead_bars:] = np.nan
    return labels


def create_target_ceiling(close: pd.Series, lookahead_bars: int, threshold_pct: float = 0.0) -> pd.Series:
    """
    CEILING MODE: Label = 1 only if price NEVER rises above the ceiling.
    Ideal for call credit spreads / defined-risk bearish strategies.
    Symmetrical to "floor" mode but for short targets.
    """
    future_max = close.iloc[::-1].rolling(window=lookahead_bars, min_periods=lookahead_bars).max().iloc[::-1].shift(-1)
    # Label = 1 if maximum stays BELOW ceiling level
    labels = (future_max < close * (1 + threshold_pct)).astype(float)
    labels.iloc[-lookahead_bars:] = np.nan
    return labels


def create_target_any_last_2B(close: pd.Series, lookahead_bars: int, threshold_pct: float = 0.0) -> pd.Series:
    """
    ANY-2B MODE ("any_2B"): Label = 1 if the price EXCEEDS the threshold at ANY point
    inside the LAST TWO BARS of the lookahead window, i.e. [t+B-1, t+B].

    Parameters
    ----------
    close : pd.Series
        Closing prices series.
    lookahead_bars : int
        Number of bars to look ahead (B).
    threshold_pct : float, optional
        Percentage threshold for the target (default: 0.0).

    Returns
    -------
    pd.Series
        Binary labels (1 if threshold exceeded within the last 2 bars, 0 otherwise),
        with NaN for the last `lookahead_bars` rows where the forward window is incomplete.
    """
    if lookahead_bars <= 0:
        return pd.Series(np.nan, index=close.index, dtype=float)

    window_size = min(2, lookahead_bars)
    start_offset = lookahead_bars - window_size + 1

    future_max = (
        close.iloc[::-1]
        .rolling(window=window_size, min_periods=window_size).max()
        .iloc[::-1]
        .shift(-start_offset)
    )

    labels = (future_max > close * (1 + threshold_pct)).astype(float)
    labels.iloc[-lookahead_bars:] = np.nan

    return labels


def create_target_any_last_2B_for_sell(close: pd.Series, lookahead_bars: int, threshold_pct: float = 0.0) -> pd.Series:
    """
    🆕 ANY-2B FOR SELL MODE ("any_2B_for_sell"): Label = 1 if the price DROPS BELOW the threshold
    at ANY point inside the LAST TWO BARS of the lookahead window, i.e. [t+B-1, t+B].

    Bearish counterpart to `any_2B`, designed specifically for `call_credit` strategies.

    Parameters
    ----------
    close : pd.Series
        Closing prices series.
    lookahead_bars : int
        Number of bars to look ahead (B).
    threshold_pct : float, optional
        Percentage threshold for the target (default: 0.0).

    Returns
    -------
    pd.Series
        Binary labels (1 if threshold breached downwards within the last 2 bars, 0 otherwise),
        with NaN for the last `lookahead_bars` rows where the forward window is incomplete.
    """
    if lookahead_bars <= 0:
        return pd.Series(np.nan, index=close.index, dtype=float)

    window_size = min(2, lookahead_bars)
    start_offset = lookahead_bars - window_size + 1

    future_min = (
        close.iloc[::-1]
        .rolling(window=window_size, min_periods=window_size).min()
        .iloc[::-1]
        .shift(-start_offset)
    )

    # Bearish: Win if min in the last 2 bars drops below threshold
    labels = (future_min < close * (1 + threshold_pct)).astype(float)
    labels.iloc[-lookahead_bars:] = np.nan

    return labels


def create_target_any_last_4B(close: pd.Series, lookahead_bars: int, threshold_pct: float = 0.0) -> pd.Series:
    """
    ANY-4B MODE ("any_4B"): Label = 1 if the price EXCEEDS the threshold at ANY point
    inside the LAST FOUR BARS of the lookahead window, i.e. [t+B-3, t+B].

    Parameters
    ----------
    close : pd.Series
        Closing prices series.
    lookahead_bars : int
        Number of bars to look ahead (B).
    threshold_pct : float, optional
        Percentage threshold for the target (default: 0.0).

    Returns
    -------
    pd.Series
        Binary labels (1 if threshold exceeded within the last 4 bars, 0 otherwise),
        with NaN for the last `lookahead_bars` rows where the forward window is incomplete.
    """
    if lookahead_bars <= 0:
        return pd.Series(np.nan, index=close.index, dtype=float)

    window_size = min(4, lookahead_bars)
    start_offset = lookahead_bars - window_size + 1

    future_max = (
        close.iloc[::-1]
        .rolling(window=window_size, min_periods=window_size).max()
        .iloc[::-1]
        .shift(-start_offset)
    )

    labels = (future_max > close * (1 + threshold_pct)).astype(float)
    labels.iloc[-lookahead_bars:] = np.nan

    return labels


def create_target_any_last_4B_for_sell(close: pd.Series, lookahead_bars: int, threshold_pct: float = 0.0) -> pd.Series:
    """
    🆕 ANY-4B FOR SELL MODE ("any_4B_for_sell"): Label = 1 if the price DROPS BELOW the threshold
    at ANY point inside the LAST FOUR BARS of the lookahead window, i.e. [t+B-3, t+B].

    Bearish counterpart to `any_4B`, designed specifically for `call_credit` strategies.

    Parameters
    ----------
    close : pd.Series
        Closing prices series.
    lookahead_bars : int
        Number of bars to look ahead (B).
    threshold_pct : float, optional
        Percentage threshold for the target (default: 0.0).

    Returns
    -------
    pd.Series
        Binary labels (1 if threshold breached downwards within the last 4 bars, 0 otherwise),
        with NaN for the last `lookahead_bars` rows where the forward window is incomplete.
    """
    if lookahead_bars <= 0:
        return pd.Series(np.nan, index=close.index, dtype=float)

    window_size = min(4, lookahead_bars)
    start_offset = lookahead_bars - window_size + 1

    future_min = (
        close.iloc[::-1]
        .rolling(window=window_size, min_periods=window_size).min()
        .iloc[::-1]
        .shift(-start_offset)
    )

    # Bearish: Win if min in the last 4 bars drops below threshold
    labels = (future_min < close * (1 + threshold_pct)).astype(float)
    labels.iloc[-lookahead_bars:] = np.nan

    return labels


# Registry: target_type string → (labeling function, direction, required optimize_target(s))
# direction: "long"  → FutureLabel == 1 means price went UP past the threshold (bullish win condition)
#            "short" → FutureLabel == 1 means price went DOWN past the threshold (bearish win condition)
TARGET_MODES = {
    "exact": (create_target_exact, "long", ["put_credit"]),
    "any": (create_target_any, "long", ["put_credit"]),
    "any_half_B": (create_target_any_at_half_B, "long", ["put_credit"]),
    "any_half_B_for_sell": (create_target_any_at_half_B_for_sell, "short", ["call_credit"]),
    "floor": (create_target_floor, "long", ["put_credit"]),
    "short_any": (create_target_short_any, "short", ["call_credit"]),
    "ceiling": (create_target_ceiling, "short", ["call_credit"]),
    "any_2B": (create_target_any_last_2B, "long", ["put_credit"]),
    "any_2B_for_sell": (create_target_any_last_2B_for_sell, "short", ["call_credit"]),
    "any_4B": (create_target_any_last_4B, "long", ["put_credit"]),
    "any_4B_for_sell": (create_target_any_last_4B_for_sell, "short", ["call_credit"]),
}


def build_labels(close: pd.Series, target_type: str, lookahead_bars: int, threshold_pct: float) -> pd.Series:
    """Single entry point that dispatches to the correct labeling function."""
    if target_type not in TARGET_MODES:
        raise ValueError(
            f"Unknown target_type '{target_type}'. Valid options: {sorted(TARGET_MODES.keys())}"
        )
    func, _direction, _opt = TARGET_MODES[target_type]
    return func(close, lookahead_bars, threshold_pct)


def is_short_target_type(target_type: str) -> bool:
    """True when FutureLabel == 1 represents a bearish (downward) outcome."""
    return TARGET_MODES.get(target_type, (None, "long", None))[1] == "short"


# ============================================
# 5. RULE-BASED FORECASTING SYSTEM
# ============================================
class ForecastSystem:
    def __init__(self, rsi_period: int = 14, rsi_oversold: float = 30, rsi_overbought: float = 70,
                 macd_fast: int = 12, macd_slow: int = 26, macd_signal: int = 9,
                 one_euro_min: float = 10, one_euro_factor: float = 0.2,
                 lookahead_bars: int = 5, threshold_pct: float = 0.01,
                 rsi_mode: str = "momentum", target_type: str = "any",
                 use_jit_signals: bool = False, cooldown_bars: int = 0,
                 precomputed_labels: Optional[pd.Series] = None):
        self.rsi_period = rsi_period
        self.rsi_oversold = rsi_oversold
        self.rsi_overbought = rsi_overbought
        self.macd_fast = macd_fast
        self.macd_slow = macd_slow
        self.macd_signal = macd_signal
        self.one_euro_min = one_euro_min
        self.one_euro_factor = one_euro_factor
        self.lookahead_bars = lookahead_bars
        self.threshold_pct = threshold_pct
        self.rsi_mode = rsi_mode
        self.target_type = target_type
        self.use_jit_signals = use_jit_signals  # Enable JIT for signal generation
        self.cooldown_bars = cooldown_bars
        self.precomputed_labels = precomputed_labels

    def generate_signals(self, df: pd.DataFrame, price_col, ticker) -> pd.DataFrame:
        df = df.copy()
        close = df[price_col]
        _tmp_array = one_euro_filter(close.values, self.one_euro_min, self.one_euro_factor)
        assert len(_tmp_array) == len(close)
        df['OneEuro'] = _tmp_array
        df['RSI'] = calculate_rsi(close, self.rsi_period)
        macd_df = calculate_macd(close, self.macd_fast, self.macd_slow, self.macd_signal)
        df['MACD'] = macd_df['MACD']
        df['MACD_Signal'] = macd_df['Signal']
        df['Histogram'] = macd_df['Histogram']

        # ✅ DYNAMIC TARGET SELECTION
        if self.precomputed_labels is not None:
            # Inject precomputed labels to save compute time during optimization
            df['FutureLabel'] = self.precomputed_labels.reindex(df.index)
        else:
            df['FutureLabel'] = build_labels(
                close=close,
                target_type=self.target_type,
                lookahead_bars=self.lookahead_bars,
                threshold_pct=self.threshold_pct,
            )

        # ✅ SIGNAL GENERATION: JIT or vectorized pandas
        if self.use_jit_signals and len(df) > 100:  # JIT overhead not worth it for small datasets
            close_vals = close.to_numpy(dtype=np.float64)
            one_euro_vals = df['OneEuro'].to_numpy(dtype=np.float64)
            rsi_vals = df['RSI'].to_numpy(dtype=np.float64)
            hist_vals = df['Histogram'].to_numpy(dtype=np.float64)
            rsi_mode_momentum = (self.rsi_mode == "momentum")

            # Pass 1: Parallel Candidates
            candidates = _generate_candidates_numba(
                close_vals, one_euro_vals, rsi_vals, hist_vals,
                self.rsi_oversold, self.rsi_overbought, rsi_mode_momentum
            )
            # Pass 2: Sequential Cooldown
            signal_array = _apply_cooldown(candidates, self.cooldown_bars)
            df['Signal'] = signal_array
        else:
            # Original vectorized pandas approach
            df['Candidate'] = 0
            rsi_shift = df['RSI'].shift(1).fillna(df['RSI'])
            hist_shift = df['Histogram'].shift(1).fillna(df['Histogram'])

            if self.rsi_mode == "reversion":
                long_rsi_cond = df['RSI'] < self.rsi_oversold
                short_rsi_cond = df['RSI'] > self.rsi_overbought
            else:  # momentum
                long_rsi_cond = df['RSI'] > self.rsi_overbought
                short_rsi_cond = df['RSI'] < 50.0  # Relaxed short momentum: bearish territory

            long_cond = ((close > df['OneEuro']) & long_rsi_cond & (df['RSI'] > rsi_shift) &
                         (df['Histogram'] > 0) & (df['Histogram'] > hist_shift))
            short_cond = ((close < df['OneEuro']) & short_rsi_cond & (df['RSI'] < rsi_shift) &
                          (df['Histogram'] < 0) & (df['Histogram'] < hist_shift))

            df.loc[long_cond, 'Candidate'] = 1
            df.loc[short_cond, 'Candidate'] = -1

            # Apply Cooldown in Pandas
            df['Signal'] = 0
            if self.cooldown_bars > 0:
                signals = np.zeros(len(df), dtype=np.int8)
                last_idx = -self.cooldown_bars - 1
                cand_arr = df['Candidate'].to_numpy()
                for i in range(len(df)):
                    if cand_arr[i] != 0:
                        if i - last_idx >= self.cooldown_bars:
                            signals[i] = cand_arr[i]
                            last_idx = i
                df['Signal'] = signals
            else:
                df['Signal'] = df['Candidate']

            # Clean up temp column
            df.drop(columns=['Candidate'], inplace=True, errors='ignore')
            df['Signal'] = df['Signal'].fillna(0)

        return df

    def evaluate_signals(self, df: pd.DataFrame, price_col) -> dict:
        valid = df[['Signal', 'FutureLabel']].dropna()
        if len(valid) == 0: return {}
        valid = valid[valid['Signal'] != 0].copy()
        if len(valid) == 0: return {'total_signals': 0}

        is_short_target = is_short_target_type(self.target_type)

        long_signals = valid[valid['Signal'] == 1]
        short_signals = valid[valid['Signal'] == -1]

        # For standard targets (bullish), FutureLabel == 1 is a win for Long, and FutureLabel == 0 is a win for Short.
        # For short targets (bearish), FutureLabel == 1 is a win for Short, and FutureLabel == 0 is a win for Long.
        if is_short_target:
            long_correct = (long_signals['FutureLabel'] == 0).sum() if len(long_signals) > 0 else 0
            short_correct = (short_signals['FutureLabel'] == 1).sum() if len(short_signals) > 0 else 0
        else:
            long_correct = (long_signals['FutureLabel'] == 1).sum() if len(long_signals) > 0 else 0
            short_correct = (short_signals['FutureLabel'] == 0).sum() if len(short_signals) > 0 else 0

        total = len(valid)
        correct = long_correct + short_correct

        return {
            'total_signals': total,
            'total_bars': len(df),
            'accuracy': correct / total if total > 0 else 0,
            'long_signals': len(long_signals),
            'long_accuracy': long_correct / len(long_signals) if len(long_signals) > 0 else 0,
            'short_signals': len(short_signals),
            'short_accuracy': short_correct / len(short_signals) if len(short_signals) > 0 else 0,
        }


# ============================================
# JIT WARMUP & VALIDATION UTILITIES
# ============================================

def warmup_jit():
    """Pre-compile JIT functions to avoid first-run overhead."""
    dummy = np.array([100.0, 101.0, 99.5, 102.0, 100.5, 103.0, 101.5, 104.0], dtype=np.float64)
    _ = _rsi_numba(dummy, 14)
    _ = _ema_numba(dummy, 12)
    _ = _macd_numba(dummy, 12, 26, 9)
    cands = _generate_candidates_numba(dummy, dummy, dummy, dummy, 30.0, 70.0, True)
    _ = _apply_cooldown(cands, 2)


def _validate_jit_consistency(verbose: bool = True) -> bool:
    """
    Sanity check: Assert JIT functions produce results consistent with expected behavior.
    Returns True if validation passes, False otherwise.
    """
    if verbose:
        print("🔍 Running JIT consistency validation...")

    try:
        np.random.seed(42)
        # Generate realistic test data
        test_prices = 100 + np.cumsum(np.random.randn(500) * 0.5)
        test_close = pd.Series(test_prices, name='Close')

        # Test RSI
        rsi_result = calculate_rsi(test_close, period=14)
        assert not rsi_result.isna().all(), "RSI: All values are NaN"
        assert rsi_result.min() >= 0 and rsi_result.max() <= 100, "RSI: Values out of [0, 100] range"

        # Test MACD
        macd_df = calculate_macd(test_close, fast=12, slow=26, signal=9)
        assert not macd_df['MACD'].isna().all(), "MACD: All values are NaN"
        assert len(macd_df) == len(test_close), "MACD: Length mismatch"

        # Test signal generation (both modes)
        for mode in ["momentum", "reversion"]:
            df_test = pd.DataFrame({'Close': test_close})
            df_test['OneEuro'] = one_euro_filter(test_close.values, 10.0, 0.2)
            df_test['RSI'] = calculate_rsi(test_close, 14)
            macd_test = calculate_macd(test_close, 12, 26, 9)
            df_test['Histogram'] = macd_test['Histogram']

            # Test pandas vectorized path
            system_pandas = ForecastSystem(rsi_mode=mode, use_jit_signals=False, cooldown_bars=0)
            result_pandas = system_pandas.generate_signals(df_test.copy(), 'Close', 'TEST')

            # Test JIT path
            system_jit = ForecastSystem(rsi_mode=mode, use_jit_signals=True, cooldown_bars=0)
            result_jit = system_jit.generate_signals(df_test.copy(), 'Close', 'TEST')

            # Signals should be identical (both paths use same logic)
            assert (result_pandas['Signal'] == result_jit['Signal']).all(), \
                f"Signal mismatch in {mode} mode between pandas and JIT paths"

            # Test with cooldown
            system_pandas_cool = ForecastSystem(rsi_mode=mode, use_jit_signals=False, cooldown_bars=2)
            result_pandas_cool = system_pandas_cool.generate_signals(df_test.copy(), 'Close', 'TEST')

            system_jit_cool = ForecastSystem(rsi_mode=mode, use_jit_signals=True, cooldown_bars=2)
            result_jit_cool = system_jit_cool.generate_signals(df_test.copy(), 'Close', 'TEST')

            assert (result_pandas_cool['Signal'] == result_jit_cool['Signal']).all(), \
                f"Signal mismatch in {mode} mode between pandas and JIT paths WITH COOLDOWN"

        if verbose:
            print("✅ JIT validation passed: All functions produce consistent results")
        return True

    except Exception as e:
        print(f"❌ JIT validation FAILED: {e}")
        if verbose:
            import traceback
            traceback.print_exc()
        return False


# ============================================
# 6. RUN FORECAST (Updated to accept parameters)
# ============================================
def run_forecast(df: pd.DataFrame, price_col, ticker: str = "^GSPC",
                 rsi_period: int = 14, rsi_oversold: float = 30.0, rsi_overbought: float = 70.0, rsi_mode: str = "momentum",
                 macd_fast: int = 12, macd_slow: int = 26, macd_signal: int = 9,
                 one_euro_min: float = 10.0, one_euro_factor: float = 0.2,
                 lookahead_bars: int = 5, threshold_pct: float = 0.01,
                 target_type: str = "any", use_jit_signals: bool = False,
                 cooldown_bars: int = 0,
                 precomputed_labels: Optional[pd.Series] = None) -> Tuple[pd.DataFrame, dict]:
    if not pd.api.types.is_numeric_dtype(df[price_col].to_numpy().dtype if isinstance(df[price_col], pd.DataFrame) else df[price_col].dtype):
        df[price_col] = df[price_col].apply(pd.to_numeric, errors='coerce')
    df = df.dropna(subset=[price_col])

    system = ForecastSystem(
        rsi_period=rsi_period, rsi_oversold=rsi_oversold, rsi_overbought=rsi_overbought, rsi_mode=rsi_mode,
        macd_fast=macd_fast, macd_slow=macd_slow, macd_signal=macd_signal,
        one_euro_min=one_euro_min, one_euro_factor=one_euro_factor,
        lookahead_bars=lookahead_bars, threshold_pct=threshold_pct,
        target_type=target_type, use_jit_signals=use_jit_signals,
        cooldown_bars=cooldown_bars,
        precomputed_labels=precomputed_labels
    )
    df_signals = system.generate_signals(df=df, price_col=price_col, ticker=ticker)
    metrics = system.evaluate_signals(df=df_signals, price_col=price_col)
    return df_signals, metrics


# ============================================
# 7. PLOTTING HELPER (Unchanged)
# ============================================
def plot_forecast_results(df: pd.DataFrame, price_col, optimize_target, sample: int = 200, start_idx: int = -1,
                          highlight_signals: bool = True, zoom_region: Optional[Tuple[int, int]] = None, test_win_rate: float = 0.0, target_type: str = "any"):
    if start_idx == -1:
        start_idx = max(0, len(df) - sample)
    plot_df = df.iloc[start_idx:start_idx + sample].copy()

    fig, axes = plt.subplots(3, 1, figsize=(14, 10), gridspec_kw={'height_ratios': [3, 1, 1]}, sharex=True)
    ax1, ax2, ax3 = axes

    is_short_target = is_short_target_type(target_type)

    ax1.plot(plot_df.index, plot_df[price_col], label='Close', alpha=0.7, linewidth=1, color='black')
    ax1.plot(plot_df.index, plot_df['OneEuro'], label='One-Euro Filter', color='blue', linewidth=2)

    longs = plot_df[(plot_df['Signal'] == 1) & plot_df['FutureLabel'].notna()]
    shorts = plot_df[(plot_df['Signal'] == -1) & plot_df['FutureLabel'].notna()]

    if optimize_target in ["put_credit", "both"]:
        ax1.scatter(longs.index, longs[price_col], marker='^', color='green', s=100, label='Long Signal', zorder=6, edgecolors='darkgreen', linewidth=1.5)

        # Add bold W for winning trades and L for losing trades (Longs)
        if is_short_target:
            long_wins = longs[longs['FutureLabel'] == 0]
            long_losses = longs[longs['FutureLabel'] == 1]
        else:
            long_wins = longs[longs['FutureLabel'] == 1]
            long_losses = longs[longs['FutureLabel'] == 0]

        for idx, row in long_wins.iterrows():
            ax1.annotate('W', xy=(idx, row[price_col]), xytext=(0, 10), textcoords='offset points',
                         color='darkgreen', fontweight='bold', fontsize=12, ha='center', va='bottom')
        for idx, row in long_losses.iterrows():
            ax1.annotate('L', xy=(idx, row[price_col]), xytext=(0, 10), textcoords='offset points',
                         color='darkred', fontweight='bold', fontsize=12, ha='center', va='bottom')

    if optimize_target in ["call_credit", "both"]:
        ax1.scatter(shorts.index, shorts[price_col], marker='v', color='red', s=100, label='Short Signal', zorder=6, edgecolors='darkred', linewidth=1.5)

        # Add bold W for winning trades and L for losing trades (Shorts)
        if is_short_target:
            short_wins = shorts[shorts['FutureLabel'] == 1]
            short_losses = shorts[shorts['FutureLabel'] == 0]
        else:
            # Note: For standard short signals, winning means price did NOT exceed threshold (FutureLabel == 0)
            short_wins = shorts[shorts['FutureLabel'] == 0]
            short_losses = shorts[shorts['FutureLabel'] == 1]

        for idx, row in short_wins.iterrows():
            ax1.annotate('W', xy=(idx, row[price_col]), xytext=(0, 10), textcoords='offset points',
                         color='darkgreen', fontweight='bold', fontsize=12, ha='center', va='bottom')
        for idx, row in short_losses.iterrows():
            ax1.annotate('L', xy=(idx, row[price_col]), xytext=(0, 10), textcoords='offset points',
                         color='darkred', fontweight='bold', fontsize=12, ha='center', va='bottom')

    if highlight_signals:
        for idx in longs.index: ax1.axvline(x=idx, color='green', linestyle=':', alpha=0.4, linewidth=0.8)
        for idx in shorts.index: ax1.axvline(x=idx, color='red', linestyle=':', alpha=0.4, linewidth=0.8)
    ax1.set_title('Price + One-Euro Filter + Trading Signals', fontsize=13, fontweight='bold')
    ax1.set_ylabel('Price', fontsize=10);
    ax1.legend(loc='upper left', fontsize=9);
    ax1.grid(True, alpha=0.3, linestyle='--');
    ax1.set_axisbelow(True)

    ax2.plot(plot_df.index, plot_df['RSI'], label='RSI', color='purple', linewidth=1.5)
    ax2.axhline(70, color='red', linestyle='--', alpha=0.6, linewidth=1, label='Overbought/Oversold')
    ax2.axhline(30, color='red', linestyle='--', alpha=0.6, linewidth=1)
    ax2.axhline(50, color='gray', linestyle=':', alpha=0.3, linewidth=0.5)
    ax2.fill_between(plot_df.index, 70, 100, color='red', alpha=0.1)
    ax2.fill_between(plot_df.index, 0, 30, color='green', alpha=0.1)
    if highlight_signals:
        for idx in longs.index: ax2.axvline(x=idx, color='green', linestyle=':', alpha=0.4, linewidth=0.8)
        for idx in shorts.index: ax2.axvline(x=idx, color='red', linestyle=':', alpha=0.4, linewidth=0.8)
    ax2.set_ylabel('RSI', fontsize=10);
    ax2.set_ylim(0, 100);
    ax2.legend(loc='lower right', fontsize=9);
    ax2.grid(True, alpha=0.3, linestyle='--');
    ax2.set_axisbelow(True)

    colors = ['green' if val >= 0 else 'red' for val in plot_df['Histogram']]
    ax3.bar(plot_df.index, plot_df['Histogram'], color=colors, alpha=0.6, label='Histogram', width=1)
    ax3.plot(plot_df.index, plot_df['MACD'], label='MACD', color='blue', linewidth=1.2)
    ax3.plot(plot_df.index, plot_df['MACD_Signal'], label='Signal Line', color='orange', linewidth=1.2)
    ax3.axhline(0, color='gray', linestyle='-', alpha=0.4, linewidth=0.8)
    if highlight_signals:
        for idx in longs.index: ax3.axvline(x=idx, color='green', linestyle=':', alpha=0.4, linewidth=0.8)
        for idx in shorts.index: ax3.axvline(x=idx, color='red', linestyle=':', alpha=0.4, linewidth=0.8)
    ax3.set_ylabel('MACD', fontsize=10);
    ax3.set_xlabel('Date', fontsize=10);
    ax3.legend(loc='lower right', fontsize=9);
    ax3.grid(True, alpha=0.3, linestyle='--');
    ax3.set_axisbelow(True)

    if zoom_region is not None:
        zoom_start, zoom_end = zoom_region
        if zoom_start < len(plot_df) and zoom_end <= len(plot_df) and zoom_start < zoom_end:
            zoom_df = plot_df.iloc[zoom_start:zoom_end]
            from matplotlib.patches import Rectangle
            ax1_inset = ax1.inset_axes([0.62, 0.55, 0.35, 0.35])
            ax1_inset.plot(zoom_df.index, zoom_df[price_col], color='black', linewidth=1.5)
            ax1_inset.plot(zoom_df.index, zoom_df['OneEuro'], color='blue', linewidth=2)

            zoom_longs = zoom_df[(zoom_df['Signal'] == 1) & zoom_df['FutureLabel'].notna()]
            zoom_shorts = zoom_df[(zoom_df['Signal'] == -1) & zoom_df['FutureLabel'].notna()]

            ax1_inset.scatter(zoom_longs.index, zoom_longs[price_col], marker='^', color='green', s=50, zorder=5)
            ax1_inset.scatter(zoom_shorts.index, zoom_shorts[price_col], marker='v', color='red', s=50, zorder=5)

            if optimize_target in ["put_credit", "both"]:
                if is_short_target:
                    zoom_long_wins = zoom_longs[zoom_longs['FutureLabel'] == 0]
                    zoom_long_losses = zoom_longs[zoom_longs['FutureLabel'] == 1]
                else:
                    zoom_long_wins = zoom_longs[zoom_longs['FutureLabel'] == 1]
                    zoom_long_losses = zoom_longs[zoom_longs['FutureLabel'] == 0]

                for idx, row in zoom_long_wins.iterrows():
                    ax1_inset.annotate('W', xy=(idx, row[price_col]), xytext=(0, 8), textcoords='offset points', color='darkgreen', fontweight='bold', fontsize=10, ha='center', va='bottom')
                for idx, row in zoom_long_losses.iterrows():
                    ax1_inset.annotate('L', xy=(idx, row[price_col]), xytext=(0, 8), textcoords='offset points', color='darkred', fontweight='bold', fontsize=10, ha='center', va='bottom')
            if optimize_target in ["call_credit", "both"]:
                if is_short_target:
                    zoom_short_wins = zoom_shorts[zoom_shorts['FutureLabel'] == 1]
                    zoom_short_losses = zoom_shorts[zoom_shorts['FutureLabel'] == 0]
                else:
                    zoom_short_wins = zoom_shorts[zoom_shorts['FutureLabel'] == 0]
                    zoom_short_losses = zoom_shorts[zoom_shorts['FutureLabel'] == 1]

                for idx, row in zoom_short_wins.iterrows():
                    ax1_inset.annotate('W', xy=(idx, row[price_col]), xytext=(0, 8), textcoords='offset points', color='darkgreen', fontweight='bold', fontsize=10, ha='center', va='bottom')
                for idx, row in zoom_short_losses.iterrows():
                    ax1_inset.annotate('L', xy=(idx, row[price_col]), xytext=(0, 8), textcoords='offset points', color='darkred', fontweight='bold', fontsize=10, ha='center', va='bottom')

            ax1_inset.set_xticks([]);
            ax1_inset.set_yticks([]);
            ax1_inset.set_title('Zoom', fontsize=8, fontweight='bold');
            ax1_inset.grid(True, alpha=0.3)
            rect = Rectangle((zoom_df.index[0], plot_df[price_col].min()), zoom_df.index[-1] - zoom_df.index[0], plot_df[price_col].max() - plot_df[price_col].min(), linewidth=1.5, edgecolor='gold', facecolor='none', linestyle='--')
            ax1.add_patch(rect)
            ax1.indicate_inset_zoom(ax1_inset, edgecolor="gold", alpha=0.7)

    plt.setp(ax3.xaxis.get_majorticklabels(), rotation=45, ha='right')
    for ax in [ax1, ax2]: ax.tick_params(labelbottom=False)
    plt.suptitle(f'🔗 Linked Technical Analysis Dashboard (Test Win Rate: {test_win_rate:.2%} | Zoom: sharex enabled)', fontsize=14, fontweight='bold', y=0.995)
    plt.tight_layout(rect=[0, 0, 1, 0.98])
    fig.text(0.5, 0.01, "💡 Tip: Use mouse wheel to zoom, drag to pan — all panels stay synchronized!", ha='center', fontsize=9, style='italic', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.3))
    plt.show()


# ============================================
# 8. ARGPARSE & ENTRY POINT
# ============================================
def setup_argparse() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Rule-based Technical Forecasting System (One-Euro + RSI + MACD) [JIT-ACCELERATED]",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    data_grp = parser.add_argument_group("Data & Environment")
    data_grp.add_argument("--dataset-id", type=str, default="day", help="Dataset identifier")
    data_grp.add_argument("--ticker", type=str, default="^GSPC", help="Ticker symbol to analyze")
    data_grp.add_argument("--seed", type=int, default=42, help="Random seed for reproducibility")
    data_grp.add_argument("--disable-print", action="store_true", help="Skip prints")
    data_grp.add_argument('--verbose', action=argparse.BooleanOptionalAction, default=True, help='Print detailed progress, metrics, and explanations')
    data_grp.add_argument('--validate-jit', action='store_true', default=False,
                          help='Run JIT consistency sanity check at startup (default: disabled)')
    data_grp.add_argument("--clip-n", type=int, default=0, help="Number of most recent bars to clip from the dataset.")
    data_grp.add_argument('--output-dir', type=str, default='models', help='Output directory')

    algo_grp = parser.add_argument_group("Algorithm Parameters")
    algo_grp.add_argument("--rsi-period", type=int, default=14, help="RSI calculation window")
    algo_grp.add_argument("--rsi-oversold", type=float, default=30.0, help="RSI oversold threshold")
    algo_grp.add_argument("--rsi-overbought", type=float, default=70.0, help="RSI overbought threshold")
    algo_grp.add_argument("--rsi-mode", type=str, choices=["momentum", "reversion"], default="momentum", help="RSI signal logic")
    algo_grp.add_argument("--macd-fast", type=int, default=12, help="MACD fast EMA period")
    algo_grp.add_argument("--macd-slow", type=int, default=26, help="MACD slow EMA period")
    algo_grp.add_argument("--macd-signal", type=int, default=9, help="MACD signal line period")
    algo_grp.add_argument("--one-euro-min", type=float, default=10.0, help="One-Euro filter min cutoff")
    algo_grp.add_argument("--one-euro-factor", type=float, default=0.2, help="One-Euro filter beta factor")
    algo_grp.add_argument("--lookahead-bars", type=int, default=10, help="Future bars to forecast")
    algo_grp.add_argument("--threshold-pct", type=float, default=0., help="Min %% move to create the target (use NEGATIVE for floor mode)")
    algo_grp.add_argument("--density-target", type=float, default=0.04, help="Target trade density (signals per bar) for optimization penalty. A 0 value disable it.")
    algo_grp.add_argument('--train-ratio', type=float, default=0.9, help='Ratio of data to use for training (rest for validation). Use 1.0 to disable split.')
    algo_grp.add_argument('--use-jit-signals', action='store_true', default=True, help='Enable JIT acceleration for signal generation (recommended for large datasets)')
    algo_grp.add_argument("--n-trials", type=int, default=50, help="Number of trials for Optuna optimization")
    algo_grp.add_argument("--n-split", type=int, default=10, help="")
    algo_grp.add_argument("--alpha", type=float, default=1, help="")
    algo_grp.add_argument("--beta", type=float, default=4, help="")
    algo_grp.add_argument('--timeout', type=int, default=120, help='Max runtime (seconds)')
    algo_grp.add_argument(
        "--optuna-db",
        type=str,
        default=None,
        help="Storage location for Optuna (e.g., sqlite:///example.db). If specified and contains completed trials, prints the best candidate before optimization."
    )
    algo_grp.add_argument(
        "--optimize-target",
        type=str,
        choices=["put_credit", "call_credit"],
        default="put_credit",
        help="Target to optimize during Optuna search: 'put_credit', 'call_credit'"
    )
    # Target labeling mode - UPDATED to include "any_4B" and "any_4B_for_sell"
    algo_grp.add_argument(
        "--target-type",
        type=str,
        choices=sorted(TARGET_MODES.keys()),
        default="any_half_B",
        help=("Target labeling method: 'exact', 'any', 'any_half_B', 'any_half_B_for_sell', 'floor', "
              "'short_any', 'ceiling', 'any_2B', 'any_2B_for_sell', 'any_4B' 🆕, or 'any_4B_for_sell' 🆕 (bearish: only the LAST FOUR bars count for drop)")
    )

    viz_grp = parser.add_argument_group("Visualization")
    viz_grp.add_argument("--plot-sample", type=int, default=1000, help="Number of recent bars to plot")
    viz_grp.add_argument("--disable-plot-sample", action="store_true", default=False, help="Skip plotting section")

    realtime_grp = parser.add_argument_group("Real-Time Mode")
    realtime_grp.add_argument(
        "--realtime",
        action="store_true",
        help="Run in real-time mode: evaluate only the latest data point using a saved model"
    )
    realtime_grp.add_argument("--use-realtime-data", action=argparse.BooleanOptionalAction, default=False)
    realtime_grp.add_argument(
        "--model-path",
        type=str,
        help="Path to saved model file (.pkl) to load optimized parameters"
    )
    realtime_grp.add_argument(
        "--output-signal-only",
        action="store_true",
        help="In real-time mode, output only the signal decision (for automation)"
    )

    return parser


def entry(args):
    command_line = "python " + " ".join(sys.argv)
    # ✅ JIT VALIDATION (optional, disabled by default)
    if getattr(args, 'validate_jit', False):
        if not _validate_jit_consistency(verbose=args.verbose):
            print("⚠️  JIT validation failed. Proceeding anyway (results may be inconsistent).")
            return None
        # Warmup jit after validation to cache compiled functions
        warmup_jit()

    # ✅ REAL-TIME MODE: Load model and evaluate latest point only
    if args.realtime:
        if not args.model_path:
            raise ValueError("--model-path is required when using --real-time")
        return run_realtime(output_signal_only=getattr(args, 'output_signal_only', False), model_path=args.model_path, return_values_as_dict=getattr(args, 'return_values_as_dict', False),
                            verbose=getattr(args, 'verbose', False), clip_n=getattr(args, 'clip_n', 0), use_realtime_data=getattr(args, 'use_realtime_data', True))

    if args.verbose:
        print("✅ __doc__ length:", len(__doc__ or ""))
        print("✅ First line:", __doc__.split('\n')[0] if __doc__ else "None")
        print(__doc__)

    # ✅ BATCH MODE: Original behavior with optional train/val split
    np.random.seed(args.seed)
    df = factory_load_data(_dataset_id=args.dataset_id, _ticker=args.ticker, _args={"clip_n": args.clip_n})
    # 🔥 Flatten MultiIndex columns to prevent KeyError during signal generation/evaluation
    assert isinstance(df.columns, pd.MultiIndex)
    df.columns = ['_'.join(str(c) for c in col).strip('_') for col in df.columns]
    price_col = f'Close_{args.ticker}'

    if args.target_type not in TARGET_MODES:
        raise ValueError(f"Unknown --target-type '{args.target_type}'. Valid: {sorted(TARGET_MODES.keys())}")

    if args.lookahead_bars == 1:
        # With a 1-bar horizon every window-based mode degenerates to a single future bar.
        assert args.target_type in ["exact", "any", "floor", "short_any", "ceiling", "any_2B", "any_2B_for_sell", "any_4B", "any_4B_for_sell"], (
            f"target_type '{args.target_type}' is not meaningful with --lookahead-bars 1"
        )

    # ✅ OPTIMIZATION & TRAIN/VALIDATION SPLIT LOGIC
    min_history = max(args.rsi_period, args.macd_slow, 100) + args.lookahead_bars + 10
    total_len = len(df)

    if total_len < min_history:
        raise ValueError(f"Dataset too small ({total_len} bars) for indicators + lookahead. Need at least {min_history}.")

    train_end_idx = int(total_len * args.train_ratio)
    # Ensure training set has enough data for warmup
    train_end_idx = max(train_end_idx, min_history)

    df_train = df.iloc[:train_end_idx].copy()
    df_test  = df.iloc[train_end_idx:].copy()
    if args.verbose:
        str_tr = f"({df_train.index[0].strftime('%Y-%m-%d_%H%M')}::{df_train.index[-1].strftime('%Y-%m-%d_%H%M')})"
        str_te = f"({df_test.index[0].strftime('%Y-%m-%d_%H%M')}::{df_test.index[-1].strftime('%Y-%m-%d_%H%M')})"
        print(f"🔀 Data Split: Train={len(df_train)} bars ({args.train_ratio * 100:.1f}%) {str_tr}, Test={len(df_test)} bars ({(1 - args.train_ratio) * 100:.1f}%) {str_te} | Dataset: {args.dataset_id}")
        print(f"🔀 Lookahead bars: {args.lookahead_bars} | Threshold: {args.threshold_pct} | Win Condition: {args.target_type} | Optimize: {args.optimize_target} | Target Density: {args.density_target} | Cooldown bars: optimized [0, 12]")

    # ✅ PRE-COMPUTE LABELS ONCE (Before Optuna)
    # Since target generation does NOT depend on RSI/MACD/OneEuro parameters,
    # calculate it globally before the study starts to save massive compute time!
    close_train = df_train[price_col]
    _func, _direction, allowed_optimize = TARGET_MODES[args.target_type]
    assert args.optimize_target in allowed_optimize, (
        f"target_type '{args.target_type}' must be optimized with "
        f"--optimize-target in {allowed_optimize}, got '{args.optimize_target}'"
    )
    precomputed_labels = _func(close_train, args.lookahead_bars, args.threshold_pct)

    if args.verbose:
        print(f"\n🏷️  Pre-computed labels using target_type='{args.target_type}' "
              f"(direction={_direction}) :: {_describe_target_mode(args.target_type, args.lookahead_bars)}")
        print(f"\n🚀 Starting Optuna Optimization with TimeSeriesSplit(n_splits=10) for {args.n_trials} trials...")
        print(f"🎯 Optimization Target: {args.optimize_target.upper()} signals only")

    is_short_target = is_short_target_type(args.target_type)

    def objective(trial):
        rsi_period = trial.suggest_int("rsi_period", 5, 30)
        rsi_oversold = trial.suggest_float("rsi_oversold", 10.0, 45.0)
        rsi_overbought = trial.suggest_float("rsi_overbought", 55.0, 90.0)
        rsi_mode = trial.suggest_categorical("rsi_mode", ["momentum", "reversion"])
        macd_fast = trial.suggest_int("macd_fast", 6, 16)
        macd_slow = trial.suggest_int("macd_slow", 20, 40)
        macd_signal = trial.suggest_int("macd_signal", 5, 15)
        one_euro_min = trial.suggest_float("one_euro_min", 1.0, 50.0)
        one_euro_factor = trial.suggest_float("one_euro_factor", 0.01, 1.0)
        cooldown_bars = trial.suggest_int("cooldown_bars", 0, 12)

        tscv = TimeSeriesSplit(n_splits=getattr(args, "n_split", 10))
        fold_scores = []
        fold_densities = []
        n_samples = len(df_train)
        X = np.arange(n_samples)

        # Run forecast on the FULL df_train.
        # This ensures RSI, MACD, and One-Euro filters have proper historical warmup data.
        df_signals, _ = run_forecast(
            df=df_train,  # <-- Pass full training data for accurate indicator calculation
            price_col=price_col,
            ticker=args.ticker,
            rsi_period=rsi_period,
            rsi_oversold=rsi_oversold,
            rsi_overbought=rsi_overbought,
            rsi_mode=rsi_mode,
            macd_fast=macd_fast,
            macd_slow=macd_slow,
            macd_signal=macd_signal,
            one_euro_min=one_euro_min,
            one_euro_factor=one_euro_factor,
            lookahead_bars=args.lookahead_bars,
            threshold_pct=args.threshold_pct,
            target_type=args.target_type,
            use_jit_signals=args.use_jit_signals,
            cooldown_bars=cooldown_bars,
            precomputed_labels=precomputed_labels
        )

        for train_idx, val_idx in tscv.split(X):
            # Manually evaluate metrics ONLY on the validation fold indices.
            # This prevents look-ahead bias while maintaining indicator accuracy.
            val_df = df_signals.iloc[val_idx].dropna(subset=['Signal', 'FutureLabel']).copy()
            fold_total_valid_bars = len(val_df)

            # Filter validation dataframe based on optimization target
            if args.optimize_target == "put_credit":
                val_df_filtered = val_df[val_df['Signal'] == 1].copy()  # Only long signals
            elif args.optimize_target == "call_credit":
                val_df_filtered = val_df[val_df['Signal'] == -1].copy()  # Only short signals
            else:
                val_df_filtered = val_df[val_df['Signal'] != 0].copy()  # Both long and short signals

            fold_density = len(val_df_filtered) / fold_total_valid_bars if fold_total_valid_bars > 0 else 0.0
            fold_densities.append(fold_density)

            if len(val_df_filtered) == 0:
                fold_scores.append(0.0)
                continue

            if is_short_target:
                val_df_filtered['ActualUp'] = (1 - val_df_filtered['FutureLabel'].astype(int))
                val_df_filtered['ActualDown'] = val_df_filtered['FutureLabel'].astype(int)
            else:
                val_df_filtered['ActualUp'] = val_df_filtered['FutureLabel'].astype(int)
                val_df_filtered['ActualDown'] = (1 - val_df_filtered['FutureLabel'].astype(int))

            # Calculate accuracy strictly based on the chosen optimization target
            if args.optimize_target == "put_credit":
                acc = val_df_filtered['ActualUp'].mean()
            elif args.optimize_target == "call_credit":
                acc = val_df_filtered['ActualDown'].mean()
            else:
                val_df_filtered['PredUp'] = (val_df_filtered['Signal'] == 1).astype(int)
                acc = (val_df_filtered['PredUp'] == val_df_filtered['ActualUp']).mean()

            fold_scores.append(acc)

        mean_score = float(np.mean(fold_scores))
        assert 0 <= mean_score <= 1
        std_score = float(np.std(fold_scores))

        mean_density = np.mean(fold_densities)
        density_penalty = abs(mean_density - args.density_target) if mean_density < args.density_target else 0.
        assert 0 <= density_penalty <= 1

        # Alpha controls how much we punish inconsistency across different time periods
        alpha = getattr(args, "alpha", 1.)
        beta  = getattr(args, "beta", 4.)
        final_score = mean_score - (alpha * std_score) - (beta * density_penalty)
        return final_score

    sampler = optuna.samplers.TPESampler(seed=args.seed, n_startup_trials=99, )

    create_study_kwargs = {
        'direction': 'maximize',
        'sampler': sampler,
    }

    if args.optuna_db:
        study_name = f"{args.ticker}_{args.dataset_id}_{args.target_type}"

        def parse_storage_url(url: str):
            """Convertit une chaîne d'URL en objet Storage Optuna adapté."""
            if url.startswith("journal://"):
                # Extrait le chemin après "journal://"
                file_path = url.replace("journal://", "", 1)
                return JournalStorage(JournalFileBackend(file_path))

            # Pour sqlite://, postgresql://, redis://, etc.
            return url

        storage = parse_storage_url(args.optuna_db)

        create_study_kwargs['storage'] = storage
        create_study_kwargs['study_name'] = study_name
        create_study_kwargs['load_if_exists'] = True

        # Check for existing completed trials
        try:
            existing_study = optuna.load_study(
                study_name=study_name,
                storage=args.optuna_db
            )
            completed_trials = [t for t in existing_study.trials if t.state == optuna.trial.TrialState.COMPLETE]
            if completed_trials:
                best_trial = existing_study.best_trial
                print("\n📂 Found existing Optuna study with completed trials!")
                print("🏆 Best Candidate so far:")
                for k, v in best_trial.params.items():
                    print(f"   {k}: {v}")
                print(f"   Best CV Accuracy: {best_trial.value:.8f}\n")
        except KeyError:
            pass  # Study does not exist yet, will be created

    def perfect_score_callback(study, trial):
        if study.best_value is not None and study.best_value >= 0.9999:
            print("\n🎯 Perfect score reached (≥ 0.9999). Stopping optimization early.")
            study.stop()

    study = optuna.create_study(**create_study_kwargs)
    study.optimize(objective, n_trials=args.n_trials, show_progress_bar=args.verbose, timeout=args.timeout, callbacks=[perfect_score_callback, ])

    best_params = study.best_params
    if args.verbose:
        print("\n✅ Optimization Complete!")
        print("🏆 Best Parameters:")
        for k, v in best_params.items():
            print(f"   {k}: {v}")
        print(f"   Best CV Accuracy: {study.best_value:.8f}\n")

    # Helper to run forecast and print results
    def run_and_report(df_subset, label, optimize_target, plot_results=False, params=None):
        assert params is not None

        # Use precomputed labels if the subset is the training set and we are optimizing
        labels_to_use = None
        if df_subset is df_train and precomputed_labels is not None:
            labels_to_use = precomputed_labels

        df_results, metrics = run_forecast(
            df=df_subset, price_col=price_col, ticker=args.ticker,
            rsi_period=params.get('rsi_period', args.rsi_period),
            rsi_oversold=params.get('rsi_oversold', args.rsi_oversold),
            rsi_overbought=params.get('rsi_overbought', args.rsi_overbought),
            rsi_mode=params.get('rsi_mode', args.rsi_mode),
            macd_fast=params.get('macd_fast', args.macd_fast),
            macd_slow=params.get('macd_slow', args.macd_slow),
            macd_signal=params.get('macd_signal', args.macd_signal),
            one_euro_min=params.get('one_euro_min', args.one_euro_min),
            one_euro_factor=params.get('one_euro_factor', args.one_euro_factor),
            lookahead_bars=args.lookahead_bars,
            threshold_pct=args.threshold_pct,
            target_type=args.target_type,
            use_jit_signals=args.use_jit_signals,
            cooldown_bars=params.get('cooldown_bars', 0),
            precomputed_labels=labels_to_use
        )
        if not args.disable_print:
            print(f"\n📊 {label} Evaluation")
            print(f"   Ticker: {args.ticker} | Data range: {df_subset.index[0].strftime('%Y-%m-%d_%H%M')} to {df_subset.index[-1].strftime('%Y-%m-%d_%H%M')} ({len(df_subset)} bars)")
            if args.optimize_target in ["both"]:
                print(f"   Total Signals: {metrics.get('total_signals', 0)}")
                print(f"   Density: {metrics.get('total_signals', 0) / len(df_subset):.2%}")
                print(f"   Overall Accuracy: {metrics.get('accuracy', 0) * 100:.2f}%")
            if args.optimize_target in ["put_credit"]:
                print(f"   Density: {metrics.get('long_signals', 0) / len(df_subset):.2%}")
                print(f"   Long Signals: {metrics.get('long_signals', 0)} | Accuracy: {metrics.get('long_accuracy', 0) * 100:.2f}%")
            if args.optimize_target in ["call_credit"]:
                print(f"   Density: {metrics.get('short_signals', 0) / len(df_subset):.2%}")
                print(f"   Short Signals: {metrics.get('short_signals', 0)} | Accuracy: {metrics.get('short_accuracy', 0) * 100:.2f}%")
            print(f"   Look-ahead Horizon: {args.lookahead_bars} bars")
            print(f"   Target Mode: '{args.target_type}' ({_describe_target_mode(args.target_type, args.lookahead_bars)})")
            print(f"   Threshold For Creating Target: {args.threshold_pct * 100:.2f}%\n")
        if plot_results and not args.disable_plot_sample:
            # Determine test win rate based on optimization target
            if args.optimize_target == "put_credit":
                wr = metrics.get('long_accuracy', 0.0)
            elif args.optimize_target == "call_credit":
                wr = metrics.get('short_accuracy', 0.0)
            else:
                wr = metrics.get('accuracy', 0.0)

            plot_forecast_results(df=df_results, price_col=price_col, sample=args.plot_sample, optimize_target=optimize_target, test_win_rate=wr, target_type=args.target_type)
        return df_results, metrics

    # Run on training set (backtest)
    _, metrics_train = run_and_report(df_subset=df_train, label="🔧 TRAINING SET (Backtest)", optimize_target=args.optimize_target, plot_results=False, params=best_params)

    # Run on test set (final evaluation) a.k.a. test set :)
    df_results_val, metrics_val = run_and_report(df_subset=df_test, label="✅ TEST SET (Final Evaluation)", optimize_target=args.optimize_target, plot_results=True, params=best_params)

    # Print comparison summary
    if not args.disable_print and metrics_train and metrics_val:
        print("\n" + "=" * 60)
        print("📈 TRAIN vs TEST COMPARISON")
        print("=" * 60)
        print(f"{'Metric':<24} {'Train':>10} {'Test':>12} {'Δ':>10}")
        print("-" * 60)
        for key in ['accuracy', 'long_accuracy', 'short_accuracy']:
            if key == 'accuracy' and args.optimize_target in ["put_credit", "call_credit"]:
                continue
            if key == 'long_accuracy' and args.optimize_target in ["both", "call_credit"]:
                continue
            if key == 'short_accuracy' and args.optimize_target in ["both", "put_credit"]:
                continue
            train_val = metrics_train.get(key, 0) * 100
            val_val = metrics_val.get(key, 0) * 100
            delta = val_val - train_val
            print(f"{key:<25} {train_val:>11.2f}% {val_val:>11.2f}% {delta:>+9.2f}%")
        print("=" * 60 + "\n")

    # 💾 Save best model at the end of optimization
    total_bars_val = metrics_val.get('total_bars', len(df_test))
    signal_density = metrics_val.get('total_signals', 0) / total_bars_val if total_bars_val > 0 else 0.0
    if args.optimize_target == "put_credit":
        signal_density = metrics_val.get('long_signals', 0) / total_bars_val if total_bars_val > 0 else 0.0
    elif args.optimize_target == "call_credit":
        signal_density = metrics_val.get('short_signals', 0) / total_bars_val if total_bars_val > 0 else 0.0
    save_best_model(
        output_dir=args.output_dir,
        best_params=best_params,
        metrics_train=metrics_train,
        metrics_val=metrics_val,
        args=args,
        signal_density=signal_density,
        command_line=command_line,
    )

    return metrics_val, metrics_train


if __name__ == "__main__":
    parser = setup_argparse()
    args = parser.parse_args()
    entry(args)