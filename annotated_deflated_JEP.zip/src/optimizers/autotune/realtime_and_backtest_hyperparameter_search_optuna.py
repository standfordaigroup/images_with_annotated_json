"""
AutoTune Cycle-Aware Trading Strategy
======================================
Overview:
    A quantitative trading algorithm that leverages digital signal processing (DSP)
    techniques to dynamically adapt to market cycles. By isolating cyclical price
    movements from long-term trends and noise, the strategy generates momentum-based
    trading signals that are optimized for specific risk/reward profiles using Optuna.

Core Algorithm:
    1. Dominant Cycle Estimation (`_auto_tune`):
       Applies a 3rd-order high-pass filter to remove low-frequency trends, then
       computes rolling autocorrelation to dynamically estimate the market's current
       dominant cycle period (in bars).
    2. Adaptive Bandpass Filtering (`_bandpass2`):
       Constructs a 2nd-order bandpass filter dynamically tuned to the estimated
       cycle period. This extracts cyclical momentum while suppressing non-cyclical
       drift and high-frequency noise.
    3. Signal Generation (`_run_backtest`):
       Triggers LONG/SHORT signals on 2-bar Rate-of-Change (ROC) crossovers of the
       bandpass output. Signals are gated by:
         - Cycle Strength: Minimum correlation threshol to ensure the detected cycle
           is statistically robust.
         - Baseline Alignment: Optional high-pass trend filter (above/below zero) to
           align signals with the underlying macro trend.
    4. Forward Evaluation:
       For every generated signal, the algorithm simulates forward performance over
       a configurable `--lookahead-bars` window, recording path-dependent min/max
       prices, terminal prices, and maximum achievable returns.
    5. Hyperparameter Optimization:
       Uses Optuna (TPE sampler + Median pruner) to search for optimal filter
       parameters (`window`, `bandwidth`, `threshold`, baseline toggles) that
       maximize a user-defined performance metric on a training set, with final
       validation on a held-out dataset.

The --optimize Flag: Metric Comparison
---------------------------------------
This flag defines the primary objective function for Optuna hyperparameter tuning.
Each metric evaluates trade success differently over the configured lookahead window,
using `--win-threshold` (`wt`) as the boundary/reference value:

  • profit_target (Direction-Agnostic)
    Measures the % of signals where the MAXIMUM forward return exceeds `wt`.
    Focus: Absolute profit magnitude. Ignores intra-trade drawdown and terminal price.
    NOTE: With negative wt, this becomes a lenient target (e.g., wt=-0.04 means
    "max return > -4%", which is easy to achieve).

  • range_bound (Direction-Agnostic)
    Measures the % of signals where price stays strictly within `[min(1-wt,1+wt), max(1-wt,1+wt)]`
    throughout the ENTIRE lookahead window.
    Focus: Volatility suppression & mean-reversion. Penalizes any breakout.
    NOTE: Negative wt values are now supported - the band bounds are automatically
    ordered to ensure lower <= upper.

  • hold_floor (Long-Focused)
    Measures the % of LONG signals where price NEVER drops below `1-wt` at any
    point during the lookahead window.
    Focus: Downside protection & stop-loss integrity. Upside is uncapped.
    NOTE: With negative wt, this becomes MORE aggressive (e.g., wt=-0.04 requires
    price to stay above 104% of entry - maintaining a minimum 4% gain).

  • hold_floor_half_B (Long-Focused)
    Measures the % of LONG signals where price NEVER drops below `1-wt` at any
    point during the SECOND HALF of the lookahead window (t + lookahead//2 to t + lookahead).
    Focus: Downside protection & stop-loss integrity during the latter half of the trade.
    NOTE: With negative wt, this becomes MORE aggressive (e.g., wt=-0.04 requires
    price to stay above 104% of entry in the second half - maintaining a minimum 4% gain).

  • hold_ceiling (Short-Focused)
    Measures the % of SHORT signals where price NEVER rises above `1+wt` during
    the lookahead window.
    Focus: Short-side risk containment & trend continuation safety.
    NOTE: With negative wt, this becomes MORE aggressive (e.g., wt=-0.04 requires
    price to stay below 96% of entry - maintaining a minimum 4% drop).

  • finish_above (Long-Focused)
    Measures the % of LONG signals where the price at the EXACT FINAL BAR of the
    lookahead window is above `1+wt`.
    Focus: Terminal momentum & breakout conviction. Allows intra-trade volatility.
    NOTE: With negative wt, this becomes a lenient target.

  • finish_below (Short-Focused)
    Measures the % of SHORT signals where the price at the EXACT FINAL BAR of the
    lookahead window is below `1-wt`.
    Focus: Terminal downside momentum & trend resolution.
    NOTE: With negative wt, this becomes a lenient target.

Key Distinctions:
  - Path-Dependent vs. Endpoint-Dependent: `hold_*`, `range_bound` evaluate price
    behavior across every bar. `finish_*` only evaluate the terminal price.
  - Directional Bias: The optimizer automatically sets `signal_type` to 1 (long),
    -1 (short), or 0 (both) based on your chosen metric.
  - Risk vs. Reward: `hold_*` and `range_bound` prioritize capital preservation.
    `profit_target` and `finish_*` prioritize directional conviction.
  - Negative Threshold Support: All metrics now properly handle negative win_threshold
    values, with semantics adjusted as noted above.

Usage Example:
    python autotune.py --dataset-id day --ticker ^GSPC --optimize hold_floor \
                       --lookahead-bars 10 --win-threshold -0.04 --n-trials 500 \
                       --storage sqlite:///optuna.db
"""
try:
    from version import sys__name, sys__version
except ImportError:
    import sys
    import pathlib

    current_dir = pathlib.Path(__file__).resolve()
    parent_dir = current_dir.parent.parent.parent
    sys.path.insert(0, str(parent_dir))
    from version import sys__name, sys__version
import argparse
import glob
import os
import pickle
import sys
from typing import Tuple, Dict
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np
import optuna
import pandas as pd
from numba import njit
from optuna.pruners import MedianPruner
from optuna.samplers import TPESampler
from sklearn.model_selection import TimeSeriesSplit
from utils import get_next_step, round_price_for_call_credit_spread, round_price_for_put_credit_spread, compute_break_even_credit
from fetchers.data_factory import factory_load_data

# =============================================================================
# 📊 CENTRAL METRIC MAPPING (Single Source of Truth)
# =============================================================================
METRIC_MAP = {
    'profit_target': {'col': 'forward_return_{}b', 'calc': lambda s, wt: (s > wt).mean()},
    'range_bound': {'col': 'stay_in_band_{}b', 'calc': lambda s, wt: s.mean()},
    'hold_floor': {'col': 'stay_above_lower_{}b', 'calc': lambda s, wt: s.mean()},
    'hold_floor_half_B': {'col': 'stay_above_lower_half_{}b', 'calc': lambda s, wt: s.mean()},
    'hold_ceiling': {'col': 'stay_below_upper_{}b', 'calc': lambda s, wt: s.mean()},
    'finish_above': {'col': 'above_upper_last_{}b', 'calc': lambda s, wt: s.mean()},
    'finish_below': {'col': 'below_lower_last_{}b', 'calc': lambda s, wt: s.mean()},
}


# =============================================================================
# 1. JIT-COMPILED CORE FUNCTIONS
# =============================================================================
@njit(cache=True)
def _highpass3(data: np.ndarray, period: int) -> np.ndarray:
    n = len(data)
    hp = np.zeros(n)
    if n < 4: return hp
    alpha = (1 - np.sin(2 * np.pi / period)) / (1 + np.sin(2 * np.pi / period))
    a1 = (1 - alpha / 2) ** 2
    b1 = 2 * (1 - alpha)
    b2 = -(1 - alpha) ** 2
    for i in range(3, n):
        hp[i] = a1 * (data[i] - 2 * data[i - 1] + data[i - 2]) + b1 * hp[i - 1] + b2 * hp[i - 2]
    return hp


@njit(cache=True)
def _bandpass2(data: np.ndarray, period: np.ndarray, bandwidth: float) -> np.ndarray:
    n = len(data)
    bp = np.zeros(n)
    bp_1, bp_2 = 0.0, 0.0
    for i in range(2, n):
        p = period[i]
        p = 4.0 if p < 4.0 else (100.0 if p > 100.0 else p)
        L1 = np.cos(2 * np.pi / p)
        G1 = np.cos(bandwidth * 2 * np.pi / p)
        if abs(G1) < 1e-10:
            G1 = 1e-10 if G1 >= 0 else -1e-10
        G1 = -0.99 if G1 < -0.99 else (0.99 if G1 > 0.99 else G1)
        disc = 1.0 / (G1 ** 2) - 1.0
        disc = 0.0 if disc < 0.0 else disc
        S1 = 1.0 / G1 - np.sqrt(disc)
        bp[i] = (0.5 * (1 - S1) * (data[i] - data[i - 2]) + L1 * (1 + S1) * bp_1 - S1 * bp_2)
        bp_2, bp_1 = bp_1, bp[i]
    return bp


@njit(cache=True)
def _auto_tune(data: np.ndarray, window: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    n = len(data)
    dc_series = np.zeros(n)
    min_corr_series = np.zeros(n)
    hp = _highpass3(data, window)
    dc_smooth = float(window)
    corr = np.zeros(window + 1)
    for i in range(window + 5, n):
        for lag in range(1, window + 1):
            Sx, Sy, Sxx, Syy, Sxy = 0.0, 0.0, 0.0, 0.0, 0.0
            seg_len = window - lag
            base = i - window
            for k in range(seg_len):
                x = hp[base + k];
                y = hp[base + k + lag]
                Sx += x;
                Sy += y;
                Sxx += x * x;
                Syy += y * y;
                Sxy += x * y
            den1 = seg_len * Sxx - Sx * Sx
            den2 = seg_len * Syy - Sy * Sy
            if den1 > 1e-10 and den2 > 1e-10:
                corr[lag] = (seg_len * Sxy - Sx * Sy) / np.sqrt(den1 * den2)
            else:
                corr[lag] = 0.0
        min_idx, min_val = 1, corr[1]
        for lag in range(2, window + 1):
            if corr[lag] < min_val: min_val = corr[lag]; min_idx = lag
        dc_raw = 2.0 * min_idx
        if dc_raw > dc_smooth + 2.0:
            dc_smooth += 2.0
        elif dc_raw < dc_smooth - 2.0:
            dc_smooth -= 2.0
        else:
            dc_smooth = dc_raw
        dc_series[i] = dc_smooth
        min_corr_series[i] = min_val
    return dc_series, min_corr_series, hp


@njit(cache=True)
def _run_backtest(prices: np.ndarray, dc_series: np.ndarray, min_corr_series: np.ndarray,
                  hp: np.ndarray, window: int, bandwidth: float, threshold: float,
                  lookahead_bars: int, win_threshold: float, signal_type: int,
                  enable_above_baseline: int, enable_below_baseline: int) -> Tuple:
    n = len(prices)
    bp = _bandpass2(prices, dc_series, bandwidth)
    roc = np.zeros(n)
    for i in range(2, n): roc[i] = bp[i] - bp[i - 2]
    signals = np.zeros(n)
    start_i = max(window + 10, 5)

    for i in range(start_i, n):
        long_cross = roc[i] > 0 >= roc[i - 1]
        short_cross = roc[i] < 0 <= roc[i - 1]
        strong_cycle = min_corr_series[i] < threshold
        above_baseline = hp[i] > 0 if enable_above_baseline else True
        below_baseline = hp[i] < 0 if enable_below_baseline else True

        if signal_type == 1:
            if long_cross and strong_cycle and above_baseline: signals[i] = 1.0
        elif signal_type == -1:
            if short_cross and strong_cycle and below_baseline: signals[i] = -1.0
        else:  # signal_type == 0 (both)
            if long_cross and strong_cycle and above_baseline:
                signals[i] = 1.0
            elif short_cross and strong_cycle and below_baseline:
                signals[i] = -1.0

    forward_returns = np.zeros(n)
    within_bound = np.zeros(n)
    within_lower = np.zeros(n)
    within_upper = np.zeros(n)
    above_upper_last = np.zeros(n)
    below_lower_last = np.zeros(n)
    within_lower_half = np.zeros(n)

    for i in range(n):
        if signals[i] != 0.0:
            if i + lookahead_bars >= n: continue
            end = i + lookahead_bars + 1
            last_idx = end - 1

            best_ret = -np.inf
            has_valid_bar = False
            for j in range(i + 1, end):
                ret = (prices[j] / prices[i] - 1.0) * signals[i]
                if ret > best_ret: best_ret = ret
                has_valid_bar = True
            forward_returns[i] = best_ret if has_valid_bar else 0.0

            min_p = prices[i];
            max_p = prices[i]
            for j in range(i + 1, end):
                if prices[j] < min_p: min_p = prices[j]
                if prices[j] > max_p: max_p = prices[j]

            # FIXED: Handle negative win_threshold by ensuring bounds are properly ordered
            lower_bound = prices[i] * (1.0 - win_threshold)
            upper_bound = prices[i] * (1.0 + win_threshold)
            if lower_bound > upper_bound:
                lower_bound, upper_bound = upper_bound, lower_bound
            within_bound[i] = 1.0 if (min_p >= lower_bound and max_p <= upper_bound) else 0.0

            min_p = prices[i]
            for j in range(i + 1, end):
                if prices[j] < min_p: min_p = prices[j]
            within_lower[i] = 1.0 if min_p >= prices[i] * (1.0 - win_threshold) else 0.0

            max_p = prices[i]
            for j in range(i + 1, end):
                if prices[j] > max_p: max_p = prices[j]
            within_upper[i] = 1.0 if max_p <= prices[i] * (1.0 + win_threshold) else 0.0

            above_upper_last[i] = 1.0 if prices[last_idx] > prices[i] * (1.0 + win_threshold) else 0.0
            below_lower_last[i] = 1.0 if prices[last_idx] < prices[i] * (1.0 - win_threshold) else 0.0

            min_p_half = prices[i + lookahead_bars // 2]
            for j in range(i + lookahead_bars // 2 + 1, end):
                if prices[j] < min_p_half: min_p_half = prices[j]
            within_lower_half[i] = 1.0 if min_p_half >= prices[i] * (1.0 - win_threshold) else 0.0

    return signals, None, None, forward_returns, within_bound, within_lower, within_upper, bp, roc, above_upper_last, below_lower_last, within_lower_half


# =============================================================================
# 2. CLASS WRAPPER
# =============================================================================
class AutoTuneStrategy:
    def __init__(self, window: int, bandwidth: float, threshold: float,
                 lookahead_bars: int, win_threshold: float, signal_type: int,
                 enable_above_baseline: int, enable_below_baseline: int):
        self.window = window
        self.bandwidth = bandwidth
        self.threshold = threshold
        self.lookahead_bars = lookahead_bars
        self.win_threshold = win_threshold
        self.signal_type = signal_type
        self.enable_above_baseline = enable_above_baseline
        self.enable_below_baseline = enable_below_baseline

    def generate_signals(self, prices) -> pd.DataFrame:
        prices = np.asarray(prices, dtype=np.float64)
        dc_series, min_corr_series, hp = _auto_tune(data=prices, window=self.window)
        sig, _, _, fwd, wr2, wr3, wr4, bp, roc, wr5, wr6, wr7 = _run_backtest(
            prices=prices, dc_series=dc_series, min_corr_series=min_corr_series, hp=hp,
            window=self.window, bandwidth=self.bandwidth, threshold=self.threshold,
            win_threshold=self.win_threshold, lookahead_bars=self.lookahead_bars,
            signal_type=self.signal_type, enable_below_baseline=self.enable_below_baseline,
            enable_above_baseline=self.enable_above_baseline
        )
        LA = self.lookahead_bars
        return pd.DataFrame({
            'price': prices, 'dominant_cycle': dc_series, 'bandpass': bp, 'roc': roc,
            'min_correlation': min_corr_series, 'highpass': hp, 'signal': sig,
            f'forward_return_{LA}b': fwd,
            f'stay_in_band_{LA}b': wr2,
            f'stay_above_lower_{LA}b': wr3,
            f'stay_below_upper_{LA}b': wr4,
            f'above_upper_last_{LA}b': wr5,
            f'below_lower_last_{LA}b': wr6,
            f'stay_above_lower_half_{LA}b': wr7
        })

    def evaluate(self, results: pd.DataFrame) -> Dict:
        df = results.copy()
        LA = self.lookahead_bars
        fwd_col = f'forward_return_{LA}b'
        wr2_col = f'stay_in_band_{LA}b'
        wr3_col = f'stay_above_lower_{LA}b'
        wr4_col = f'stay_below_upper_{LA}b'
        wr5_col = f'above_upper_last_{LA}b'
        wr6_col = f'below_lower_last_{LA}b'
        wr7_col = f'stay_above_lower_half_{LA}b'

        signals = df[df['signal'] != 0].copy()
        label = 'long' if self.signal_type == 1 else ('short' if self.signal_type == -1 else 'both')

        total_signals = len(signals)
        if total_signals == 0:
            return {'status': f'No {label} signals generated in evaluation period'}

        profit_target = (signals[fwd_col].values > self.win_threshold).mean()
        range_bound = signals[wr2_col].values.mean()
        hold_floor = signals[wr3_col].values.mean()
        hold_ceiling = signals[wr4_col].values.mean()
        finish_above = signals[wr5_col].values.mean()
        finish_below = signals[wr6_col].values.mean()
        hold_floor_half_B = signals[wr7_col].values.mean()

        return {
            'total_signals': total_signals,
            'signal_type': label,
            f'profit_target_{label}_{LA}b': f"{profit_target * 100:.1f}%",
            f'range_bound_{label}_{LA}b': f"{range_bound * 100:.1f}%",
            f'hold_floor_{label}_{LA}b': f"{hold_floor * 100:.1f}%",
            f'hold_ceiling_{label}_{LA}b': f"{hold_ceiling * 100:.1f}%",
            f'finish_above_{label}_{LA}b': f"{finish_above * 100:.1f}%",
            f'finish_below_{label}_{LA}b': f"{finish_below * 100:.1f}%",
            f'hold_floor_half_B_{label}_{LA}b': f"{hold_floor_half_B * 100:.1f}%",
            f'expectancy_{label}_{LA}b': f"{signals[fwd_col].mean() * 100:.3f}%",
        }


# =============================================================================
# 3. ARGUMENT PARSER
# =============================================================================
def setup_argparse() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="AutoTune Strategy: Cycle-aware trading algorithm with Optuna hyperparameter optimization.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    data_group = parser.add_argument_group('Data & Symbol')
    data_group.add_argument('--dataset-id', type=str, default='day')
    data_group.add_argument('--ticker', type=str, default='^GSPC')
    data_group.add_argument("--clip-n", type=int, default=0, help="Number of most recent bars to clip from the dataset.")

    strat_group = parser.add_argument_group('Strategy Parameters')
    strat_group.add_argument('--lookahead-bars', type=int, default=10)
    strat_group.add_argument('--win-threshold', type=float, default=0.02,
                             help="Win threshold for optimization metrics. Can be negative for aggressive targets.")
    strat_group.add_argument('--min-signal-density', type=float, default=0.02)

    opt_group = parser.add_argument_group('Optimization & Execution')
    opt_group.add_argument('--train-ratio', type=float, default=0.8)
    opt_group.add_argument('--optimize', type=str, choices=list(METRIC_MAP.keys()), default='hold_floor')
    opt_group.add_argument('--n-trials', type=int, default=999)
    opt_group.add_argument('--n-split', type=int, default=20)
    opt_group.add_argument('--alpha', type=float, default=1.)
    opt_group.add_argument('--timeout', type=int, default=300)
    opt_group.add_argument('--output-dir', type=str, default='models')
    opt_group.add_argument('--storage', type=str, default=None,
                           help='Optuna storage URL (e.g., sqlite:///optuna.db). Default: in-memory.')
    opt_group.add_argument('--study-name', type=str, default=None,
                           help='Optuna study name. Auto-generated if --storage is provided but name is omitted.')

    flag_group = parser.add_argument_group('Execution Flags')
    flag_group.add_argument('--real-time', action=argparse.BooleanOptionalAction, default=False)
    flag_group.add_argument('--realtime', action=argparse.BooleanOptionalAction, default=False)
    flag_group.add_argument('--model-path', type=str, default=None)
    flag_group.add_argument('--modelpath', type=str, default=None)
    flag_group.add_argument('--verbose', action=argparse.BooleanOptionalAction, default=False)
    flag_group.add_argument('--verbose-short', action=argparse.BooleanOptionalAction, default=False)
    flag_group.add_argument('--verbose-study-progress-bar', action=argparse.BooleanOptionalAction, default=False, help='Verbose output')
    flag_group.add_argument('--plot', action=argparse.BooleanOptionalAction, default=False)
    return parser


def perfect_score_callback(study, trial):
    if study.best_value is not None and study.best_value >= 0.9999:
        print("\n🎯 Perfect score reached (≥ 0.9999). Stopping optimization early.")
        study.stop()


# =============================================================================
# 4. ENTRY POINT
# =============================================================================
def entry(args):
    optuna.logging.set_verbosity(optuna.logging.WARNING)
    verbose = args.verbose
    verbose_short = getattr(args, "verbose_short", False)
    real_time = getattr(args, "realtime", getattr(args, "real_time", None))
    np.random.seed(42)

    # =============================================================================
    # 🔄 REAL-TIME MODE
    # =============================================================================
    if real_time:
        # Récupère le premier qui existe, ou None si aucun n'est présent
        model_path = getattr(args, "modelpath", None) or getattr(args, "model_path", None)
        if not model_path or not os.path.exists(str(model_path)):
            raise FileNotFoundError("Le chemin du modèle est introuvable ou invalide.")
        if not os.path.exists(model_path):
            raise FileNotFoundError(f"Specified model not found: {model_path}")
        if verbose and not verbose_short:
            print(f"📥 Loading specified real-time model: {model_path}")

        with open(model_path, 'rb') as f:
            saved_model = pickle.load(f)

        command_line = saved_model.get("command_line", "")
        if verbose:
            print(f"Command line used: {command_line}")

        rt_params = saved_model['params']
        rt_win_threshold = saved_model['win_threshold']

        # Utiliser le code entier (1, -1, 0) pour la logique, pas le label texte
        rt_signal_type_code = saved_model.get('signal_type_code', 0)
        rt_signal_type_label = saved_model.get('signal_type', 'both')

        strat_rt = AutoTuneStrategy(
            **rt_params,
            win_threshold=rt_win_threshold,
            signal_type=rt_signal_type_code  # Passe l'entier attendu par _run_backtest
        )

        dataset_id = saved_model['dataset_id']
        ticker = saved_model['ticker']
        spx = factory_load_data(_dataset_id=dataset_id, _ticker=ticker, _args={"clip_n": args.clip_n, "realtime": getattr(args, "use_realtime_data", True)})

        if verbose:
            first_date = spx.index[0]
            last_date = spx.index[-1]
            num_bars = len(spx)
            print(f"\n📊 Dataset Loaded: {ticker} ({dataset_id})")
            print(f"   Bars: {num_bars:,} | Range: {first_date.strftime('%Y%m%d_%H%M')}  ->  {last_date.strftime('%Y%m%d_%H%M')}\n")

        close_col = ('Close', ticker)
        closes = spx[close_col].squeeze().dropna().copy()
        results_rt = strat_rt.generate_signals(closes)
        last_row = results_rt.iloc[-1]
        last_signal = last_row['signal']

        if 'ticker' in saved_model and ticker != saved_model['ticker']:
            raise ValueError(f"Ticker mismatch: CLI={ticker}, Model={saved_model['ticker']}")

        last_price = last_row['price']
        last_date_str = closes.index[-1].strftime('%Y-%m-%d')
        la_date = get_next_step(the_date=closes.index[-1], dataset_id=saved_model['dataset_id'], nn=saved_model['params']['lookahead_bars']).strftime('%Y-%m-%d')
        opt_metric = saved_model['optimize_metric']
        test_win_rate = saved_model['val_score']
        la_bars = saved_model['params']['lookahead_bars']

        # Évaluation du signal basée sur les entiers (1, -1, 0)
        signal = 0
        if last_signal == 1.0 and rt_signal_type_code in (1, 0):
            signal = 1
        elif last_signal == -1.0 and rt_signal_type_code in (-1, 0):
            signal = -1

        signal_str = "🟢 LONG" if signal == 1 else ("🔴 SHORT" if signal == -1 else "⚪ NONE")

        if verbose:
            print(f"Dataset: {dataset_id} | Look Ahead: {la_bars} bars")
            print(f"Training score: {saved_model['train_score']:.6%} | Test score: {test_win_rate:.6%}")
            print(f"Training win rate: {saved_model['train_win_rate']:.6%} | Test win rate: {saved_model['validation_win_rate']:.6%}")
            train_density, test_density = saved_model.get('train_trade_density', 0), saved_model.get('test_trade_density', 0)
            print(f"Training density: {train_density:.6%} | Test density: {test_density:.6%}")
            print(f"Optimization metric: {opt_metric} | Win Threshold: {rt_win_threshold:.2%} | Signal Type: {rt_signal_type_label}")
            print(f"Datapoint used: {last_date_str} | Signal computed: {last_signal} {signal_str}")

        target_price = 0.0
        abs_wt = abs(rt_win_threshold)

        # Calcul du prix cible (strike) selon la métrique
        if signal == 1:
            if opt_metric in ['hold_floor', 'hold_floor_half_B']:
                target_price = last_price * (1.0 - rt_win_threshold)
            elif opt_metric == 'finish_above':
                target_price = last_price * (1.0 + rt_win_threshold)
            elif opt_metric == 'profit_target':
                target_price = last_price * (1.0 + abs_wt)
            elif opt_metric == 'range_bound':
                target_price = last_price * (1.0 + abs_wt)  # Borne supérieure par défaut pour l'affichage
        elif signal == -1:
            if opt_metric == 'hold_ceiling':
                target_price = last_price * (1.0 + rt_win_threshold)
            elif opt_metric == 'finish_below':
                target_price = last_price * (1.0 - rt_win_threshold)
            elif opt_metric == 'profit_target':
                target_price = last_price * (1.0 - abs_wt)
            elif opt_metric == 'range_bound':
                target_price = last_price * (1.0 - abs_wt)  # Borne inférieure par défaut pour l'affichage

        # Invalidation du signal si la logique ne correspond pas à la métrique d'optimisation
        if last_signal != 0:
            is_valid = False
            if opt_metric in ['hold_floor', 'finish_above', 'hold_floor_half_B']:
                if signal == 1 and rt_signal_type_code in (1, 0):
                    is_valid = True
            elif opt_metric in ['hold_ceiling', 'finish_below']:
                if signal == -1 and rt_signal_type_code in (-1, 0):
                    is_valid = True
            elif opt_metric in ['profit_target', 'range_bound']:
                if rt_signal_type_code == 0 or (signal == 1 and rt_signal_type_code == 1) or (signal == -1 and rt_signal_type_code == -1):
                    is_valid = True

            if not is_valid:
                last_signal = 0.0
                signal = 0
                signal_str = "⚪ NONE (Invalidated)"
                target_price = 0.0

        # =====================================================================
        # 🆕 GÉNÉRATION DU MESSAGE EXPLICATIF (STATUS MESSAGE)
        # =====================================================================
        if signal == 0:
            status_message = "⚪ NEUTRE : Aucun thread actif. En attente d'une configuration de marché valide."
        else:
            direction = "ACHAT" if signal == 1 else "VENTE"
            emoji = "🟢" if signal == 1 else "🔴"

            # Définition précise de l'objectif selon la métrique d'optimisation
            if opt_metric == 'hold_floor':
                action = f"maintenir le prix au-dessus du seuil de {round_price_for_put_credit_spread(target_price):.0f}"
            elif opt_metric == 'hold_floor_half_B':
                action = f"maintenir le prix au-dessus du seuil de {round_price_for_put_credit_spread(target_price):.0f} durant la seconde moitié de la période"
            elif opt_metric == 'hold_ceiling':
                action = f"maintenir le prix en dessous du seuil de {round_price_for_call_credit_spread(target_price):.0f}"
            elif opt_metric == 'finish_above':
                action = f"clôturer au-dessus du seuil de {round_price_for_put_credit_spread(target_price):.0f}"
            elif opt_metric == 'finish_below':
                action = f"clôturer en dessous du seuil de {round_price_for_call_credit_spread(target_price):.0f}"
            elif opt_metric == 'profit_target':
                action = f"atteindre un rendement maximum supérieur au seuil (cible indicative: {target_price:.2f})"
            elif opt_metric == 'range_bound':
                band_low = last_price * (1.0 - abs_wt)
                band_high = last_price * (1.0 + abs_wt)
                action = f"maintenir le prix strictement à l'intérieur de la bande [{band_low:.2f}, {band_high:.2f}]"
            else:
                action = f"atteindre l'objectif défini par (cible: {target_price:.2f})"
            break_even = compute_break_even_credit(test_win_rate, 500)
            status_message = (
                f"{emoji} {direction} : "
                f"Objectif de {action} ({abs_wt:.2%}) "
                f"d'ici l'expiration prévue le {la_date} "
                f"({la_bars} barres). "
                f"Test Win Rate : {test_win_rate:.2%}. "
                f"Break Even : {break_even:.2f}$"
            )

        # Calcul du multiplicateur pour compatibilité descendante
        optimization_metric, method = "buy_wr", "final_close"
        if opt_metric in ["hold_ceiling", "finish_below"]:
            optimization_metric = "sell_wr"
        elif opt_metric == "profit_target":
            optimization_metric = "buy_wr" if signal == 1 else "sell_wr"
        elif opt_metric == "range_bound":
            optimization_metric = "range_wr"

        if optimization_metric == "buy_wr":
            threshold_multiplier = 1.0 - rt_win_threshold
        elif optimization_metric == "sell_wr":
            threshold_multiplier = 1.0 + rt_win_threshold
        else:
            threshold_multiplier = 1.0  # Neutre

        # =====================================================================
        # RETOUR DU DICTIONNAIRE ENRICHI
        # =====================================================================
        return {
            'current_price': last_price,
            'current_date': last_date_str,
            'train_score': saved_model['train_score'],
            'val_score': test_win_rate,
            'threshold': threshold_multiplier,
            'raw_win_threshold': rt_win_threshold,
            'signal_type': rt_signal_type_label,
            'signal_type_code': rt_signal_type_code,
            'dataset_id': dataset_id,
            'ticker': ticker,
            'optimization_metric': optimization_metric,
            'train_win_rate': saved_model['train_win_rate'],
            'val_win_rate': saved_model['validation_win_rate'],
            'method': method,
            'target_date': la_date,
            'signal': signal,
            'target_price': target_price,
            'lookahead': la_bars,
            'status_message': status_message  # 🆕 NOUVEAU : Chaîne explicative prête à l'emploi
        }

    optimize = args.optimize
    os.makedirs(args.output_dir, exist_ok=True)
    command_line = "python " + " ".join(sys.argv)
    dataset_id, ticker = args.dataset_id, args.ticker
    spx = factory_load_data(_dataset_id=dataset_id, _ticker=ticker, _args={"clip_n": args.clip_n})
    if verbose:
        first_date = spx.index[0]
        last_date = spx.index[-1]
        num_bars = len(spx)
        print(f"\n📊 Dataset Loaded: {ticker} ({dataset_id})")
        print(f"   Bars: {num_bars:,} | Range: {first_date.strftime('%Y%m%d_%H%M')}  ->  {last_date.strftime('%Y%m%d_%H%M')}\n")
    close_col = ('Close', ticker)
    closes = spx[close_col].squeeze().dropna().copy()
    if verbose:
        print(__doc__)
    # =============================================================================
    # 🎯 OPTIMIZATION MODE
    # =============================================================================
    train_ratio = args.train_ratio
    assert 0.0 < train_ratio < 1.0, "--train-ratio must be between 0.0 and 1.0"
    split_idx = int(len(closes) * train_ratio)
    train_closes = closes.iloc[:split_idx].copy()
    test_closes  = closes.iloc[split_idx:].copy()

    if verbose:
        print(f"📊 Train/Test Split: {train_ratio:.0%} / {1 - train_ratio:.0%}")
        print(f"   Train: {len(train_closes)} bars ({train_closes.index[0].strftime('%Y%m%d_%H%M')}::{train_closes.index[-1].strftime('%Y%m%d_%H%M')}) | "
              f"Test: {len(test_closes)} bars ({test_closes.index[0].strftime('%Y%m%d_%H%M')}::{test_closes.index[-1].strftime('%Y%m%d_%H%M')})\n")

    lookahead_bars = args.lookahead_bars
    win_threshold = args.win_threshold
    # Allow negative win_threshold values
    assert -1 < win_threshold < 1, "--win-threshold must be between -1.0 and 1.0 (exclusive)"
    n_trials = args.n_trials
    timeout = args.timeout
    required_signal_density = args.min_signal_density
    n_split = getattr(args, "n_split", 20)
    alpha   = getattr(args, "alpha", 1.)
    METRIC_TO_SIGNAL_TYPE = {
        'hold_floor': 1, 'finish_above': 1, 'hold_floor_half_B': 1,
        'hold_ceiling': -1, 'finish_below': -1,
        'profit_target': 0, 'range_bound': 0
    }
    signal_type = METRIC_TO_SIGNAL_TYPE.get(optimize, 0)
    signal_label = {1: 'long', -1: 'short', 0: 'both'}[signal_type]

    # 🔧 OPTIMIZATION SETUP
    window_min, window_max, window_step = 2, 160, 1
    bandwidth_min, bandwidth_max, bandwidth_step = 0.00015, 0.99015, 0.01
    threshold_min, threshold_max, threshold_step = -0.9996, -0.0096, 0.01

    if verbose:
        print(f"\n🔧 Running AutoTune Strategy with Optuna Optimization  |  Optimize: {optimize} ({signal_label})  |  Look Ahead: {lookahead_bars}b  |  Dataset id: {dataset_id}  |  "
              f"Win Threshold: {win_threshold:.4%}  |  Optuna: {n_trials}/{timeout}  |  Dataset Length: {len(closes)}  |  Minimum Signal Density: {required_signal_density}")

    def objective(trial):
        try:
            window = trial.suggest_int('window', window_min, window_max, step=window_step)
            bandwidth = trial.suggest_float('bandwidth', bandwidth_min, bandwidth_max, step=bandwidth_step)
            threshold = trial.suggest_float('threshold', threshold_min, threshold_max, step=threshold_step)
            _lookahead_bars = trial.suggest_int('lookahead_bars', lookahead_bars, lookahead_bars)
            if signal_type == 1:
                enable_above_baseline = trial.suggest_int('enable_above_baseline', 0, 1)
                enable_below_baseline = trial.suggest_int('enable_below_baseline', 0, 0)  # irrelevant: long-only
            elif signal_type == -1:
                enable_above_baseline = trial.suggest_int('enable_above_baseline', 0, 0)  # irrelevant: short-only
                enable_below_baseline = trial.suggest_int('enable_below_baseline', 0, 1)
            else:  # signal_type == 0, both matter
                enable_above_baseline = trial.suggest_int('enable_above_baseline', 0, 1)
                enable_below_baseline = trial.suggest_int('enable_below_baseline', 0, 1)

            strat = AutoTuneStrategy(
                window=window, bandwidth=bandwidth, threshold=threshold,
                lookahead_bars=_lookahead_bars, win_threshold=win_threshold,
                signal_type=signal_type, enable_above_baseline=enable_above_baseline, enable_below_baseline=enable_below_baseline,
            )

            # Generate signals for the entire training set once (filters are strictly causal)
            results = strat.generate_signals(train_closes.copy())
            df = results.copy()

            # 🆕 Apply TimeSeriesSplit for cross-validation
            tscv = TimeSeriesSplit(n_splits=n_split)
            col_fmt = METRIC_MAP[optimize]['col'].format(_lookahead_bars)

            fold_scores = []
            for _, test_idx in tscv.split(train_closes):
                # Slice the results for the current test fold
                fold_df = df.iloc[test_idx]
                fold_signals = fold_df[fold_df['signal'] != 0].copy()

                # 🛡️ Prevent data leakage across CV folds
                max_allowed_idx = max(test_idx)
                valid_mask = fold_signals.index + _lookahead_bars <= max_allowed_idx
                fold_signals = fold_signals[valid_mask]

                n_signals = len(fold_signals)
                if n_signals == 0:
                    fold_scores.append(0.0)
                    continue

                # ✅ DYNAMICALLY SELECT CORRECT COLUMN & METRIC BASED ON OPTIMIZE
                obj = METRIC_MAP[optimize]['calc'](fold_signals[col_fmt].values, win_threshold)

                signal_density = n_signals / len(fold_df)
                if signal_density < required_signal_density:
                    gap = required_signal_density - signal_density
                    penalty = max(0.0, 1.0 - gap * 5.0)
                    fold_scores.append(obj * penalty)
                else:
                    fold_scores.append(obj)

            final_score = np.mean(fold_scores) - (alpha * np.std(fold_scores))
            return float(final_score)

        except Exception as e:
            print(f"[WARNING] Trial failed: {e}")
            return 0.0

    # 🗄️ OPTUNA PERSISTENCE SETUP
    storage = args.storage
    study_name = args.study_name
    load_if_exists = False

    if storage:
        load_if_exists = True
        if not study_name:
            study_name = f"autotune_{ticker}_{dataset_id}_{optimize}"

    sampler = TPESampler(seed=42)
    pruner = MedianPruner(n_startup_trials=99, n_warmup_steps=0)

    study = optuna.create_study(
        study_name=study_name,
        storage=storage,
        direction='maximize',
        sampler=sampler,
        pruner=pruner,
        load_if_exists=load_if_exists
    )

    # 📊 OUTPUT BEST PARAMS IF AVAILABLE BEFORE OPTIMIZATION
    if len(study.trials) > 0 and study.best_value is not None:
        print(f"\n📂 Resuming existing study '{study_name}' ({len(study.trials)} trials found).")
        print(f"   🎯 Best Objective So Far: {study.best_value * 100:.2f}%")
        print(f"   ⚙️ Best Parameters    : {study.best_params}")
    elif len(study.trials) > 0:
        print(f"\n📂 Resuming existing study '{study_name}' ({len(study.trials)} trials found, but no successful trials yet).")
    else:
        if verbose: print(f"\n📂 Starting new Optuna study '{study_name or 'in-memory'}'.")

    if verbose: print(f"\n⚙️ Running Optuna search ({n_trials} trials, {timeout}s timeout) on TRAINING SET...")
    study.optimize(objective, n_trials=n_trials, show_progress_bar=args.verbose_study_progress_bar, gc_after_trial=True, timeout=timeout, callbacks=[perfect_score_callback])

    if verbose:
        print(f"\n✅ Best Trial Completed (Training Set):")
        print(f"   🎯 Objective Value: {study.best_trial.value * 100:.2f}%")
        print(f"   ⚙️ Parameters     : {study.best_trial.params}")

    score_of_best_trial = study.best_trial.value
    best_params = study.best_trial.params

    # 🟢 EVALUATE BEST PARAMS ON TRAINING & VALIDATION SETS
    strat_best = AutoTuneStrategy(**best_params, win_threshold=win_threshold, signal_type=signal_type)
    la = strat_best.lookahead_bars

    # --- Training Set Evaluation ---
    results_train = strat_best.generate_signals(train_closes)
    sig_train = results_train[results_train['signal'] != 0]
    train_win_rate = 0.
    train_score = score_of_best_trial  # Default to Optuna's returned score
    signal_density_train = 0.0

    if len(sig_train) > 0:
        col_fmt_train = METRIC_MAP[optimize]['col'].format(la)
        train_win_rate = METRIC_MAP[optimize]['calc'](sig_train[col_fmt_train].values, win_threshold)
        # Recalculate exact train_score with penalty to be perfectly accurate
        signal_density_train = len(sig_train) / len(results_train)
        if signal_density_train < required_signal_density:
            gap = required_signal_density - signal_density_train
            penalty = max(0.0, 1.0 - gap * 5.0)
            train_score = train_win_rate * penalty
        else:
            train_score = train_win_rate

    # --- Test Set Evaluation ---
    results_valid = strat_best.generate_signals(test_closes)
    sig_valid = results_valid[results_valid['signal'] != 0]
    test_win_rate = 0.
    test_score = 0.
    signal_density_test = 0.0

    if len(sig_valid) > 0:
        col_fmt_val = METRIC_MAP[optimize]['col'].format(la)
        test_win_rate = METRIC_MAP[optimize]['calc'](sig_valid[col_fmt_val].values, win_threshold)
        signal_density_test = len(sig_valid) / len(results_valid)
        if signal_density_test < required_signal_density:
            gap = required_signal_density - signal_density_test
            penalty = max(0.0, 1.0 - gap * 5.0)
            test_score = test_win_rate * penalty
        else:
            test_score = test_win_rate

        if verbose:
            print("\n📊 Final Performance (TEST SET):")
            print(f"   🎯 Win Rate ({optimize}): {test_win_rate * 100:.2f}%")
            print(f"   📉 Penalized Score: {test_score * 100:.2f}%")
            print(f"   📈 Trade Density: {signal_density_test:.4f} ({len(sig_valid)} trades / {len(results_valid)} bars)")
    else:
        if verbose:
            print("\n📊 Final Performance (TEST SET):")
            print("   🎯 Win Rate: N/A (0 signals generated)")
            print(f"   📈 Trade Density: {signal_density_test:.4f} (0 trades / {len(results_valid)} bars)")

    # 💾 SAVE MODEL
    os.makedirs(args.output_dir, exist_ok=True)
    w, bw, th, la, op = best_params['window'], best_params['bandwidth'], best_params['threshold'], best_params['lookahead_bars'], optimize
    model_name = f"autotune__la{la}__op{op}__wth{win_threshold}__trainsc{score_of_best_trial:.4f}__trainwr{train_win_rate:.4f}__twr{test_win_rate:.4f}.pkl"
    model_path = os.path.join(args.output_dir, model_name)

    model_data = {
        'params': best_params, 'win_threshold': win_threshold, 'signal_type': signal_label,
        'signal_type_code': signal_type, 'optimize_metric': optimize,
        'train_score': train_score, 'val_score': test_score, 'test_score': test_score,
        'train_win_rate': train_win_rate, 'validation_win_rate': test_win_rate,
        'dataset_id': dataset_id, 'ticker': ticker, 'command_line': command_line,
        'train_trade_density': signal_density_train,
        'test_trade_density': signal_density_test,
        'train_trades_count': len(sig_train) if len(sig_train) > 0 else 0,
        'test_trades_count': len(sig_valid) if len(sig_valid) > 0 else 0,
    }
    with open(model_path, 'wb') as f:
        pickle.dump(model_data, f)

    if verbose: print(f"\n💾 Model saved to: {model_path}")

    if args.plot:
        final_metrics = strat_best.evaluate(results_valid)
        plot_strategy_results(
            results=results_valid, params=best_params, metrics=final_metrics,
            ticker=ticker, dataset_id=dataset_id, output_dir=args.output_dir,
            verbose=verbose, signal_type=signal_label, optimize_metric=optimize,
            win_threshold=win_threshold, test_win_rate=test_win_rate,
        )


# =============================================================================
# 🆕 PLOTTING FUNCTION
# =============================================================================
def plot_strategy_results(results: pd.DataFrame, params: dict, metrics: dict,
                          ticker: str, dataset_id: str, output_dir: str = '.',
                          verbose: bool = True, signal_type: str = 'both',
                          optimize_metric: str = 'profit_target', win_threshold: float = 0.04,
                          test_win_rate: float = 0.0) -> str:
    try:
        plt.style.use('seaborn-v0_8-darkgrid')
    except:
        pass

    df = results.copy()
    dates = df.index
    LA = params.get('lookahead_bars', 10)

    signals = df[df['signal'] != 0]
    long_signals = signals[signals['signal'] > 0]
    short_signals = signals[signals['signal'] < 0]

    def classify(df_sig, metric, la, thresh):
        if len(df_sig) == 0: return pd.DataFrame(), pd.DataFrame()
        # ✅ USES CENTRAL METRIC_MAP FOR CONSISTENCY
        col = METRIC_MAP[metric]['col'].format(la)
        if metric == 'profit_target':
            return df_sig[df_sig[col] > thresh], df_sig[df_sig[col] <= thresh]
        return df_sig[df_sig[col] >= 0.99], df_sig[df_sig[col] < 0.99]

    long_success, long_fail = classify(long_signals, optimize_metric, LA, win_threshold)
    short_success, short_fail = classify(short_signals, optimize_metric, LA, win_threshold)

    fig = plt.figure(figsize=(16, 10))
    fig.suptitle(f'AutoTune Strategy Results - {ticker} ({dataset_id}) | Signal Type: {signal_type.upper()}\n'
                 f'Optimized for: {optimize_metric.upper()} @ {win_threshold:.4%} threshold',
                 fontsize=15, fontweight='bold', y=0.995)

    gs = fig.add_gridspec(2, 2, height_ratios=[2.2, 1], hspace=0.3, wspace=0.25)
    ax1 = fig.add_subplot(gs[0, :])
    ax1.plot(dates, df['price'], label='Price', linewidth=1.5, color='steelblue', zorder=1)

    marker_kwargs = dict(s=110, zorder=5, edgecolors='black', linewidths=0.8, alpha=0.85)
    if len(long_success) > 0: ax1.scatter(long_success.index, long_success['price'], marker='o', color='limegreen', label=f'Long ({optimize_metric} Success)', **marker_kwargs)
    if len(long_fail) > 0: ax1.scatter(long_fail.index, long_fail['price'], marker='s', color='crimson', label=f'Long ({optimize_metric} Fail)', **marker_kwargs)
    if len(short_success) > 0: ax1.scatter(short_success.index, short_success['price'], marker='o', color='limegreen', label=f'Short ({optimize_metric} Success)', **marker_kwargs)
    if len(short_fail) > 0: ax1.scatter(short_fail.index, short_fail['price'], marker='s', color='crimson', label=f'Short ({optimize_metric} Fail)', **marker_kwargs)

    ax1.set_ylabel('Price', fontweight='bold')
    ax1.set_title('Price Action with Trading Signals', fontweight='bold')
    ax1.legend(loc='upper left', fontsize=9)
    ax1.grid(True, alpha=0.3)

    if hasattr(dates[0], 'year') or hasattr(dates, 'strftime'):
        ax1.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))
        ax1.xaxis.set_major_locator(mdates.MonthLocator(interval=3))
        plt.setp(ax1.xaxis.get_majorticklabels(), rotation=45, ha='right')

    ax2 = fig.add_subplot(gs[1, 0], sharex=ax1)
    ax2.plot(dates, df['bandpass'], label='Bandpass', linewidth=1, color='purple')
    ax2.axhline(y=0, color='gray', linestyle='--', linewidth=0.5)
    ax2.set_ylabel('Bandpass', fontweight='bold')
    ax2.set_title('Bandpass Filter Output', fontweight='bold')
    ax2.grid(True, alpha=0.3)

    ax3 = fig.add_subplot(gs[1, 1], sharex=ax1)
    ax3.plot(dates, df['roc'], label='ROC (2-bar)', linewidth=1, color='orange')
    ax3.axhline(y=0, color='gray', linestyle='--', linewidth=0.5)
    ax3.set_ylabel('ROC', fontweight='bold')
    ax3.set_title('Rate of Change (Momentum)', fontweight='bold')
    ax3.grid(True, alpha=0.3)

    n_long_win = len(long_success);
    n_long_fail = len(long_fail)
    n_short_win = len(short_success);
    n_short_fail = len(short_fail)
    total_signals = len(signals)
    plot_success_rate = (n_long_win + n_short_win) / total_signals if total_signals > 0 else 0.0

    metrics_text = (f"Optimized Metric: {optimize_metric.upper()}\n"
                    f"Win Threshold: {win_threshold:.2%} | Lookahead: {LA} bars\n\n"
                    f"Test Win Rate: {test_win_rate:.2%}\n\n"
                    f"Performance:\n")
    metrics_text += (f"\n📊 Visual Classification (per {optimize_metric}):\n"
                     f"  Success: {n_long_win + n_short_win} | Fail: {n_long_fail + n_short_fail}\n"
                     f"  Plotted Rate: {plot_success_rate:.2%} (should match best trial score)")

    props = dict(boxstyle='round', facecolor='wheat', alpha=0.85)
    fig.text(0.985, 0.97, metrics_text, fontsize=9, verticalalignment='top',
             horizontalalignment='right', bbox=props, family='monospace')

    plt.tight_layout(rect=[0, 0, 0.97, 0.96])

    timestamp = pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')
    plot_filename = f"autotune_plot_{ticker}_{dataset_id}_{timestamp}.png"
    plot_path = os.path.join(output_dir, plot_filename)
    os.makedirs(output_dir, exist_ok=True)
    plt.savefig(plot_path, dpi=150, bbox_inches='tight', facecolor='white')

    if verbose:
        print(f"\n📊 Plot saved to: {plot_path}")
        print(f"   Visual success rate: {plot_success_rate:.2%} | Optimized score: {metrics.get(f'{optimize_metric}_{signal_type}_{LA}b', 'N/A')}")
        print("   Showing plot window... (close it to continue)")
    plt.show()
    return plot_path


# =============================================================================
# 5. MAIN
# =============================================================================
if __name__ == "__main__":
    parser = setup_argparse()
    args = parser.parse_args()
    entry(args)