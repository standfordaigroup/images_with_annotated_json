import os
import random
import sys
from pathlib import Path

# ─────────────────────────────────────────────────────────────────────────
# 🔒 DETERMINISM SETUP
# ─────────────────────────────────────────────────────────────────────────
SEED = 42
random.seed(SEED)
os.environ["PYTHONHASHSEED"] = str(SEED)

# Force single-threaded BLAS/OMP to help reproducibility.
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"

try:
    from version import sys__name, sys__version
except ImportError:
    import pathlib

    current_dir = pathlib.Path(__file__).resolve()
    parent_dir = current_dir.parent.parent.parent
    sys.path.insert(0, str(parent_dir))
    from version import sys__name, sys__version

import argparse
import pickle
import time
import warnings
from datetime import datetime
from urllib.parse import quote

import numpy as np
import pandas as pd

try:
    import optuna
except ImportError as exc:
    print("This script requires Optuna. Install it with: pip install optuna")
    raise exc

from sklearn import svm
from sklearn.ensemble import RandomForestClassifier
from sklearn.exceptions import ConvergenceWarning, EfficiencyWarning, InconsistentVersionWarning
from sklearn.linear_model import SGDClassifier
from sklearn.metrics import classification_report, confusion_matrix, fbeta_score, make_scorer
from sklearn.model_selection import TimeSeriesSplit, cross_validate
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer, RobustScaler, StandardScaler

from utils import (
    get_next_step,
    round_price_for_call_credit_spread,
    round_price_for_put_credit_spread,
)
from constants import WEBEARStyle

warnings.filterwarnings("ignore", category=InconsistentVersionWarning)
warnings.filterwarnings("ignore", category=ConvergenceWarning)
warnings.filterwarnings("ignore", category=EfficiencyWarning)


def _format_date(ts):
    try:
        return ts.strftime("%Y-%m-%d")
    except Exception:
        return str(ts)


def _parse_arguments():
    """
    Parse command-line arguments for the market/macro prediction script.
    """
    parser = argparse.ArgumentParser(
        description="Train and evaluate time-series classifiers with Optuna-driven feature selection.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
        epilog="""
        Examples:
          # Start or continue an Optuna study:
          python this_script.py -d combined_month_macro.data --study-name my_study

          # Reset study:
          python this_script.py -d combined_month_macro.data --study-name my_study --delete-study

          # Run for 30 minutes:
          python this_script.py -d combined_month_macro.data --time-limit 1800
        """,
    )

    # ─────────────────────────────────────────────────────────────────────────
    # DATA & TARGET CONFIGURATION
    # ─────────────────────────────────────────────────────────────────────────
    data_grp = parser.add_argument_group("Data & Target Configuration")
    data_grp.add_argument(
        "--dataset", "-d", type=str, default="combined_month_macro.data",
        help="Path to the pickled dataset containing 'market_data' and 'macro_data'."
    )
    data_grp.add_argument(
        "--n-test", "-nt", type=int, default=24,
        help="Number of final time steps to reserve for out-of-sample testing."
    )
    data_grp.add_argument(
        "--target-type", "-tt", type=str, default="soft_higher",
        choices=["higher", "soft_higher", "lower", "soft_lower", "in_between"],
        help="Logic used to generate the binary prediction target."
    )
    data_grp.add_argument(
        "--target-percentage", "-tp", type=float, default=0.01,
        help="Threshold fraction for 'soft' or 'in_between' target types (e.g., 0.01 = 1%%)."
    )
    data_grp.add_argument(
        "--override-target-percentage", "-ortp", type=float, default=None,
        help="In realtime, override the target percentage from the model."
    )
    data_grp.add_argument(
        "--look-ahead", "-la", type=float, default=1.0,
        help="Number of periods to shift forward for target generation. Must be > 0."
    )

    # ─────────────────────────────────────────────────────────────────────────
    # FEATURES & TECHNICAL INDICATORS
    # ─────────────────────────────────────────────────────────────────────────
    feat_grp = parser.add_argument_group("Features & Technical Indicators")
    feat_grp.add_argument(
        "--features", "-f", nargs="+", default=[
            "VIX_Ratio", "RSI", "Price_to_MA", "VIX", "MA_Short", "MA_Long",
            "Shifted_MA_Short", "Shifted_MA_Long", "Shifted_Price_to_MA",
            "VIX_Lag1", "RSI_Lag1", "Fed_Rate_Diff", "Unrate_Diff",
            "Inflation_Rate", "Spread_10Y2Y", "Log_Close", "Dist_from_ATH",
            "PCE_Inflation_YoY", "WALCL_YoY", "DGS10_Level", "DGS10_MoM_Chg"
        ],
        help="List of column names to use as candidate model features."
    )
    feat_grp.add_argument(
        "--vix-lag", "-vl", type=int, default=1,
        help="Lag period applied to the VIX feature."
    )
    feat_grp.add_argument(
        "--rsi-lag", "-rl", type=int, default=1,
        help="Lag period applied to the RSI feature."
    )
    feat_grp.add_argument(
        "--rsi-window", "-rw", type=int, default=14,
        help="Rolling window size for RSI calculation."
    )

    # ─────────────────────────────────────────────────────────────────────────
    # MODEL & TRAINING CONFIGURATION
    # ─────────────────────────────────────────────────────────────────────────
    model_grp = parser.add_argument_group("Model & Training Configuration")
    model_grp.add_argument(
        "--scaler", "-s", type=str, default="FunctionTransformer",
        choices=["RobustScaler", "StandardScaler", "FunctionTransformer"],
        help="Feature scaling method applied before model training."
    )
    model_grp.add_argument(
        "--estimator", "-e", type=str, default="RandomForestClassifier",
        choices=["RandomForestClassifier", "LinearSVC", "SVC", "SGDClassifier"],
        help="Machine learning classifier to use for prediction."
    )
    model_grp.add_argument(
        "--scorer", "-sc", type=str, default="F0.5",
        choices=["F0.5", "F", "F2"],
        help="Metric used for hyperparameter optimization and evaluation."
    )
    model_grp.add_argument(
        "--training-mode", "-tm", type=str, default="optuna",
        choices=["optuna", "exhaustive", "random", "manual"],
        help="Feature search strategy. Legacy modes are redirected to Optuna."
    )
    model_grp.add_argument(
        "--minimum-features", "-mfl", type=int, default=1,
        help="Minimum number of selected features."
    )
    model_grp.add_argument(
        "--max-random-iterations", "-mri", type=int, default=99999,
        help="Fallback for --n-trials if --n-trials is not provided."
    )

    # ─────────────────────────────────────────────────────────────────────────
    # OPTUNA CONFIGURATION
    # ─────────────────────────────────────────────────────────────────────────
    optuna_grp = parser.add_argument_group("Optuna Configuration")
    optuna_grp.add_argument(
        "--study-name", type=str, default="market_feature_selection",
        help="Optuna study name. Reusing the same name/storage resumes the study."
    )
    optuna_grp.add_argument(
        "--optuna-db", type=str, default="./optuna_market_feature_selection.db",
        help=(
            "Optuna persistence file. "
            "If suffix is .journal/.log/.jsonl, JournalStorage is used. "
            "Otherwise SQLite storage is used."
        )
    )
    optuna_grp.add_argument(
        "--optuna-storage", type=str, default=None,
        help="Explicit Optuna storage URL. If set, --optuna-db is ignored."
    )
    optuna_grp.add_argument(
        "--n-trials", type=int, default=None,
        help=(
            "Number of Optuna trials to run. If omitted: "
            "use --time-limit if present, else --max-random-iterations if changed, else 100."
        )
    )
    optuna_grp.add_argument(
        "--cv-splits", type=int, default=5,
        help="Number of TimeSeriesSplit folds used in the objective."
    )
    optuna_grp.add_argument(
        "--cv-gap", type=int, default=None,
        help=(
            "Gap between train and validation folds. "
            "Defaults to --look-ahead to reduce target leakage."
        )
    )
    optuna_grp.add_argument(
        "--cv-n-jobs", type=int, default=1,
        help="n_jobs used inside cross_validate. Use 0 for None, -1 for all cores."
    )
    optuna_grp.add_argument(
        "--feature-penalty-weight", type=float, default=0.001,
        help="Objective penalty weight for selecting more than the minimum number of features."
    )
    optuna_grp.add_argument(
        "--instability-penalty-weight", type=float, default=0.05,
        help="Objective penalty weight for CV score standard deviation."
    )
    optuna_grp.add_argument(
        "--worst-fold-penalty-weight", type=float, default=0.10,
        help="Objective penalty weight for bad worst-fold CV score."
    )
    optuna_grp.add_argument(
        "--invalid-penalty", type=float, default=10.0,
        help="Base loss returned for invalid or failed trials."
    )
    optuna_grp.add_argument(
        "--max-features", type=int, default=None,
        help="Maximum number of selected features. Defaults to all available features."
    )
    optuna_grp.add_argument(
        "--delete-study", action="store_true",
        help="Delete the existing Optuna study before starting, if it exists."
    )
    optuna_grp.add_argument(
        "--allow-study-changes", action="store_true",
        help="Allow resuming even if dataset/target/signature changed. Use with care."
    )

    # ─────────────────────────────────────────────────────────────────────────
    # EXECUTION & OUTPUT
    # ─────────────────────────────────────────────────────────────────────────
    exec_grp = parser.add_argument_group("Execution & Output")
    exec_grp.add_argument(
        "--time-limit", "-tl", type=float, default=None,
        help="Maximum time in seconds for the search process. None = no limit."
    )
    exec_grp.add_argument(
        "--output-dir", "-o", type=str, default="./output_models",
        help="Directory to save the best model and training metadata."
    )
    exec_grp.add_argument(
        "--verbose", action="store_false", dest="verbose", default=True,
        help="Disable detailed console output and progress reports."
    )
    exec_grp.add_argument(
        "--real-time", action="store_true", default=False,
        help="Run in real-time prediction mode using a saved model."
    )
    exec_grp.add_argument(
        "--realtime", action="store_true", default=False,
        help="Alias for --real-time."
    )
    exec_grp.add_argument(
        "--model-path", type=str, default=None,
        help="(Optional for --real-time) Path to a specific pickled model."
    )
    exec_grp.add_argument(
        "--clip", action="store_true",
        help="Exclude incomplete current bar in real-time."
    )
    exec_grp.add_argument(
        "--clip-n", type=int, default=0,
        help="Do a .iloc[:-n] on the loaded dataset. A value greater than 0 enables it."
    )
    exec_grp.add_argument(
        "--nb-worker", type=int, default=1, required=False,
        help="Number of parallel Optuna worker threads."
    )

    args = parser.parse_args()

    scaler_map = {
        "RobustScaler": RobustScaler,
        "StandardScaler": StandardScaler,
        "FunctionTransformer": FunctionTransformer,
    }
    estimator_map = {
        "RandomForestClassifier": RandomForestClassifier,
        "LinearSVC": svm.LinearSVC,
        "SVC": svm.SVC,
        "SGDClassifier": SGDClassifier,
    }

    args.my_scaler = scaler_map[args.scaler]
    args.the_estimator = estimator_map[args.estimator]

    return args


def _build_features_and_target(
    _df_market,
    _df_macro,
    _rsi_window,
    _vix_lag,
    _rsi_lag,
    _look_head_for_prediction,
    _percentage_of_type_target,
    _type_of_target,
    _verbose,
    create_target=True,
):
    # 1. Macro features.
    _df_macro["Spread_10Y2Y"] = _df_macro["T10Y2Y"].shift(1)
    _df_macro["Spread_10Y3M"] = _df_macro["T10Y3M"].shift(1)
    _df_macro["Fed_Rate_Diff"] = _df_macro["FEDFUNDS"].diff().shift(1)
    _df_macro["Unrate_Diff"] = _df_macro["UNRATE"].diff().shift(1)
    _df_macro["Inflation_Rate"] = _df_macro["CPIAUCSL"].pct_change(12, fill_method=None).shift(1)

    # PCEPI: YoY PCE Inflation.
    _df_macro["PCE_Inflation_YoY"] = _df_macro["PCEPI"].pct_change(12).shift(1)

    # WALCL: Fed balance sheet YoY growth.
    _df_macro["WALCL_YoY"] = _df_macro["WALCL"].pct_change(12).shift(1)

    # DGS10: 10Y Treasury yield level and monthly change.
    _df_macro["DGS10_Level"] = _df_macro["DGS10"].shift(1)
    _df_macro["DGS10_MoM_Chg"] = _df_macro["DGS10"].diff().shift(1)

    macro_features = [
        "Fed_Rate_Diff",
        "Unrate_Diff",
        "Inflation_Rate",
        "Spread_10Y2Y",
        "Spread_10Y3M",
        "PCE_Inflation_YoY",
        "WALCL_YoY",
        "DGS10_Level",
        "DGS10_MoM_Chg",
    ]

    _df_fusionned = _df_market.join(_df_macro[macro_features]).dropna().copy()

    # 2. Market features.
    _df_fusionned["VIX_Ratio"] = _df_fusionned["VIX"] / _df_fusionned["VIX"].rolling(12).mean()

    delta = _df_fusionned["Close"].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=_rsi_window).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=_rsi_window).mean()
    rs = gain / loss
    _df_fusionned["RSI"] = 100 - (100 / (1 + rs))

    _df_fusionned["MA_Short"] = _df_fusionned["Close"].rolling(window=3).mean()
    _df_fusionned["MA_Long"] = _df_fusionned["Close"].rolling(window=12).mean()
    _df_fusionned["Price_to_MA"] = _df_fusionned["Close"] / _df_fusionned["MA_Long"]

    _df_fusionned["Shifted_MA_Short"] = _df_fusionned["MA_Short"].diff()
    _df_fusionned["Shifted_MA_Long"] = _df_fusionned["MA_Long"].pct_change()
    _df_fusionned["Shifted_Price_to_MA"] = _df_fusionned["Price_to_MA"].diff()

    _df_fusionned["VIX_Lag1"] = _df_fusionned["VIX"].shift(_vix_lag)
    _df_fusionned["RSI_Lag1"] = _df_fusionned["RSI"].shift(_rsi_lag)

    _df_fusionned["Log_Close"] = np.log(_df_fusionned["Close"])
    _df_fusionned["Dist_from_ATH"] = (_df_fusionned["Close"] / _df_fusionned["Close"].cummax()) - 1

    if _verbose:
        tmp = _df_fusionned.dropna()
        if not tmp.empty:
            print(
                f"Dates in DF (before target): "
                f"{_format_date(tmp.index[0])} :: {_format_date(tmp.index[-1])}"
            )

    # 3. Target.
    if create_target:
        _look_head_for_prediction = int(_look_head_for_prediction)
        assert _look_head_for_prediction > 0
        assert 0 <= _percentage_of_type_target < 1

        future_close = _df_fusionned["Close"].shift(-_look_head_for_prediction)

        if _type_of_target == "higher":
            _df_fusionned["Target"] = (future_close > _df_fusionned["Close"]).astype(int)
        elif _type_of_target == "lower":
            _df_fusionned["Target"] = (future_close < _df_fusionned["Close"]).astype(int)
        elif _type_of_target == "soft_higher":
            _df_fusionned["Return"] = (future_close / _df_fusionned["Close"]) - 1
            _df_fusionned["Target"] = (_df_fusionned["Return"] > _percentage_of_type_target).astype(int)
        elif _type_of_target == "soft_lower":
            _df_fusionned["Return"] = (future_close / _df_fusionned["Close"]) - 1
            _df_fusionned["Target"] = (_df_fusionned["Return"] < -_percentage_of_type_target).astype(int)
        elif _type_of_target == "in_between":
            lower_bound = _df_fusionned["Close"] * (1 - _percentage_of_type_target)
            upper_bound = _df_fusionned["Close"] * (1 + _percentage_of_type_target)
            _df_fusionned["Target"] = (
                (future_close >= lower_bound) & (future_close <= upper_bound)
            ).astype(int)
        else:
            raise ValueError(f"Unknown target type: {_type_of_target}")

        # Restore NaNs where future_close is missing so dropna() works correctly.
        _df_fusionned.loc[future_close.isna(), "Target"] = np.nan
        _df_fusionned = _df_fusionned.dropna(subset=["Target"])
        # Drop also the first rows where there might be some missing features.
        _df_fusionned = _df_fusionned.dropna()
    else:
        # Real-time mode: only drop rows with missing features.
        _df_fusionned = _df_fusionned.dropna()

    if _verbose and not _df_fusionned.empty:
        print(
            f"Dates in DF (features only): "
            f"{_format_date(_df_fusionned.index[0])} :: {_format_date(_df_fusionned.index[-1])}"
        )

    return _df_fusionned.copy()


def _get_beta(scorer_name: str) -> float:
    if scorer_name == "F0.5":
        return 0.5
    if scorer_name == "F":
        return 1.0
    if scorer_name == "F2":
        return 2.0
    raise ValueError(f"Unknown scorer: {scorer_name}")


def _sqlite_url_from_path(path: Path) -> str:
    path_posix = Path(path).resolve().as_posix()
    if os.name == "nt":
        return f"sqlite:///{quote(path_posix, safe='/:')}"
    return f"sqlite:////{quote(path_posix.lstrip('/'), safe='/:')}"


def _make_optuna_storage(args):
    """
    Create an Optuna storage that serializes the study on disk.

    Default:
      - SQLite if --optuna-db ends with .db/.sqlite/etc.
      - JournalStorage if --optuna-db ends with .journal/.log/.jsonl.

    You can force any Optuna storage URL with --optuna-storage.
    """
    if getattr(args, "optuna_storage", None):
        return args.optuna_storage

    path = Path(args.optuna_db).expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    path = path.resolve()

    if path.suffix.lower() in {".journal", ".log", ".jsonl"}:
        # Newer Optuna APIs.
        try:
            return optuna.storages.JournalStorage(optuna.storages.JournalFileBackend(str(path)))
        except AttributeError:
            pass

        # Older Optuna APIs.
        try:
            return optuna.storages.JournalStorage(optuna.storages.JournalFileStorage(str(path)))
        except Exception:
            pass

    return _sqlite_url_from_path(path)


def _select_features_from_trial(trial, feature_names, min_features, max_features):
    """
    Optuna-friendly feature selection.

    Instead of sampling many invalid binary masks, we sample:
      - n_selected
      - one score per feature

    and keep the top-n_selected features. This guarantees valid feature subsets.
    """
    n_selected = trial.suggest_int("n_selected", min_features, max_features)

    scored = []
    for i, feat in enumerate(feature_names):
        w = trial.suggest_float(f"feat_score::{i}", 0.0, 1.0)
        scored.append((w, i, feat))

    # Deterministic ordering:
    # higher weight first, then original feature index as tie-breaker.
    scored.sort(key=lambda x: (-x[0], x[1]))

    chosen_set = {feat for _, _, feat in scored[:n_selected]}
    selected = [feat for feat in feature_names if feat in chosen_set]

    return selected, n_selected


def _selected_features_from_params(params, feature_names, min_features, max_features):
    """
    Fallback reconstruction of selected features from Optuna trial.params.
    """
    if "n_selected" not in params:
        return feature_names[:min_features]

    n_selected = int(params.get("n_selected", min_features))
    n_selected = max(min_features, min(max_features, n_selected, len(feature_names)))

    scored = []
    for i, feat in enumerate(feature_names):
        w = float(params.get(f"feat_score::{i}", 0.0))
        scored.append((w, i, feat))

    scored.sort(key=lambda x: (-x[0], x[1]))
    chosen_set = {feat for _, _, feat in scored[:n_selected]}
    return [feat for feat in feature_names if feat in chosen_set]


def _suggest_model_params(trial, estimator_name: str):
    """
    Suggest model hyperparameters inside the same Optuna trial.

    This makes the objective more coherent than nested random search:
    feature selection + model hyperparameters are optimized together.
    """
    if estimator_name == "RandomForestClassifier":
        max_depth_raw = trial.suggest_categorical(
            "model::max_depth", ["2", "3", "5", "8", "10", "12", "none"]
        )
        min_samples_split = trial.suggest_int("model::min_samples_split", 2, 64)
        min_samples_leaf = trial.suggest_int(
            "model::min_samples_leaf", 1, min(32, max(1, min_samples_split))
        )
        max_features_raw = trial.suggest_categorical(
            "model::max_features", ["sqrt", "log2", "none"]
        )
        class_weight_raw = trial.suggest_categorical(
            "model::class_weight", ["none", "balanced", "balanced_subsample"]
        )

        return {
            "n_estimators": trial.suggest_int("model::n_estimators", 100, 800, step=100),
            "max_depth": None if max_depth_raw == "none" else int(max_depth_raw),
            "min_samples_split": min_samples_split,
            "min_samples_leaf": min_samples_leaf,
            "max_features": None if max_features_raw == "none" else max_features_raw,
            "bootstrap": True,
            "class_weight": None if class_weight_raw == "none" else class_weight_raw,
        }

    if estimator_name == "LinearSVC":
        loss = trial.suggest_categorical("model::loss", ["hinge", "squared_hinge"])
        dual = True if loss == "hinge" else trial.suggest_categorical("model::dual", [True, False])
        class_weight_raw = trial.suggest_categorical("model::class_weight", ["none", "balanced"])

        return {
            "C": trial.suggest_float("model::C", 1e-3, 1e3, log=True),
            "loss": loss,
            "penalty": "l2",
            "dual": dual,
            "tol": trial.suggest_float("model::tol", 1e-4, 1e-1, log=True),
            "max_iter": trial.suggest_int("model::max_iter", 2000, 10000, step=2000),
            "class_weight": None if class_weight_raw == "none" else class_weight_raw,
        }

    if estimator_name == "SVC":
        gamma_mode = trial.suggest_categorical("model::gamma_mode", ["scale", "auto", "custom"])
        if gamma_mode == "custom":
            gamma = trial.suggest_float("model::gamma_value", 1e-4, 10.0, log=True)
        else:
            gamma = gamma_mode

        kernel = trial.suggest_categorical("model::kernel", ["rbf", "poly", "sigmoid"])
        class_weight_raw = trial.suggest_categorical("model::class_weight", ["none", "balanced"])

        params = {
            "C": trial.suggest_float("model::C", 1e-2, 1e3, log=True),
            "kernel": kernel,
            "gamma": gamma,
            "probability": True,
            "cache_size": 200,
            "class_weight": None if class_weight_raw == "none" else class_weight_raw,
        }

        if kernel == "poly":
            params["degree"] = trial.suggest_int("model::degree", 2, 4)

        return params

    if estimator_name == "SGDClassifier":
        penalty = trial.suggest_categorical("model::penalty", ["l2", "l1", "elasticnet"])
        learning_rate = trial.suggest_categorical(
            "model::learning_rate", ["constant", "optimal", "invscaling", "adaptive"]
        )
        class_weight_raw = trial.suggest_categorical("model::class_weight", ["none", "balanced"])

        params = {
            "loss": trial.suggest_categorical(
                "model::loss", ["hinge", "log_loss", "modified_huber", "squared_hinge"]
            ),
            "penalty": penalty,
            "alpha": trial.suggest_float("model::alpha", 1e-6, 1e-1, log=True),
            "learning_rate": learning_rate,
            "max_iter": trial.suggest_int("model::max_iter", 5000, 20000, step=5000),
            "tol": trial.suggest_float("model::tol", 1e-4, 1e-1, log=True),
            "class_weight": None if class_weight_raw == "none" else class_weight_raw,
        }

        if learning_rate != "optimal":
            params["eta0"] = trial.suggest_float("model::eta0", 1e-4, 1e-1, log=True)

        if learning_rate == "invscaling":
            params["power_t"] = trial.suggest_float("model::power_t", 0.1, 0.9)

        if penalty == "elasticnet":
            params["l1_ratio"] = trial.suggest_float("model::l1_ratio", 0.0, 1.0)

        return params

    raise ValueError(f"Unsupported estimator: {estimator_name}")


def _make_estimator(estimator_class, params, seed=SEED, n_jobs=1):
    """
    Build estimator from params and force reproducible/single-thread settings.
    """
    params = dict(params or {})

    try:
        default_params = estimator_class().get_params()
    except Exception:
        default_params = {}

    if "random_state" in default_params:
        params["random_state"] = seed

    if "n_jobs" in default_params:
        params["n_jobs"] = n_jobs

    if estimator_class.__name__ == "SVC":
        params["probability"] = True

    if estimator_class.__name__ == "LinearSVC":
        params.setdefault("max_iter", 5000)

    return estimator_class(**params)


def _save_best_model(best_setup, args, output_dir, command_line, verbose=True):
    """
    Save the best model configuration and training parameters to a pickle file.
    """
    os.makedirs(output_dir, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    est_name = args.the_estimator.__name__
    target_name = args.target_type

    filename = f"best_model_{est_name}_{target_name}_{timestamp}.pkl"
    filepath = os.path.join(output_dir, filename)

    save_data = {
        "best_setup": best_setup,
        "saved_at": datetime.now().isoformat(),
        "params": {
            "rsi_window": args.rsi_window,
            "vix_lag": args.vix_lag,
            "rsi_lag": args.rsi_lag,
            "look_ahead": args.look_ahead,
            "target_percentage": args.target_percentage,
            "target_type": args.target_type,
            "dataset_filename": args.dataset,
        },
        "command_line": command_line,
        "optuna": best_setup.get("cv", {}).get("optuna", {}),
    }

    with open(filepath, "wb") as f:
        pickle.dump(save_data, f)

    if verbose:
        print(f"\n💾 Best model successfully saved to: {filepath}")


def entry_point(args):
    command_line = "python " + " ".join(sys.argv)
    final_dataset_filename = args.dataset
    verbose = args.verbose

    is_realtime = getattr(args, "real_time", False) or getattr(args, "realtime", False)

    # ─────────────────────────────────────────────────────────────────────────
    # 🔄 LOAD SAVED PARAMETERS FIRST IF IN REAL-TIME MODE
    # ─────────────────────────────────────────────────────────────────────────
    if is_realtime:
        model_path = args.model_path
        assert model_path is not None, "--model-path is required in real-time mode."

        if verbose:
            print(f"📦 Loading model and training parameters from: {model_path}")

        with open(model_path, "rb") as f:
            saved_data = pickle.load(f)

        command_line = saved_data.get("command_line", command_line)
        if verbose:
            print(f"Command line used: {command_line}")

        saved_params = saved_data.get("params", {})

        assert "rsi_window" in saved_params
        rsi_window = saved_params.get("rsi_window")

        assert "vix_lag" in saved_params
        vix_lag = saved_params.get("vix_lag")

        assert "rsi_lag" in saved_params
        rsi_lag = saved_params.get("rsi_lag")

        assert "look_ahead" in saved_params
        look_head_for_prediction = saved_params.get("look_ahead")

        assert "target_percentage" in saved_params
        percentage_of_type_target = saved_params.get("target_percentage")

        assert "target_type" in saved_params
        type_of_target = saved_params.get("target_type")

        _dataset_filename_used = saved_params.get("dataset_filename", final_dataset_filename)
        _is_same_file_str = (
            f"(overriding {_dataset_filename_used})"
            if final_dataset_filename != _dataset_filename_used
            else ""
        )

        if verbose:
            print(f"📦 Loading dataset from : {final_dataset_filename}  {_is_same_file_str}")

        saved_params["dataset_filename"] = final_dataset_filename

        if verbose:
            print("✅ Using saved training parameters for real-time feature engineering.")
    else:
        n_test = args.n_test
        type_of_target = args.target_type
        percentage_of_type_target = args.target_percentage
        look_head_for_prediction = int(args.look_ahead)
        my_scaler = args.my_scaler
        features = args.features
        vix_lag = args.vix_lag
        rsi_lag = args.rsi_lag
        rsi_window = args.rsi_window
        the_estimator = args.the_estimator
        the_scorer = args.scorer
        training_mode = args.training_mode
        max_random_iterations = args.max_random_iterations
        minimum_features = args.minimum_features
        time_limit = args.time_limit
        output_dir = args.output_dir
        saved_data = None

    if verbose:
        print(f"🔄 Loading data from <<{final_dataset_filename}>>")

    np.set_printoptions(linewidth=np.inf)

    with open(final_dataset_filename, "rb") as f:
        loaded_data = pickle.load(f)

    df_market = loaded_data["market_data"]
    df_macro = loaded_data["macro_data"]

    df = _build_features_and_target(
        _df_market=df_market,
        _df_macro=df_macro,
        _rsi_window=rsi_window,
        _vix_lag=vix_lag,
        _rsi_lag=rsi_lag,
        _look_head_for_prediction=look_head_for_prediction,
        _percentage_of_type_target=percentage_of_type_target,
        _type_of_target=type_of_target,
        _verbose=verbose,
        create_target=not is_realtime,
    )
    assert 0==df.isna().any(axis=1).sum()
    # ─────────────────────────────────────────────────────────────────────────
    # 🚀 REAL-TIME PREDICTION MODE
    # ─────────────────────────────────────────────────────────────────────────
    if is_realtime:
        if df.empty:
            print("❌ No valid data points available after feature engineering.")
            return

        if getattr(args, "clip", False):
            df = df.iloc[:-1].copy()
        elif getattr(args, "clip_n", 0) > 0:
            df = df.iloc[: -int(args.clip_n)].copy()

        if df.empty:
            print("❌ No valid data points available after clipping.")
            return

        last_date = _format_date(df.index[-1])
        last_value = df.iloc[-1]["Close"]

        best_setup = saved_data["best_setup"]
        setup_to_use = best_setup.get("cv", best_setup.get("test", best_setup.get("train")))
        assert setup_to_use is not None, "No valid model setup found in saved file."

        _target_type_used = saved_data["params"]["target_type"]
        _target_pourcentage_used = saved_data["params"]["target_percentage"]

        if getattr(args, "override_target_percentage", None) is not None:
            _target_pourcentage_used = args.override_target_percentage

        _look_ahead_used = int(saved_data["params"]["look_ahead"])
        assert look_head_for_prediction == _look_ahead_used

        _dataset_filename_used = saved_data["params"].get("dataset_filename", final_dataset_filename)

        scaler = setup_to_use["scaler"]
        model = setup_to_use["model"]
        feat_cols = setup_to_use["features"]

        missing_features = [f for f in feat_cols if f not in df.columns]
        if missing_features:
            print(f"❌ Missing features in realtime dataframe: {missing_features}")
            return

        if verbose:
            print(
                f"Beta    Priorite    Philosophie\n"
                f"0.5     Precision   'Je ne veux pas me tromper quand j\'investis.'\n"
                f"1.0     Equilibre   'Je veux un bon melange de fiabilite et d\'opportunites.'\n"
                f"2.0     Rappel      'Je ne veux surtout pas rater une hausse du marche.'"
            )

        _tmp_ttu_1 = f"{WEBEARStyle.BOLD}higher{WEBEARStyle.END}" if _target_type_used == "higher" else "higher"
        _tmp_ttu_2 = f"{WEBEARStyle.BOLD}lower{WEBEARStyle.END}" if _target_type_used == "lower" else "lower"
        _tmp_ttu_3 = f"{WEBEARStyle.BOLD}soft_higher{WEBEARStyle.END}" if _target_type_used == "soft_higher" else "soft_higher"
        _tmp_ttu_4 = f"{WEBEARStyle.BOLD}soft_lower{WEBEARStyle.END}" if _target_type_used == "soft_lower" else "soft_lower"
        _tmp_ttu_5 = f"{WEBEARStyle.BOLD}in_between{WEBEARStyle.END}" if _target_type_used == "in_between" else "in_between"

        if verbose:
            print(
                f"🔹 {_tmp_ttu_1}\n"
                f"Logic: 1 if future_price > current_price, else 0\n"
                f"Meaning: Predicts any upward movement, no matter how small.\n"
                f"Use case: Pure directional bias. Highly sensitive to market noise.\n"
                f"\n"
                f"🔹 {_tmp_ttu_2}\n"
                f"Logic: 1 if future_price < current_price, else 0\n"
                f"Meaning: Predicts any downward movement.\n"
                f"Use case: Short/bearish directional bias.\n"
                f"\n"
                f"🔹 {_tmp_ttu_3} ⭐ (Recommended for trading)\n"
                f"Logic: 1 if (future_price / current_price) - 1 > threshold, else 0\n"
                f"Meaning: Predicts an upward move greater than your threshold (e.g., > +1%). Moves between 0% and +1% are labeled 0.\n"
                f"Use case: Filters out noise and transaction costs. Only signals when there's meaningful upside potential.\n"
                f"\n"
                f"🔹 {_tmp_ttu_4}\n"
                f"Logic: 1 if (future_price / current_price) - 1 < -threshold, else 0\n"
                f"Meaning: Predicts a downward move greater than your threshold (e.g., < -1%).\n"
                f"Use case: Filters out minor dips. Only signals meaningful downside risk.\n"
                f"\n"
                f"🔹 {_tmp_ttu_5}\n"
                f"Logic: 1 if current_price * (1 - threshold) ≤ future_price ≤ current_price * (1 + threshold), else 0\n"
                f"Meaning: Predicts the market will stay sideways/consolidate within ± your threshold.\n"
                f"Use case: Useful for range-bound strategies, volatility selling, or avoiding false breakout signals.\n"
                f"\n"
            )

        clip_str = ""
        if getattr(args, "clip", False):
            clip_str = "(clipping activated)"
        elif getattr(args, "clip_n", 0) > 0:
            clip_str = f"(clipping activated,{int(getattr(args, 'clip_n', 0))})"

        if verbose:
            print(f"📅 Using last datapoint: {last_date} @ {last_value:.0f} {clip_str}")

        # Prepare last row.
        X_last = df[feat_cols].iloc[[-1]]
        X_last_scaled = scaler.transform(X_last)

        # Predict.
        _realtime_prediction = model.predict(X_last_scaled)[0]

        proba = 0.0
        if hasattr(model, "predict_proba"):
            try:
                probas = model.predict_proba(X_last_scaled)[0]
                classes = getattr(model, "classes_", None)

                if classes is not None and len(classes) == 2:
                    proba = float(probas[1])
                elif len(probas) == 2:
                    proba = float(probas[1])
                elif len(probas) == 1:
                    proba = float(probas[0])
            except Exception:
                proba = 0.0

        dataset_id = None
        if "_day_" in final_dataset_filename:
            dataset_id = "day"
        if "_month_" in final_dataset_filename:
            dataset_id = "month"
        if "_week_" in final_dataset_filename or "_week" in final_dataset_filename:
            dataset_id = "week"

        assert dataset_id is not None, f"{dataset_id=}   {final_dataset_filename=}"

        ff_date = get_next_step(the_date=last_date, dataset_id=dataset_id, nn=int(_look_ahead_used))
        assert 0 < int(_look_ahead_used)

        _now_timestamp = datetime.now().strftime("%Y-%m-%d")

        if verbose:
            print("\n" + "═" * 50)
            print(f"🚀 REAL-TIME PREDICTION FOR +{int(_look_ahead_used)} BAR{'' if 1 == int(_look_ahead_used) else 'S'}")
            print(f"📅 Date/Value used : {last_date} @ {last_value:.0f}")
            print(f"📅 Today's date    : {_now_timestamp}")

        if _target_type_used in ["lower", "soft_lower"]:
            if verbose:
                print(
                    f"📊 Prediction      : "
                    f"{'DOWN' if _realtime_prediction == 1 else '!DOWN'} @ {proba:.2%} : "
                    f"on {ff_date}, price {'<' if _realtime_prediction == 1 else '>'} "
                    f"{last_value * (1 - _target_pourcentage_used):.0f}"
                )

        if _target_type_used in ["higher", "soft_higher"]:
            strike_price = (
                round_price_for_put_credit_spread(last_value * (1 - _target_pourcentage_used))
                if _realtime_prediction == 1
                else round_price_for_call_credit_spread(last_value * (1 + _target_pourcentage_used))
            )

            if verbose:
                print(
                    f"📊 Prediction      : "
                    f"{'UP' if _realtime_prediction == 1 else 'DOWN'} @ {proba:.2%} : "
                    f"on {ff_date}, price {'>' if _realtime_prediction == 1 else '<'} "
                    f"{strike_price:.0f}"
                )

        if _target_type_used in ["in_between"]:
            _str_left_tmp = (
                f"{round_price_for_put_credit_spread(last_value * (1 - _target_pourcentage_used)):.0f}"
                if _realtime_prediction == 1
                else "?"
            )
            _str_right_tmp = (
                f"{round_price_for_call_credit_spread(last_value * (1 + _target_pourcentage_used)):.0f}"
                if _realtime_prediction == 1
                else "?"
            )

            if verbose:
                print(
                    f"📊 Prediction      : "
                    f"{'RANGE' if _realtime_prediction == 1 else '!RANGE'} @ {proba:.2%} : "
                    f"on {ff_date}, {_str_left_tmp} < price < {_str_right_tmp}"
                )

        if verbose:
            print(
                f"📈 Parameters      : {_target_type_used} @{_target_pourcentage_used:.4%}  "
                f"LA:{_look_ahead_used}  Dataset:{_dataset_filename_used}"
            )
            print("═" * 50)
            print(f"🔑 Features Used   : {feat_cols}")
            print(f"   Scorer: {setup_to_use['scorer']}")

        cv_score_raw = setup_to_use.get("cv_score", "N/A")
        test_score_raw = setup_to_use.get("test_score", "N/A")

        cv_score_str = f"{cv_score_raw:.2%}" if isinstance(cv_score_raw, (int, float)) else cv_score_raw
        test_score_str = f"{test_score_raw:.2%}" if isinstance(test_score_raw, (int, float)) else test_score_raw

        if verbose:
            print(f"   CV/Test scores: {cv_score_str}/{test_score_str}")
            print(f"   Train : {setup_to_use['train_t1']}::{setup_to_use['train_t2']}")
            print(f"   Target: {_target_type_used} @{_target_pourcentage_used:.4%}")
            print(
                f"   Out of sample (Test) performance "
                f"({setup_to_use['test_t1']}::{setup_to_use['test_t2']}): \n"
                f"    y    : {setup_to_use['y_test_final'].values}\n"
                f"    y_hat: {setup_to_use['y_hat_test_final']}"
            )
            print("Test Confusion Matrix:")
            print(confusion_matrix(setup_to_use["y_test_final"], setup_to_use["y_hat_test_final"]))
            print("═" * 50)

        return {
            "realtime_prediction": _realtime_prediction,
            "last_date": last_date,
            "last_value": last_value,
            "now": _now_timestamp,
            "target_type": _target_type_used,
            "target_pourcentage_used": _target_pourcentage_used,
            "look_ahead": _look_ahead_used,
            "dataset_id": dataset_id,
            "clip_n": getattr(args, "clip_n", 0),
        }

    # ─────────────────────────────────────────────────────────────────────────
    # 📚 STANDARD OPTUNA TRAINING LOOP
    # ─────────────────────────────────────────────────────────────────────────
    if training_mode != "optuna" and verbose:
        print(f"⚠️ --training-mode '{training_mode}' is legacy. Using Optuna instead.")

    available_features = [f for f in features if f in df.columns]
    missing_features = [f for f in features if f not in df.columns]

    if missing_features and verbose:
        print(f"⚠️ Missing feature columns in dataset and ignored: {missing_features}")

    if not available_features:
        raise ValueError("No available features found in the dataset.")

    df_model = df.dropna(subset=available_features + ["Target"]).copy()

    if df_model.empty:
        raise ValueError("No valid rows after dropping NaNs in features/target.")

    X_all = df_model[available_features].copy()
    y_all = df_model["Target"].astype(int).copy()

    assert n_test > 0
    if n_test >= len(X_all):
        raise ValueError(f"--n-test={n_test} must be smaller than dataset length {len(X_all)}.")

    X_train_full = X_all.iloc[:-n_test].copy()
    y_train_full = y_all.iloc[:-n_test].copy()

    X_test_final = X_all.iloc[-n_test:].copy()
    y_test_final = y_all.iloc[-n_test:].copy()

    train_size, test_size = len(X_train_full), len(X_test_final)

    if train_size < 20:
        raise ValueError(f"Not enough training rows: {train_size}. Increase data or reduce --n-test.")

    if verbose:
        print(f"\n[STATIC] train_size={train_size}  test_size={test_size}")
        print(f"[TRAIN]  {_format_date(X_train_full.index[0])} :: {_format_date(X_train_full.index[-1])}")
        print(f"[TEST]   {_format_date(X_test_final.index[0])} :: {_format_date(X_test_final.index[-1])}")
        print(f"Nombre de features disponibles : {len(available_features)}")
        print(f"Features: {available_features}")
        print(
            f"N test: {n_test}   Target: {type_of_target} , {percentage_of_type_target}   "
            f"Look Ahead: {look_head_for_prediction}   Scaler: {my_scaler.__name__}   "
            f"Estimator: {the_estimator.__name__}   Scorer: {the_scorer}"
        )

    min_features = max(1, min(int(minimum_features), len(available_features)))

    if args.max_features is None:
        max_features = len(available_features)
    else:
        max_features = min(int(args.max_features), len(available_features))

    max_features = max(min_features, max_features)

    beta = _get_beta(the_scorer)
    scoring = make_scorer(fbeta_score, beta=beta, zero_division=0)

    optuna.logging.set_verbosity(optuna.logging.INFO if verbose else optuna.logging.WARNING)

    storage = _make_optuna_storage(args)

    if getattr(args, "delete_study", False):
        try:
            optuna.delete_study(study_name=args.study_name, storage=storage)
            if verbose:
                print(f"🗑️ Deleted existing Optuna study: {args.study_name}")
        except Exception as exc:
            if verbose:
                print(f"ℹ️ Could not delete study '{args.study_name}': {exc}")

    sampler = optuna.samplers.TPESampler(seed=SEED)

    study = optuna.create_study(
        study_name=args.study_name,
        storage=storage,
        direction="minimize",
        load_if_exists=True,
        sampler=sampler,
    )

    if study.direction != optuna.study.StudyDirection.MINIMIZE:
        raise RuntimeError(
            f"Existing study '{args.study_name}' has direction={study.direction}. "
            f"This script expects MINIMIZE. Use --delete-study or another --study-name."
        )

    # Prevent accidental mixing of incompatible studies.
    train_end = _format_date(X_train_full.index[-1])
    test_end = _format_date(X_test_final.index[-1])

    signature = {
        "dataset": str(Path(final_dataset_filename).resolve()),
        "features": available_features,
        "target_type": type_of_target,
        "target_percentage": float(percentage_of_type_target),
        "look_ahead": int(look_head_for_prediction),
        "n_test": int(n_test),
        "n_train": int(train_size),
        "train_end": train_end,
        "test_end": test_end,
        "scorer": the_scorer,
        "estimator": the_estimator.__name__,
        "scaler": my_scaler.__name__,
        "cv_splits": int(args.cv_splits),
        "cv_gap": "auto" if args.cv_gap is None else int(args.cv_gap),
        "min_features": int(min_features),
        "max_features": int(max_features),
        "feature_penalty_weight": float(args.feature_penalty_weight),
        "instability_penalty_weight": float(args.instability_penalty_weight),
        "worst_fold_penalty_weight": float(args.worst_fold_penalty_weight),
        "invalid_penalty": float(args.invalid_penalty),
    }

    existing_signature = study.user_attrs.get("signature")
    if existing_signature is not None and existing_signature != signature:
        if not args.allow_study_changes:
            raise RuntimeError(
                "Existing Optuna study signature does not match current run.\n"
                "This usually means dataset, target, features, CV, estimator, scorer, or penalty settings changed.\n"
                "Use --delete-study, choose a different --study-name, or use --allow-study-changes if you really know what you are doing."
            )
        elif verbose:
            print(
                "⚠️ Study signature changed but --allow-study-changes is enabled. "
                "Old and new trials may not be directly comparable."
            )

    study.set_user_attr("signature", signature)
    study.set_user_attr("feature_names", available_features)

    if args.n_trials is not None:
        n_trials = max(0, int(args.n_trials))
    elif args.time_limit is not None:
        # Let timeout control execution.
        n_trials = 10**9
    elif int(args.max_random_iterations) != 99999:
        n_trials = max(0, int(args.max_random_iterations))
    else:
        n_trials = 100

    if args.time_limit and verbose:
        print(f"⏱️ Time limit set to: {args.time_limit} seconds")

    if verbose:
        print(f"🧠 Optuna study: {args.study_name}")
        print(f"🧠 Optuna storage: {args.optuna_storage or args.optuna_db}")
        print(f"🧠 Trials to run this call: {n_trials}")
        print(f"🧠 Existing trials in study: {len(study.trials)}")

    base_gap = int(args.cv_gap) if args.cv_gap is not None else max(0, int(look_head_for_prediction))
    cv_n_jobs = None if int(args.cv_n_jobs) == 0 else int(args.cv_n_jobs)

    def objective(trial: optuna.trial.Trial) -> float:
        selected_features, n_selected = _select_features_from_trial(
            trial=trial,
            feature_names=available_features,
            min_features=min_features,
            max_features=max_features,
        )

        trial.set_user_attr("features", selected_features)
        trial.set_user_attr("n_features", len(selected_features))

        model_params = _suggest_model_params(trial, the_estimator.__name__)
        trial.set_user_attr("model_params", model_params)

        X_sub = X_train_full[selected_features]

        if X_sub.shape[1] == 0:
            trial.set_user_attr("valid", False)
            return float(args.invalid_penalty)

        pipe = Pipeline(
            [
                ("scaler", my_scaler()),
                ("clf", _make_estimator(the_estimator, model_params, seed=SEED, n_jobs=1)),
            ]
        )

        max_splits_by_len = max(1, len(X_train_full) // 3)
        n_splits = max(2, min(int(args.cv_splits), max_splits_by_len))

        if n_splits < 2 or len(X_train_full) < 10:
            trial.set_user_attr("valid", False)
            return float(args.invalid_penalty + 2.0)

        gap = max(0, base_gap)
        max_gap = max(0, len(X_train_full) // (n_splits + 1) - 1)
        gap = min(gap, max_gap)

        try:
            tscv = TimeSeriesSplit(n_splits=n_splits, gap=gap)
        except TypeError:
            # Older scikit-learn versions may not support gap.
            tscv = TimeSeriesSplit(n_splits=n_splits)

        try:
            cv_results = cross_validate(
                estimator=pipe,
                X=X_sub,
                y=y_train_full,
                cv=tscv,
                scoring=scoring,
                n_jobs=cv_n_jobs,
                return_train_score=False,
                error_score="raise",
            )
            fold_scores = np.asarray(cv_results["test_score"], dtype=float)
        except Exception as exc:
            trial.set_user_attr("valid", False)
            trial.set_user_attr("failed", True)
            trial.set_user_attr("error", str(exc)[:1000])
            return float(args.invalid_penalty + 1.0)

        if fold_scores.size == 0 or not np.all(np.isfinite(fold_scores)):
            trial.set_user_attr("valid", False)
            return float(args.invalid_penalty + 1.0)

        mean_score = float(np.mean(fold_scores))
        std_score = float(np.std(fold_scores))
        min_score = float(np.min(fold_scores))

        # Enhanced objective loss:
        #   primary loss        = 1 - CV F-beta
        #   instability penalty = CV standard deviation
        #   worst-fold penalty  = 1 - worst CV fold score
        #   feature penalty     = extra features beyond minimum
        extra_ratio = max(0, n_selected - min_features) / max(
            1, len(available_features) - min_features
        )

        loss = 1.0 - mean_score
        loss += float(args.instability_penalty_weight) * std_score
        loss += float(args.worst_fold_penalty_weight) * (1.0 - min_score)
        loss += float(args.feature_penalty_weight) * extra_ratio

        if not np.isfinite(loss):
            loss = float(args.invalid_penalty)

        trial.set_user_attr("valid", True)
        trial.set_user_attr("cv_mean", mean_score)
        trial.set_user_attr("cv_std", std_score)
        trial.set_user_attr("cv_min", min_score)
        trial.set_user_attr("objective_loss", float(loss))

        return float(loss)

    def optuna_callback(study_obj, trial):
        if not verbose:
            return

        cv_mean = trial.user_attrs.get("cv_mean", float("nan"))
        n_feat = trial.user_attrs.get("n_features", "?")

        if trial.number % 10 == 0:
            print(
                f"[Optuna] Trial {trial.number:>5} | "
                f"loss={trial.value:.4f} | CV={cv_mean:.4f} | feats={n_feat}"
            )

        try:
            best = study_obj.best_trial
            if best is not None and trial.number == best.number:
                print(
                    f"[Optuna] ⭐ New best trial {trial.number} | "
                    f"loss={trial.value:.4f} | CV={cv_mean:.4f} | feats={n_feat}"
                )
        except Exception:
            pass

    try:
        study.optimize(
            objective,
            n_trials=n_trials,
            timeout=args.time_limit,
            n_jobs=max(1, int(args.nb_worker)),
            callbacks=[optuna_callback] if verbose else [],
        )
    except KeyboardInterrupt:
        print("\n⏹️ Interrupted by user. The Optuna study remains serialized on disk.")

    if len(study.trials) == 0:
        print("⚠️ No Optuna trials were run. Nothing to save.")
        return None

    best_trial = study.best_trial

    if best_trial is None or not best_trial.user_attrs.get("valid", False):
        print("⚠️ No valid Optuna trial found. Nothing to save.")
        if best_trial is not None and best_trial.user_attrs.get("error"):
            print(f"Last best trial error: {best_trial.user_attrs.get('error')}")
        return None

    best_features = best_trial.user_attrs.get("features")
    if not best_features:
        best_features = _selected_features_from_params(
            params=best_trial.params,
            feature_names=available_features,
            min_features=min_features,
            max_features=max_features,
        )

    model_params = best_trial.user_attrs.get("model_params")
    if model_params is None:
        raise RuntimeError(
            "Best trial does not contain saved model_params. "
            "This can happen with an incompatible old study. "
            "Use --delete-study or a new --study-name."
        )

    if verbose:
        print("\n" + "═" * 128)
        print(
            f"⭐ BEST OPTUNA SETUP | TARGET:{type_of_target} @{percentage_of_type_target:.4%} | "
            f"LA:{look_head_for_prediction} | DF:{final_dataset_filename} | "
            f"Train/Test: {train_size}/{test_size}"
        )
        print("═" * 128)
        print(f"Optuna study       : {args.study_name}")
        print(f"Best trial         : {best_trial.number}")
        print(f"Objective loss     : {best_trial.value:.4f}")
        print(f"Features           : {best_features}")
        print(f"Number of features : {len(best_features)}")
        print(f"Model params       : {model_params}")
        print(f"Estimator          : {the_estimator.__name__}")
        print(f"Scorer:            : {the_scorer}")

    # ─────────────────────────────────────────────────────────────────────────
    # Refit best setup on full training block.
    # Test set is used only for final reporting, never for selection.
    # ─────────────────────────────────────────────────────────────────────────
    try:
        scaler = my_scaler()

        X_train_best = X_train_full[best_features].copy()
        X_test_best = X_test_final[best_features].copy()

        X_train_scaled = scaler.fit_transform(X_train_best)
        X_test_scaled = scaler.transform(X_test_best)

        final_model = _make_estimator(the_estimator, model_params, seed=SEED, n_jobs=1)
        final_model.fit(X_train_scaled, y_train_full)

        test_preds = final_model.predict(X_test_scaled)
        test_score = fbeta_score(y_test_final, test_preds, beta=beta, zero_division=0)
    except Exception as exc:
        print(f"❌ Failed to refit best trial on full training data: {exc}")
        return None

    cv_mean = float(best_trial.user_attrs.get("cv_mean", float("nan")))
    cv_std = float(best_trial.user_attrs.get("cv_std", float("nan")))
    cv_min = float(best_trial.user_attrs.get("cv_min", float("nan")))

    if verbose:
        print("\nScores for this snapshot:")
        print(f"  - CV selection metric ({the_scorer}): {cv_mean:.2%} ± {cv_std:.2%}")
        print(f"  - Worst CV fold ({the_scorer})       : {cv_min:.2%}")
        print(f"  - Test report metric ({the_scorer})  : {test_score:.2%}")
        print("\nClassification Report (TEST SET):")
        print(classification_report(y_test_final, test_preds, zero_division=0))
        print(f"\ny    : {y_test_final.values}")
        print(f"y_hat: {test_preds}")
        print("Confusion Matrix - TEST SET:")
        print(confusion_matrix(y_test_final, test_preds))
        print("═" * 128)

    snapshot = {
        "cv_score": cv_mean,
        "objective_loss": float(best_trial.value),
        "cv_std": cv_std,
        "cv_min": cv_min,
        "test_score": float(test_score),
        "model": final_model,
        "estimator": the_estimator,
        "type_of_target": type_of_target,
        "features": best_features,
        "scaler": scaler,
        "scorer": the_scorer,
        "X_train_full__before_scaled": X_train_best,
        "X_train_scaled": X_train_scaled,
        "y_train_full": y_train_full,
        "X_test_final__before_scaled": X_test_best,
        "X_test_scaled": X_test_scaled,
        "y_test_final": y_test_final,
        "y_hat_test_final": test_preds,
        "X": X_all[best_features],
        "y": y_all,
        "n_test": n_test,
        "train_t1": _format_date(X_train_full.index[0]),
        "train_t2": _format_date(X_train_full.index[-1]),
        "test_t1": _format_date(X_test_final.index[0]),
        "test_t2": _format_date(X_test_final.index[-1]),
        "optuna": {
            "study_name": args.study_name,
            "trial_number": best_trial.number,
            "trial_value": float(best_trial.value),
            "n_features": len(best_features),
            "model_params": model_params,
        },
    }

    best_setup_found = {"cv": snapshot}

    _save_best_model(
        best_setup=best_setup_found,
        args=args,
        output_dir=output_dir,
        command_line=command_line,
        verbose=verbose,
    )

    print(f"\nScript was executed in {Path.cwd()}")
    return None


if __name__ == "__main__":
    parsed_args = _parse_arguments()
    entry_point(parsed_args)