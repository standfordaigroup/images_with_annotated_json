from constants import FYAHOO__OUTPUTFILENAME_DAY, FYAHOO__OUTPUTFILENAME_MONTH, FYAHOO__OUTPUTFILENAME_WEEK, FYAHOO__OUTPUTFILENAME_QUARTER, FYAHOO__OUTPUTFILENAME_YEAR
from constants import EMAIL_SENDER_WEBEAR, PWD_GOOGLE_API, TAURUS_V1_BASE_DIRECTORY, CLAUSE_NON_RESPONSABILITE, IS_RUNNING_HOME_SWEET_HOME, TAURUS_V2_BASE_DIRECTORY
import sys
from types import SimpleNamespace
import platform
import math
import pandas as pd
import glob
import numpy as np
import random
import copy
import smtplib
import re
import os
import mimetypes
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from pathlib import Path
import shutil
import calendar
from datetime import datetime, time as dt_time, timedelta
from zoneinfo import ZoneInfo

os_name = platform.system()


# Function to check if two dictionaries are equal, considering NumPy arrays
def dicts_are_equal(d1, d2):
    if d1.keys() != d2.keys():
        return False
    for key in d1:
        if isinstance(d1[key], np.ndarray) and isinstance(d2[key], np.ndarray):
            if not np.array_equal(d1[key], d2[key]):
                return False
        elif d1[key] != d2[key]:
            return False
    return True


# Function to check if all dictionaries are the same
def all_dicts_equal(dicts, reference_dict):
    for d in dicts:
        if not dicts_are_equal(d, reference_dict):
            return False
    return True


def namespace_to_dict(ns):
    return {k: namespace_to_dict(v) if isinstance(v, SimpleNamespace) else v for k, v in ns.__dict__.items()}


def dict_to_namespace(d):
    return SimpleNamespace(**{k: dict_to_namespace(v) if isinstance(v, dict) else v for k, v in d.items()})


def get_index_from_date(_df, _specific_date, inc=True, max_missing_days=31):
    counted_missing_days = 0
    while counted_missing_days < max_missing_days:
        # Check if the specific date is in the index
        if _specific_date in _df.index:
            _index_number = _df.index.get_loc(_specific_date)
            # print(f"The index number for {_specific_date} is {_index_number}.")
            return _index_number
        else:
            # print(f"{_specific_date} is not in the index.")
            counted_missing_days += 1
            if inc:  # Increment the date by one day
                _specific_date = (datetime.strptime(_specific_date, "%Y-%m-%d") + timedelta(days=1)).strftime("%Y-%m-%d")
            else:
                _specific_date = (datetime.strptime(_specific_date, "%Y-%m-%d") - timedelta(days=1)).strftime("%Y-%m-%d")
    assert False, f"Cannot find an index for date {_specific_date}"


def _get_root_dir():
    # Get the current working directory of the running program
    current_dir = os.path.dirname(os.path.abspath(__file__))  # This file is utils.py, which is in the src/ directory
    return os.path.abspath(os.path.join(current_dir, '..'))


def get_stub_dir(local_dir=None):
    a_dir = os.path.join(_get_root_dir(), "stubs")
    os.makedirs(a_dir, exist_ok=True)
    if local_dir:
        a_dir = os.path.join(a_dir, local_dir)
        os.makedirs(a_dir, exist_ok=True)
    return a_dir


def get_and_clean_stub_dir(local_dir):
    a_dir = get_stub_dir(local_dir)

    # Convertit le chemin en objet Path
    dir_path = Path(a_dir)

    # Boucle sur tout le contenu du dossier
    for item in dir_path.iterdir():
        try:
            if item.is_dir():
                shutil.rmtree(item)  # Supprime un sous-répertoire et tout son contenu
            else:
                item.unlink()  # Supprime un fichier
        except:
            pass
    return a_dir


def _get_data_dir():
    a_dir = os.path.join(_get_root_dir(), 'data')
    return a_dir


def get_spy_and_vix_data_dir():
    a_dir = os.path.join(_get_data_dir(), "spy_and_vix")
    return a_dir


def get_latest_spy_and_vix_dataframe():
    data_dir = get_spy_and_vix_data_dir()
    files = glob.glob(os.path.join(data_dir, "spy_and_vix__*.pkl"))

    if not files:
        raise FileNotFoundError("No files found in the directory.")

    latest_file = max(files, key=lambda x: datetime.strptime(os.path.basename(x).split("__")[1].split(".")[0], "%Y-%m-%d"))
    return pd.read_pickle(latest_file)


def get_spy_and_vix_df_from_data_dir(date):
    a_file = os.path.join(get_spy_and_vix_data_dir(), f"spy_and_vix__{datetime.strptime(date, '%Y-%m-%d')}.pkl")
    if os.path.exists(a_file):
        return pd.read_pickle(a_file)
    return None


def generate_indices_basic_style(df, dates, x_seq_length, y_seq_length, jump_ahead=0, just_x_no_y=False, data_interval='1d'):
    # Simply takes N days to predict the next P days. Only the "P days" shall be in the date range specified
    indices = []
    tt1 = pd.to_datetime(dates[0]).replace(hour=0, minute=0, second=0)
    tt2 = pd.to_datetime(dates[1]).replace(hour=23, minute=59, second=59)
    assert tt1 <= tt2
    #ts1 = tt1 - pd.Timedelta(2 * (x_seq_length + y_seq_length) + jump_ahead, unit='days')
    #ts2 = tt2 + pd.Timedelta(2 * (x_seq_length + y_seq_length) + jump_ahead, unit='days')
    #df = df.loc[ts1:ts2]  # Reduce length of dataframe to make the processing faster
    if just_x_no_y:
        assert tt1.date() == tt2.date()
        for idx in reversed(range(0, len(df) + 1)):
            idx1, idx2 = idx - x_seq_length, idx
            if idx1 < 0 or idx2 < 0:
                continue
            if len(df.iloc[idx1:idx2]) != x_seq_length:
                continue
            assert jump_ahead==0
            if data_interval=='1d':
                # We want to predict tomorrow, so we need data today
                if next_weekday(df.iloc[idx1:idx2].index[-1].date()) != tt1.date():
                    continue
            if data_interval == '1wk':
                # We want to predict this week, so we need data from last weeks
                # So, if the predicting date is not in the week followwing idx1:idx2, pass.
                if not is_it_next_week_after_last_week_of_df(df=df.iloc[idx1:idx2], date=tt1):
                    continue
            assert idx2 > idx1
            indices.append((idx1, idx2))
            break
    else:
        for idx in reversed(range(0, len(df)+1)):
            idx1, idx2 = idx-x_seq_length-1, idx-1
            idx3, idx4 = idx+jump_ahead-1, idx+jump_ahead+y_seq_length-1
            if idx1 <0 or idx4 > len(df):
                continue
            assert df.iloc[idx1:idx2].index.intersection(df.iloc[idx3:idx4].index).empty
            # Make sure that y is in the range
            t1_y, t2_y = df.iloc[idx3:idx4].index[0], df.iloc[idx3:idx4].index[-1]
            if t1_y < tt1 or t1_y > tt2:
                continue
            if t2_y < tt1 or t2_y > tt2:
                continue
            for tk_y in list(df.iloc[idx3:idx4].index):
                assert tt1 <= tk_y <= tt2
            if len(df.iloc[idx1:idx2]) != x_seq_length:
                continue
            if len(df.iloc[idx3:idx4]) != y_seq_length:
                continue
            assert idx4 > idx3 >= idx2 > idx1
            indices.append((idx1, idx2, idx3, idx4))
    return indices, copy.deepcopy(df)


def generate_indices_naked_monday_style(df, seq_length, ignore_data_before_this_date=None):
    # For each monday, predict next tuesday, wednesday and thursday based on the last K data
    target_length                         = 3
    cutoff_day                            = 1  # Monday
    flush_target_week_with_wrong_sequence = False  # Means that y shall be tuesday, wednesday and thursday
    indices                               = []
    assert 0 == seq_length%5
    monday_indexes = [index for index, row in df[df.day_of_week == cutoff_day].iterrows()]
    for idx in monday_indexes:
        idx = df.index.get_loc(idx) + 1
        i1, i2, i3 = idx - seq_length, idx, idx+target_length
        if i1 <0:
            continue
        the_x, the_y = df.iloc[i1:i2], df.iloc[i2:i3]
        if len(the_x) != seq_length or len(the_y) != target_length:
            continue
        if ignore_data_before_this_date is not None:
            if the_y.index[-1] < pd.to_datetime(ignore_data_before_this_date):
                continue
        assert target_length == len(the_y)
        assert the_x.iloc[-1].day_of_week.values[0] == 1
        assert 1 == len(list(set([the_y.iloc[uu].week_of_year.values[0] for uu in range(0, target_length)])))
        assert len(list(set([the_x.iloc[uu].week_of_year.values[0] for uu in range(0, len(the_x))]))) in [seq_length/5,seq_length/5+1,seq_length/5+2]
        dismiss = False
        if flush_target_week_with_wrong_sequence:
            for uu in range(0, target_length):
                if uu +2 != the_y.iloc[uu].day_of_week.values[0]:
                    dismiss = True
                #if 2 != the_y.iloc[0].day_of_week or 3 != the_y.iloc[1].day_of_week or 4 != the_y.iloc[2].day_of_week:
        if dismiss:
            continue
        indices.append((i1,i2,i3))
    return indices, df


def generate_indices_with_multiple_cutoff_day(_df, _dates, x_seq_length, y_seq_length, cutoff_days, split_ratio=-1., shuffle=False):
    _indices = []
    for cutoff_day in cutoff_days:
        train_indices, train_df = generate_indices_with_cutoff_day(cutoff_day=cutoff_day, _df=copy.deepcopy(_df), _dates=_dates, x_seq_length=x_seq_length, y_seq_length=y_seq_length)
        _indices.extend(train_indices)
    return _indices, copy.deepcopy(_df)


def generate_indices_with_cutoff_day(_df, _dates, x_seq_length, y_seq_length, cutoff_day=1, split_ratio=-1., shuffle=False):
    # For all "cutoff_day" , generate indices a, b, c where b is the cutoff day, a-b] is x_seq and ]b->c is the y_seq
    _indices = []
    _end_idx = -1 if '2099' in _dates[1] else get_index_from_date(_df=_df, _specific_date=_dates[1])
    _df = _df[:_end_idx]
    cutoff_day_indexes = [index for index, row in _df[_df.day_of_week == cutoff_day].iterrows()]
    for idx in cutoff_day_indexes:
        idx = _df.index.get_loc(idx) + 1
        i1, i2, i3 = idx - x_seq_length, idx, idx + y_seq_length
        if i1 < 0:
            continue
        the_X, the_y = _df.iloc[i1:i2], _df.iloc[i2:i3]
        if len(the_X) != x_seq_length or len(the_y) != y_seq_length:
            continue
        if the_y.index[-1] < pd.to_datetime(_dates[0]):
            continue
        the_X, the_y = _df.iloc[i1:i2], _df.iloc[i2:i3]
        assert len(the_X) == x_seq_length and len(the_y) == y_seq_length
        assert cutoff_day in [1,2,3,4,5]
        if cutoff_day in [1, 2, 3, 4]:
            assert the_y.iloc[0].day_of_week.values[0] >= cutoff_day+1  # the first y is the next day or "next next" one if there was a holiday
        else:
            assert the_y.iloc[0].day_of_week.values[0] == 1
        assert the_X.iloc[-1].day_of_week.values[0] == cutoff_day
        assert the_y.iloc[0].day_of_week.values[0] != cutoff_day
        for a_df in [the_X, the_y]:
            for uu in range(0, len(a_df)):
                assert a_df.iloc[uu].day_of_week.values[0] in [1,2,3,4,5]
        _indices.append((i1, i2, i3))
    if shuffle:
        random.shuffle(_indices)
    if -1 != split_ratio:
        return _indices[:int(len(_indices)*split_ratio)], _indices[int(len(_indices)*split_ratio):], _df
    else:
        return _indices, _df


def get_all_checkpoints(_a_directory):
    return [file for file in Path(_a_directory).rglob('*.pt') if 'checkpoints' in str(file)]


def extract_info_from_filename(filename):
    """
    Extracts information from a filename.

    Args:
        filename (str): The filename to extract information from.

    Returns:
        dict: A dictionary containing the extracted information.
    """
    pattern     = r"best__(?P<metric1_name>val_accuracy|val_loss)_(?P<metric1_value>\d+\.\d+)__with__(?P<metric2_name>val_accuracy|val_loss)_(?P<metric2_value>\d+\.\d+)__at_(?P<epoch>\d+)\.pt"
    pattern_alt = r"best__(?P<metric1_name>val_accuracy)_(?P<metric1_value>\d+\.\d+)__with__(?P<metric2_name>loss|val_loss)_(?P<metric2_value>\d+\.\d+)_at_(?P<epoch>\d+)\.pt"
    match = re.match(pattern, filename)
    if match:
        return match.groupdict()
    else:
        match = re.match(pattern_alt, filename)
        if match:
            return match.groupdict()
        else:
            return None


def previous_weekday_with_check(date, df):
    # 1. On force la date en Timestamp pandas (gère les strings comme '2026-10-31')
    current_date = pd.to_datetime(date)

    # 2. On calcule le jour ouvré précédent
    yesterday = previous_weekday(current_date)

    # 3. La boucle fonctionne car 'yesterday' et 'df.index' partagent le même type
    while yesterday not in df.index:
        yesterday = previous_weekday(yesterday)

    return yesterday


def previous_weekday(date):
    previous_day = date - pd.Timedelta(1, unit='days')
    while previous_day.weekday() >= 5:  # 5 = Saturday, 6 = Sunday
        previous_day -= pd.Timedelta(1, unit='days')
    return previous_day


def next_weekday_with_check(date, df, max_look_ahead=999):
    next_day = next_weekday(date)
    count = 0
    while next_day not in df.index:
        next_day = next_weekday(next_day)
        count += 1
        if count == max_look_ahead:
            return None
    return next_day


def next_weekday(input_date, nn=1):
    _next_day = pd.to_datetime(input_date) if isinstance(input_date, str) else input_date

    # Determine the step direction (forward +1 or backward -1)
    step = -1 if nn < 0 else 1
    # Use the absolute value to ensure the loop runs correctly
    target_count = abs(nn)

    count = 0
    while count < target_count:
        _next_day += pd.Timedelta(days=step)
        # Only increment count if Mon(0) to Fri(4)
        if _next_day.weekday() < 5:
            count += 1
    return _next_day



def is_weekday(date):
    """
    Returns True if date is a weekday, False otherwise.
    """
    return date.weekday() < 5  # 5 represents Saturday, 6 represents Sunday


def is_last_weekend_of_month(date):
    # Vérifie si c'est un samedi (5) ou un dimanche (6)
    is_weekend = date.weekday() >= 5

    # Vérifie si le même jour la semaine prochaine change de mois
    _next_week = date + timedelta(days=7)
    is_last_week = _next_week.month != date.month

    return is_weekend and is_last_week


def find_next_sunday(date: datetime) -> datetime:
    """
    Finds the next Sunday given a datetime object.

    Args:
    date (datetime): The date from which to find the next Sunday.

    Returns:
    datetime: The next Sunday.
    """
    # Calculate the difference between the given date's weekday and Sunday (6)
    days_to_sunday = 6 - date.weekday()

    # If the given date is already Sunday, move to the next week
    if days_to_sunday == 0:
        days_to_sunday = 7

    # Add the calculated days to the given date
    next_sunday = date + timedelta(days=days_to_sunday)
    assert 6 == next_sunday.weekday()
    return next_sunday


def find_next_saturday(date: datetime, move_to_next_week=True) -> datetime:
    """
    Finds the next Saturday given a datetime object.

    Args:
    date (datetime): The date from which to find the next Saturday.

    Returns:
    datetime: The next Saturday.
    """
    # Calculate the difference between the given date's weekday and Saturday (5)
    days_to_saturday = 5 - date.weekday()
    if 0 == days_to_saturday and not move_to_next_week:
        return date
    # If the given date is already Saturday, move to the next week
    if days_to_saturday == 0:
        days_to_saturday = 7

    # Add the calculated days to the given date
    next_saturday = date + timedelta(days=days_to_saturday)
    assert 5 == next_saturday.weekday()
    return next_saturday


def find_previous_saturday(date: datetime) -> datetime:
    """
    Finds the previous Saturday given a datetime object.

    Args:
    date (datetime): The date from which to find the previous Saturday.

    Returns:
    datetime: The previous Saturday.
    """
    # Calculate the difference between the given date's weekday and Saturday (5)
    days_to_saturday = date.weekday() - 5

    # If the given date is already Saturday, move to the previous week
    if days_to_saturday <= 0:
        days_to_saturday = -1 * (7 + days_to_saturday)
    else:
        days_to_saturday = -1 * days_to_saturday

    # Subtract the calculated days from the given date
    previous_saturday = date + timedelta(days=days_to_saturday)
    assert 5 == previous_saturday.weekday()
    return previous_saturday


def string_to_bool(s):
    """
    Converts a string representation of a boolean to a boolean type.

    Args:
        s (str): The string representation of a boolean.

    Returns:
        bool: The boolean equivalent of the input string.

    Raises:
        ValueError: If the input string is not a valid boolean representation.
    """
    if isinstance(s, bool):
        return s
    s = s.lower()
    if s == "true":
        return True
    elif s == "false":
        return False
    else:
        raise ValueError("Invalid boolean representation")


def is_it_next_week_after_last_week_of_df(df, date):
    last_date = df.index[-1]
    assert 4 == last_date.weekday()  # always a friday
    day_next_week = last_date + pd.Timedelta(days=7)
    assert 4 == day_next_week.weekday()  # always a friday
    return (last_date <= date <= day_next_week) and date.weekday() < 5


def calculate_bollinger_bands(df, window=20, num_std=2, col_name='Close_SPY'):
    df[f'{col_name}__SMA'] = df[col_name].rolling(window).mean()
    df[f'{col_name}__std'] = df[col_name].rolling(window).std()
    df[f'{col_name}__Upper_BB'] = df[f'{col_name}__SMA'] + (df[f'{col_name}__std'] * num_std)
    df[f'{col_name}__Lower_BB'] = df[f'{col_name}__SMA'] - (df[f'{col_name}__std'] * num_std)
    df.dropna(inplace=True)
    return df


def calculate_rsi(df, window=14, col_name='Close_SPY'):
    delta = df[col_name].diff().dropna()
    up, down = delta.copy(), delta.copy()
    up[up < 0] = 0
    down[down > 0] = 0
    roll_up = up.rolling(window).mean()
    roll_down = down.rolling(window).mean().abs()
    RS = roll_up / roll_down
    RSI = 100.0 - (100.0 / (1.0 + RS))
    df[f'{col_name}__RSI'] = RSI
    df.dropna(inplace=True)
    return df


def calculate_macd(df, slow=26, fast=12, signal=9, col_name='Close_SPY'):
    ema_slow = df[col_name].ewm(span=slow, adjust=False).mean()
    ema_fast = df[col_name].ewm(span=fast, adjust=False).mean()
    df[f'{col_name}__MACD'] = ema_fast - ema_slow
    df[f'{col_name}__Signal'] = df[f'{col_name}__MACD'].ewm(span=signal, adjust=False).mean()
    return df


def format_execution_time(execution_time):
    """Format a duration in seconds into a zero-padded HHhMMmSSs string.

    Always includes hours, minutes, and seconds, padded with leading zeros
    to ensure two digits for each unit.

    Examples:
        format_execution_time(3663)  -> '01h01m03s'
        format_execution_time(61)    -> '00h01m01s'
        format_execution_time(5)     -> '00h00m05s'
        format_execution_time(0)     -> '00h00m00s'

    Args:
        execution_time (float or int): A non-negative duration in seconds.

    Returns:
        str: A zero-padded string in the format 'HHhMMmSSs'.
    """
    hours = int(execution_time // 3600)
    minutes = int((execution_time % 3600) // 60)
    seconds = int(execution_time % 60)
    mseconds = int((execution_time % 1) * 1000)
    return f"{hours:02d}h{minutes:02d}m{seconds:02d}s{mseconds:03d}ms"


def get_weekdays(today=None, number_of_days=3):
    if today is None:
        today = date.today()

    weekdays = []
    current = today
    while len(weekdays) < number_of_days:
        if current.weekday() < 5:  # Mon–Fri
            weekdays.append(current)
        current -= timedelta(days=1)
    return tuple(weekdays)


def transform_path(line, date_str):
    """
    Transforms a path assignment line by inserting a date folder before the filename.

    Args:
        line (str): Original line like 'FYAHOO__OUTPUTFILENAME_WEEK = r"D:...snapshot_week.pkl"'
        date_str (str or None): Date string in format YYYY.MM.DD (e.g., "2025.10.31")

    Returns:
        str: Transformed line with date folder inserted
    """
    # Pattern to match the assignment and capture the path parts
    return os.path.join(Path(line).parent, date_str, Path(line).name)


def format_duration(seconds):
    """Convert a duration in seconds to a compact human-readable string including milliseconds.

    Formats the input duration as a concatenation of hours, minutes, seconds, and milliseconds,
    omitting any units with zero values, except when the total duration is less
    than a minute—in that case, seconds are always shown (including '0s' for zero).
    Milliseconds are only shown if they are greater than zero.

    Examples:
        format_duration(3663.5)   -> '1h1m3s500ms'
        format_duration(61.005)   -> '1m1s5ms'
        format_duration(5)        -> '5s'
        format_duration(0.042)    -> '0s42ms'
        format_duration(0)        -> '0s'

    Args:
        seconds (float or int): A non-negative duration in seconds.

    Returns:
        str: A compact time string using 'h', 'm', 's', and 'ms' suffixes.
    """
    # 1. Extraire les millisecondes avant de tronquer les secondes
    # (int((seconds % 1) * 1000) permet de récupérer la partie décimale en ms)
    ms = int(round((seconds % 1) * 1000))

    # 2. Convertir la partie entière pour le reste du calcul
    seconds_int = int(seconds)

    hours, remainder = divmod(seconds_int, 3600)
    minutes, secs = divmod(remainder, 60)

    parts = []
    if hours:
        parts.append(f"{hours}h")
    if minutes:
        parts.append(f"{minutes}m")

    # Toujours afficher les secondes si la durée totale est < 1 min, ou si 'parts' est vide
    if secs or not parts:
        parts.append(f"{secs}s")

    # Ajouter les millisecondes uniquement si elles sont supérieures à 0
    if ms > 0:
        parts.append(f"{ms}ms")

    return ''.join(parts)


def is_monday(dt=None):
    """Return True if the given date is a Monday. If no date is given, use today."""
    if dt is None:
        dt = date.today()
    elif isinstance(dt, str):
        dt = datetime.strptime(dt, "%Y-%m-%d").date()
    return dt.weekday() == 0  # Monday is 0 in Python


def is_tuesday(dt=None):
    """Return True if the given date is a Tuesday. If no date is given, use today."""
    if dt is None:
        dt = date.today()
    elif isinstance(dt, str):
        dt = datetime.strptime(dt, "%Y-%m-%d").date()
    return dt.weekday() == 1  # Tuesday is 1


def is_wednesday(dt=None):
    """Return True if the given date is a Wednesday. If no date is given, use today."""
    if dt is None:
        dt = date.today()
    elif isinstance(dt, str):
        dt = datetime.strptime(dt, "%Y-%m-%d").date()
    return dt.weekday() == 2  # Wednesday is 2


def is_thursday(dt=None):
    """Return True if the given date is a Thursday. If no date is given, use today."""
    if dt is None:
        dt = date.today()
    elif isinstance(dt, str):
        dt = datetime.strptime(dt, "%Y-%m-%d").date()
    return dt.weekday() == 3  # Thursday is 3


def is_friday(dt=None):
    """Return True if the given date is a Friday. If no date is given, use today."""
    if dt is None:
        dt = date.today()
    elif isinstance(dt, str):
        dt = datetime.strptime(dt, "%Y-%m-%d").date()
    return dt.weekday() == 4  # Friday is 4


def get_weekday_name(dt):
    if is_friday(dt):
        return "friday"
    if is_thursday(dt):
        return "thursday"
    if is_wednesday(dt):
        return "wednesday"
    if is_tuesday(dt):
        return "tuesday"
    return "monday"


def str2bool(v):
    return string_to_bool(v)


DATASET_AVAILABLE = ['day', 'week', 'month', 'quarter', 'year']
def get_filename_for_dataset(dataset_choice, older_dataset=None):
    mapping = {
        'day': FYAHOO__OUTPUTFILENAME_DAY,
        'week': FYAHOO__OUTPUTFILENAME_WEEK,
        'month': FYAHOO__OUTPUTFILENAME_MONTH,
        'quarter': FYAHOO__OUTPUTFILENAME_QUARTER,
        'year': FYAHOO__OUTPUTFILENAME_YEAR,
    }
    if older_dataset is not None and older_dataset != '':
        return transform_path(mapping[dataset_choice], older_dataset)
    return mapping[dataset_choice]


def next_day(input_date, skip_weekends=True):
    """
    Get the next calendar day (or next weekday if skip_weekends=True).

    Args:
        input_date (str | date | datetime): Input date in "%Y-%m-%d" format or date/datetime object
        skip_weekends (bool): If True, skip Saturday/Sunday and return next Monday

    Returns:
        date: Next day as a date object
    """
    # Normalize input to date object
    if isinstance(input_date, str):
        dt = datetime.strptime(input_date, "%Y-%m-%d").date()
    elif isinstance(input_date, datetime):
        dt = input_date.date()
    else:  # date object
        dt = input_date

    next_dt = dt + timedelta(days=1)

    if skip_weekends:
        while next_dt.weekday() >= 5:  # 5=Saturday, 6=Sunday
            next_dt += timedelta(days=1)

    return next_dt


def next_week(input_date, weekday=None):
    """
    Get date for next week (same weekday by default, or specific weekday).

    Args:
        input_date (str | date | datetime): Input date
        weekday (int | None): Target weekday (0=Monday, 6=Sunday). If None, use same weekday as input.

    Returns:
        date: Date in next week
    """
    # Normalize input
    if isinstance(input_date, str):
        dt = datetime.strptime(input_date, "%Y-%m-%d").date()
    elif isinstance(input_date, datetime):
        dt = input_date.date()
    else:
        dt = input_date

    if weekday is None:
        weekday = dt.weekday()

    # Get next occurrence of target weekday (at least 1 day ahead)
    days_ahead = weekday - dt.weekday()
    if days_ahead <= 0:  # Target day already passed this week
        days_ahead += 7

    return dt + timedelta(days=days_ahead)


def next_month(input_date, day=None, preserve_month_end=True):
    """
    Get date in next month with smart day handling.

    Args:
        input_date (str | date | datetime): Input date
        day (int | None): Specific day of month (1-31). If None, use same day as input.
        preserve_month_end (bool): If True and input is last day of month, return last day of next month.

    Returns:
        date: Date in next month
    """
    # Normalize input
    if isinstance(input_date, str):
        dt = datetime.strptime(input_date, "%Y-%m-%d").date()
    elif isinstance(input_date, datetime):
        dt = input_date.date()
    else:
        dt = input_date

    # Determine target day
    if day is None:
        day = dt.day

        # Special handling for month-end dates
        if preserve_month_end:
            _, last_day = calendar.monthrange(dt.year, dt.month)
            if dt.day == last_day:
                # Input is last day of month → return last day of next month
                next_month = dt.month % 12 + 1
                next_year = dt.year + (dt.month // 12)
                _, last_day_next = calendar.monthrange(next_year, next_month)
                day = last_day_next

    # Calculate next month/year
    next_month = dt.month % 12 + 1
    next_year = dt.year + (dt.month // 12)

    # Handle invalid days (e.g., Jan 31 → Feb 31 doesn't exist)
    try:
        return date(next_year, next_month, day)
    except ValueError:
        # Fall back to last day of next month
        _, last_day = calendar.monthrange(next_year, next_month)
        return date(next_year, next_month, last_day)


from datetime import date, datetime, timedelta

from datetime import date, datetime, timedelta

def get_next_day_range(input_date=None):
    """
    Returns a formatted string showing the next week-calendar day and the date object of that day.

    Args:
        input_date (str | date | datetime | None):
            - If None: uses today's date
            - If str: expects "YYYY-MM-DD" format
            - If datetime/date: uses the given date

    Returns:
        tuple: (str, date)
            - str: "Next day is YYYY-MM-DD"
            - date: date object representing the next calendar day

    Examples:
        >>> get_next_day_range("2025-02-05")  # Wednesday
        ('Next day is 2025-02-06', datetime.date(2025, 2, 6))

        >>> get_next_day_range("2025-02-28")  # Non-leap year end of February
        ('Next day is 2025-03-01', datetime.date(2025, 3, 1))

        >>> get_next_day_range("2024-12-31")
        ('Next day is 2025-01-01', datetime.date(2025, 1, 1))

        >>> get_next_day_range(datetime(2025, 2, 16, 14, 30))  # Sunday with time
        ('Next day is 2025-02-17', datetime.date(2025, 2, 17))
    """
    # Normalize input to date object
    if input_date is None:
        dt = date.today()
    elif isinstance(input_date, str):
        dt = datetime.strptime(input_date, "%Y-%m-%d").date()
    elif isinstance(input_date, datetime):
        dt = input_date.date()
    else:  # date object
        dt = input_date

    next_day = next_weekday(dt)
    return f"Returned day is {next_day.strftime('%Y-%m-%d')}", next_day


def get_week_range(input_date=None, weeks_ahead=0):
    """
    Returns a formatted string showing the Monday-to-Friday week range
    based on the number of weeks ahead specified.

    Args:
        input_date (str | date | datetime | None):
            - If None: uses today's date
            - If str: expects "YYYY-MM-DD" format
            - If datetime/date: uses the given date
        weeks_ahead (int):
            - 0: current week
            - 1: next week (default)
            - 2+: future weeks

    Returns:
        tuple[str, date]: A message string and the Friday date object.
    """
    # Normalize input to date object
    if input_date is None:
        dt = date.today()
    elif isinstance(input_date, str):
        dt = datetime.strptime(input_date, "%Y-%m-%d").date()
    elif isinstance(input_date, datetime):
        dt = input_date.date()
    else:  # date object
        dt = input_date

    # Find Monday of current week (Monday = weekday 0)
    monday_this_week = dt - timedelta(days=dt.weekday())

    # Calculate target week's Monday and Friday based on weeks_ahead
    target_monday = monday_this_week + timedelta(weeks=weeks_ahead)
    target_friday = target_monday + timedelta(days=4)  # Monday + 4 days = Friday

    message = (f"Returned week is from {target_monday.strftime('%Y-%m-%d')} "
               f"to {target_friday.strftime('%Y-%m-%d')}")

    return message, target_friday


def get_next_week_range(input_date=None):
    return get_week_range(input_date=input_date, weeks_ahead=1)


def get_next_month_range(input_date=None):
    return get_month_range(input_date, 1)


def get_quarter_range(input_date=None, quarters_ahead=0):
    """
    Retourne une chaîne formatée et l'objet date du dernier jour pour le trimestre ciblé.

    Args:
        input_date (str | date | datetime | None):
            - Si None : utilise la date d'aujourd'hui
            - Si str : attend le format "YYYY-MM-DD"
            - Si datetime/date : utilise la date fournie
        quarters_ahead (int):
            - 0 pour le trimestre courant (par défaut)
            - 1 pour le trimestre prochain
            - l pour un trimestre plus lointain dans le futur

    Returns:
        tuple: (formatted_string, last_day_date)
    """
    # Normalisation de l'entrée vers un objet date
    if input_date is None:
        dt = date.today()
    elif isinstance(input_date, str):
        dt = datetime.strptime(input_date, "%Y-%m-%d").date()
    elif isinstance(input_date, datetime):
        dt = input_date.date()
    else:
        dt = input_date

    # Détermination du trimestre courant (0 = Q1, 1 = Q2, 2 = Q3, 3 = Q4)
    current_quarter = (dt.month - 1) // 3

    # Calcul du trimestre et de l'année cible
    total_quarters = current_quarter + quarters_ahead
    target_year = dt.year + (total_quarters // 4)
    target_quarter = total_quarters % 4

    # Déduction des mois de début et de fin du trimestre cible (1-indexed)
    start_month = (target_quarter * 3) + 1
    end_month = start_month + 2

    # Premier et dernier jour du trimestre
    first_day = date(target_year, start_month, 1)
    _, days_in_month = calendar.monthrange(target_year, end_month)
    last_day = date(target_year, end_month, days_in_month)

    formatted_string = (f"Target quarter is from {first_day.strftime('%Y-%m-%d')} "
                        f"to {last_day.strftime('%Y-%m-%d')}")

    return formatted_string, last_day


def get_year_range(input_date=None, years_ahead=0):
    """
    Retourne une chaîne formatée et l'objet date du dernier jour pour l'année ciblée.

    Args:
        input_date (str | date | datetime | None):
            - Si None : utilise la date d'aujourd'hui
            - Si str : attend le format "YYYY-MM-DD"
            - Si datetime/date : utilise la date fournie
        years_ahead (int):
            - 0 pour l'année courante (par défaut)
            - 1 pour l'année prochaine
            - l pour une année plus lointaine dans le futur

    Returns:
        tuple: (formatted_string, last_day_date)
    """
    # Normalisation de l'entrée vers un objet date
    if input_date is None:
        dt = date.today()
    elif isinstance(input_date, str):
        dt = datetime.strptime(input_date, "%Y-%m-%d").date()
    elif isinstance(input_date, datetime):
        dt = input_date.date()
    else:
        dt = input_date

    # Calcul de l'année cible
    target_year = dt.year + years_ahead

    # Premier et dernier jour de l'année
    first_day = date(target_year, 1, 1)
    last_day = date(target_year, 12, 31)

    formatted_string = (f"Target year is from {first_day.strftime('%Y-%m-%d')} "
                        f"to {last_day.strftime('%Y-%m-%d')}")

    return formatted_string, last_day


def get_month_range(input_date=None, months_ahead=0):
    """
    Retourne une chaîne formatée et l'objet date du dernier jour pour le mois ciblé.

    Args:
        input_date (str | date | datetime | None):
            - Si None : utilise la date d'aujourd'hui
            - Si str : attend le format "YYYY-MM-DD"
            - Si datetime/date : utilise la date fournie
        months_ahead (int):
            - 0 pour le mois courant (par défaut)
            - 1 pour le mois prochain
            - l pour un mois plus lointain dans le futur

    Returns:
        tuple: (formatted_string, last_day_date)
    """
    # Normalisation de l'entrée vers un objet date
    if input_date is None:
        dt = date.today()
    elif isinstance(input_date, str):
        dt = datetime.strptime(input_date, "%Y-%m-%d").date()
    elif isinstance(input_date, datetime):
        dt = input_date.date()
    else:
        dt = input_date

    # Calcul du mois et de l'année cible (gestion du débordement des années)
    # L'indexation commence à 0 pour le calcul des mois (0 = Janvier, 11 = Décembre)
    total_months = (dt.month - 1) + months_ahead
    target_year = dt.year + (total_months // 12)
    target_month = (total_months % 12) + 1

    # Le premier jour est toujours le 1er du mois
    first_day = date(target_year, target_month, 1)

    # Récupération du dernier jour du mois cible
    _, days_in_month = calendar.monthrange(target_year, target_month)
    last_day = date(target_year, target_month, days_in_month)

    formatted_string = (f"Target month is from {first_day.strftime('%Y-%m-%d')} "
                        f"to {last_day.strftime('%Y-%m-%d')}")

    return formatted_string, last_day


def add_vwap_with_bands(
        df: pd.DataFrame,
        open_col,
        high_col,
        low_col,
        close_col,
        volume_col,
        window,
        ticker,
        bands=(1, 2, 3),
        add_scretch_condition=(True, True, True),
        prefix: str = "VWAP",
        use_hlc3=False,
        add_z_score_feature=False,
):
    """
    Adds VWAP and multi-band levels to dataframe.

    Parameters
    ----------
    df : pd.DataFrame
        Input dataframe (must contain High, Low, Close, Volume columns)
    open_col ,high_col, low_col, close_col, volume_col :
        Column names (supports MultiIndex columns like ('High', 'SPY'))
    window : int or None
        None  -> cumulative VWAP
        int   -> rolling VWAP window
    bands : tuple
        Standard deviation multipliers (e.g. (1,2,3))
    prefix : str
        Prefix name for generated columns

    Returns
    -------
    pd.DataFrame
        DataFrame with VWAP and bands added
    """

    df = df.copy()

    # --- Typical Price ---
    if use_hlc3:
        tp = (df[high_col] + df[low_col] + df[close_col]) / 3.0
    else:  # ohlc/4
        tp = (df[open_col] + df[high_col] + df[low_col] + df[close_col]) / 4.0

    if window is None:
        # ===== CUMULATIVE VWAP =====
        cum_vol = df[volume_col].cumsum()
        cum_tpv = (tp * df[volume_col]).cumsum()
        cum_tp2v = ((tp ** 2) * df[volume_col]).cumsum()

        vwap = cum_tpv / cum_vol
        var = (cum_tp2v / cum_vol) - (vwap ** 2)

    else:
        # ===== ROLLING VWAP =====
        vol_sum = df[volume_col].rolling(window).sum()
        tpv_sum = (tp * df[volume_col]).rolling(window).sum()
        tp2v_sum = ((tp ** 2) * df[volume_col]).rolling(window).sum()

        vwap = tpv_sum / vol_sum
        var = (tp2v_sum / vol_sum) - (vwap ** 2)

    std = np.sqrt(var.clip(lower=0))  # avoid negative floating noise
    col_bands_lst, col_features_lst = [], []
    col_dict = {'vwap':     (f"{prefix}", ticker),
                'vwap_std': (f"{prefix}_std", ticker),
                }
    if add_z_score_feature:
        col_dict.update({'vwap_z': (f"{prefix}_z", ticker),})
    for b in bands:
        col_dict.update({f'vwap_uband_{b}'      : (f"{prefix}_upper_{b}", ticker),
                         f'vwap_lband_{b}'      : (f"{prefix}_lower_{b}", ticker),
                         f'vwap_above_sigma_{b}': (f"{prefix}_above_{b}sigma", ticker),
                         f'vwap_below_sigma_{b}': (f"{prefix}_below_{b}sigma", ticker),
                         })

    # --- Store Base VWAP ---
    df[col_dict['vwap']] = vwap
    df[col_dict['vwap_std']] = std

    # --- Multi Bands ---
    for b in bands:
        df[col_dict[f'vwap_uband_{b}']] = vwap + b * std
        df[col_dict[f'vwap_lband_{b}']] = vwap - b * std
        col_bands_lst.append(col_dict[f'vwap_uband_{b}'])
        col_bands_lst.append(col_dict[f'vwap_lband_{b}'])

    if add_z_score_feature:
        df[col_dict[f'vwap_z']] = (df[close_col] - df[col_dict['vwap']]) / df[col_dict['vwap_std']]
        col_features_lst.append(col_dict['vwap_z'])

    if add_scretch_condition:
        assert len(add_scretch_condition) == len(bands)
        for b in bands:
            df[col_dict[f'vwap_above_sigma_{b}']] = df[close_col] > df[col_dict[f'vwap_uband_{b}']]
            df[col_dict[f'vwap_below_sigma_{b}']] = df[close_col] < df[col_dict[f'vwap_lband_{b}']]

    return df.copy(), col_dict


def get_growth_function(y_min, y_max):
    """
    Returns a function that maps:
    10  -> y_min
    20  -> 1.0
    100 -> y_max
    """
    x_min, x_mid, x_max = 5, 20, 100
    y_mid = 1.0

    # Solve for curvature 'k' based on the ratio of growth
    # (y_max - y_min) / (y_mid - y_min) = ((x_max - x_min) / (x_mid - x_min))^k
    ratio_y = (y_max - y_min) / (y_mid - y_min)
    ratio_x = (x_max - x_min) / (x_mid - x_min)  # This is 90 / 10 = 9

    k = np.log(ratio_y) / np.log(ratio_x)
    C = (y_mid - y_min) / ((x_mid - x_min) ** k)

    def growth_func(x):
        # Clip x to the bounds [10, 100] to avoid errors or unexpected values
        x = np.clip(x, x_min, x_max)
        return C * (x - x_min) ** k + y_min

    return growth_func


def abrupt_growth(x, y_min=0.1, y_max=10.0, sharpness=5):
    """
    x: input (10 to 100)
    y_min: value at x=10
    y_max: value at x=100
    sharpness: higher values = flatter start, more abrupt finish
    """
    x_min, x_mid, x_max = 10, 20, 100
    y_mid = 1.0

    # Normalize x to a 0-1 scale for the math
    # 0 at x=10, ~0.11 at x=20, 1 at x=100
    norm_x = (x - x_min) / (x_max - x_min)

    # Apply exponential growth: (e^(s*x) - 1) / (e^s - 1)
    # This creates a curve that starts at 0 and ends at 1
    curve = (np.exp(sharpness * norm_x) - 1) / (np.exp(sharpness) - 1)

    # Rescale the curve to fit y_min and y_max
    # Note: This might not hit 1.0 at exactly 20 unless we solve for
    # the specific 'sharpness' that passes through (20, 1).
    return y_min + (y_max - y_min) * curve


def get_weekday_range(input_date):
    """
    Given any date, returns a tuple of (Monday, Friday) for that specific week.

    Args:
        input_date (str | date | datetime | pd.Timestamp): The date to check.

    Returns:
        tuple: (str, str) in YYYY-MM-DD format representing Monday and Friday.
    """
    # Normalize input to a datetime object
    if isinstance(input_date, str):
        dt = pd.to_datetime(input_date)
    elif isinstance(input_date, (date, datetime)):
        dt = pd.to_datetime(input_date)
    else:
        dt = input_date

    # dt.weekday() returns 0 for Monday, 4 for Friday
    monday = dt - pd.Timedelta(days=dt.weekday())
    friday = monday + pd.Timedelta(days=4)

    return (monday.strftime('%Y-%m-%d'), friday.strftime('%Y-%m-%d'))


def get_month_weekday_range(input_date):
    """
    Given any date, returns a tuple of (first_weekday, last_weekday)
    for that specific month (Mon–Fri only).

    Args:
        input_date (str | date | datetime | pd.Timestamp): The date to check.

    Returns:
        tuple: (str, str) in YYYY-MM-DD format representing
               first weekday and last weekday of the month.
    """
    # Normalize input to a datetime object
    if isinstance(input_date, str):
        dt = pd.to_datetime(input_date)
    elif isinstance(input_date, (date, datetime)):
        dt = pd.to_datetime(input_date)
    else:
        dt = input_date

    # First day of the month
    first_day = dt.replace(day=1)

    # Adjust to first weekday (Mon–Fri)
    if first_day.weekday() >= 5:  # Saturday=5, Sunday=6
        first_weekday = first_day + pd.Timedelta(days=(7 - first_day.weekday()))
    else:
        first_weekday = first_day

    # Last day of the month
    next_month = first_day + pd.offsets.MonthBegin(1)
    last_day = next_month - pd.Timedelta(days=1)

    # Adjust to last weekday (Mon–Fri)
    if last_day.weekday() >= 5:
        last_weekday = last_day - pd.Timedelta(days=(last_day.weekday() - 4))
    else:
        last_weekday = last_day

    return (
        first_weekday.strftime('%Y-%m-%d'),
        last_weekday.strftime('%Y-%m-%d')
    )


def compute_ichimoku(_df, close_col, high_col, low_col, period_tenkan_sen=9, period_kijun_sen=26, senkou_span_a=26, senkou_span_b=52, chikou_span=26):
    """
    Returns:
        df with Ichimoku columns added
    """

    high = _df[high_col]
    low = _df[low_col]
    close = _df[close_col]

    # Tenkan-sen (9)
    tenkan_high = high.rolling(window=period_tenkan_sen).max()
    tenkan_low = low.rolling(window=period_tenkan_sen).min()
    _df['tenkan_sen'] = (tenkan_high + tenkan_low) / 2

    # Kijun-sen (26)
    kijun_high = high.rolling(window=period_kijun_sen).max()
    kijun_low = low.rolling(window=period_kijun_sen).min()
    _df['kijun_sen'] = (kijun_high + kijun_low) / 2

    # Senkou Span A (shifted forward 26)
    _df['senkou_span_a'] = ((_df['tenkan_sen'] + _df['kijun_sen']) / 2).shift(senkou_span_a)

    # Senkou Span B (52, shifted forward 26)
    span_b_high = high.rolling(window=senkou_span_b).max()
    span_b_low = low.rolling(window=senkou_span_b).min()
    _df['senkou_span_b'] = ((span_b_high + span_b_low) / 2).shift(senkou_span_b//2)

    # Chikou Span (lagging)
    _df['chikou_span'] = close.shift(-chikou_span)

    return _df


def generate_ichimoku_signals(_df, close_col):
    _df = _df.copy()

    # Trend filter
    _df['above_cloud'] = (
            (_df[close_col] > _df['senkou_span_a']) &
            (_df[close_col] > _df['senkou_span_b'])
    )

    _df['below_cloud'] = (
            (_df[close_col] < _df['senkou_span_a']) &
            (_df[close_col] < _df['senkou_span_b'])
    )

    # Tenkan / Kijun crossover
    _df['tk_cross'] = np.where(_df['tenkan_sen'] > _df['kijun_sen'], 1, -1)

    _df['tk_cross_signal'] = _df['tk_cross'].diff()

    # +2 → bullish cross, -2 → bearish cross
    _df['long_signal'] = (
            (_df['tk_cross_signal'] == 2) &
            (_df['above_cloud'])
    )

    _df['short_signal'] = (
            (_df['tk_cross_signal'] == -2) &
            (_df['below_cloud'])
    )

    return _df


def get_next_step(the_date, dataset_id, nn):
    if 'day' == dataset_id:
        _next_ = next_weekday(the_date, nn)
    elif 'week' == dataset_id:
        assert nn > 0
        _next_ = next_week(the_date)
        for u in range(1, nn):
            _next_ = next_week(_next_)
    elif 'month' == dataset_id:
        assert nn > 0
        _next_ = next_month(the_date)
        for u in range(1, nn):
            _next_ = next_month(_next_)  # Fixed: was incorrectly calling next_week
    elif 'quarter' == dataset_id:
        assert nn > 0
        # Advance by 3 months per quarter step
        _next_ = the_date
        for u in range(3 * nn):
            _next_ = next_month(_next_)
    elif 'year' == dataset_id:
        assert nn > 0
        # Advance by 12 months per year step (for completeness, since 'year' is in DATASET_AVAILABLE)
        _next_ = the_date
        for u in range(12 * nn):
            _next_ = next_month(_next_)
    elif dataset_id.startswith('intraday'):
        assert nn > 0
        # Extrait le nombre de minutes (ex: '5min' -> 5)
        def _get_dataset_timeframe(_dataset_id):
            try:
                if _dataset_id.startswith("intraday"):
                    try:
                        _n_minutes = int(_dataset_id.split("_")[1][:-3])
                        return _n_minutes
                    except:
                        _n_minutes = int(_dataset_id.split("-")[1][:-3])
                        return _n_minutes
                elif _dataset_id.startswith("extraday"):
                    try:
                        _n_days = int(re.search(r'\d+', _dataset_id.split("_")[1]).group())
                        return _n_days
                    except:
                        _n_days = int(re.search(r'\d+', _dataset_id.split("-")[1]).group())
                        return _n_days
                return None
            except:
                return None
        tick_minutes = _get_dataset_timeframe(dataset_id)
        assert tick_minutes is not None
        # Ajoute le nombre de minutes multiplié par l'étape nn
        _next_ = the_date + timedelta(minutes=tick_minutes * nn)
    elif dataset_id.startswith('extraday'):
        assert nn > 0
        n_days = get_dataset_timeframe(_dataset_id=dataset_id)
        _next_ = next_weekday(the_date, n_days)
    else:
        assert False, f"Implement for {dataset_id}"
    return _next_


def get_dataset_timeframe(_dataset_id):
    try:
        if _dataset_id.startswith("intraday"):
            try:
                _n_minutes = int(_dataset_id.split("_")[1][:-3])
                return _n_minutes
            except:
                try:
                    _n_minutes = int(_dataset_id.split("-")[1][:-3])
                    return _n_minutes
                except:
                    return 1  # Par defaut
        elif _dataset_id.startswith("extraday"):
            try:
                _n_days = int(re.search(r'\d+', _dataset_id.split("_")[1]).group())
                return _n_days
            except:
                _n_days = int(re.search(r'\d+', _dataset_id.split("-")[1]).group())
                return _n_days
        return None
    except:
        return None


def send_html_email(destinataires, sujet, corps, cc=None, cci=None, pieces_jointes=None, add_clause_non_responsabilite=True):
    # Assurer que les arguments sont des listes
    dest_list = [destinataires] if isinstance(destinataires, str) else (destinataires or [])
    cc_list = [cc] if isinstance(cc, str) else (cc or [])
    cci_list = [cci] if isinstance(cci, str) else (cci or [])
    expediteur = EMAIL_SENDER_WEBEAR
    mot_de_passe_app = PWD_GOOGLE_API
    _send_email(
        expediteur=expediteur,
        destinataires=dest_list,
        cc=cc_list,
        cci=cci_list,
        sujet=sujet,
        corps=ansi_to_html(f"{corps}\n\n\n{CLAUSE_NON_RESPONSABILITE}") if add_clause_non_responsabilite else ansi_to_html(corps),
        mot_de_passe_app=mot_de_passe_app,
        subtype='html',
        pieces_jointes=pieces_jointes
    )


def _send_email(
        expediteur,
        destinataires,
        cc,
        cci,
        sujet,
        corps,
        mot_de_passe_app,
        serveur_smtp="smtp.gmail.com",
        port_smtp=587,
        subtype='plain',
        pieces_jointes=None
):
    if not IS_RUNNING_HOME_SWEET_HOME:
        return
    # Construire le message
    msg = MIMEMultipart()
    msg['From'] = expediteur
    msg['To'] = ", ".join(destinataires)

    if cc:
        msg['Cc'] = ", ".join(cc)

    # Note : On n'ajoute JAMAIS les 'Cci' dans msg['Bcc'] pour des raisons de confidentialité.

    msg['Subject'] = sujet
    msg.attach(MIMEText(corps, subtype))

    # Gestion des pièces jointes
    if pieces_jointes:
        try:
            if not isinstance(pieces_jointes, list|tuple):
                pieces_jointes = [pieces_jointes]
            for fichier in pieces_jointes:
                if os.path.isfile(fichier):
                    mime_type, _ = mimetypes.guess_type(fichier)
                    if mime_type is None:
                        mime_type = 'application/octet-stream'

                    main_type, sub_type = mime_type.split('/', 1)

                    with open(fichier, 'rb') as f:
                        part = MIMEBase(main_type, sub_type)
                        part.set_payload(f.read())

                    encoders.encode_base64(part)
                    nom_fichier = os.path.basename(fichier)
                    part.add_header('Content-Disposition', f'attachment; filename="{nom_fichier}"')
                    msg.attach(part)
                else:
                    print(f"Attention : Le fichier '{fichier}' n'existe pas et sera ignoré.")
        except:
            pass

    # Liste unique de TOUS les serveurs de réception finaux (To + Cc + Cci)
    tous_les_destinataires = list(set(list(destinataires) + list(cc) + list(cci)))

    # Serveur SMTP
    server = smtplib.SMTP(serveur_smtp, port_smtp)
    server.starttls()
    server.login(expediteur, mot_de_passe_app)

    # Envoyer le courriel
    texte = msg.as_string()
    server.sendmail(expediteur, tous_les_destinataires, texte)
    server.quit()


def ansi_to_html(text):
    text = re.sub(r'\x1b\[0m|\[0m', '</b>', text)
    text = re.sub(r'\x1b\[1m|\[1m', '<b>', text)
    html_output = f"<pre style='font-family: monospace; font-size: 14px;'>{text}</pre>"
    return html_output


def calculate_rsi(df, ticker, close_col, period=14):
    """
    Calcule le RSI pour un ticker spécifique dans un DataFrame multi-index.
    """
    # 1. Calcul des variations de prix d'une bougie à l'autre
    delta = df[close_col].diff()

    # 2. Séparation des gains (positifs) et des pertes (négatives)
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)

    # 3. Calcul de la moyenne mobile exponentielle lissée (Wilder's MMA)
    # Note : alpha = 1 / period correspond exactement à la méthode de l'inventeur J. Welles Wilder
    avg_gain = gain.ewm(alpha=1 / period, min_periods=period, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1 / period, min_periods=period, adjust=False).mean()

    # 4. Calcul du Relative Strength (RS)
    rs = avg_gain / avg_loss

    # 5. Calcul du RSI normalisé entre 0 et 100
    rsi = 100 - (100 / (1 + rs))

    # Optionnel : Gestion des divisions par zéro si avg_loss est égal à 0
    rsi = rsi.replace([np.inf, -np.inf], 100)
    new_col=(f'RSI_{period}', ticker)
    df[new_col] = rsi
    return df, new_col


def get_taurus_v1_models():
    # (PY312_HT) PS D:\PyCharmProjects\webear\src\optimizers\oerh> python .\player_with_backtesting.py --n-back 10000 --models-dir D:\Finance\compiled_models\taurus\v1\2026.08.20\optimizers\oerh\models
    #
    # 🌍 STATS GLOBALES :
    #   • Dataset     : day
    #   • Ticker      : ^GSPC
    #   • Dates       : 2026-09-04_0000 :: 1986-12-24_0000
    # Clips: 100%|██████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| 10000/10000 [11:49<00:00, 14.09it/s]
    #
    # ==================================================
    # ====== STATISTIQUES FINALES DE COMPILATION =======
    # ==================================================
    #
    # 📊 STATS PAR MODÈLE :
    #   • oerh__mlong_accuracy__la12__th-0.02000__ttany_half_B__twr0.9529__sd0.2469__dsday__cdb1__^GSPC__20260905_183245 -> Total: 944  | Density: 9.44% | WR: 96.61%
    #   • oerh__mlong_accuracy__la5__th-0.01000__ttany_half_B__twr0.9192__sd0.1230__dsday__cdb2__^GSPC__20260821_091918 -> Total: 1093 | Density: 10.93% | WR: 93.41%
    #   • oerh__mlong_accuracy__la5__th-0.01000__ttany_half_B__twr0.9394__sd0.0849__dsday__cdb5__^GSPC__20260820_113002 -> Total: 752  | Density: 7.52% | WR: 92.69%
    #
    result= {"oerh": {"mom": {"name": "mom", "version": 1,
                             "filepath": os.path.join(TAURUS_V1_BASE_DIRECTORY, r"2026.08.20\optimizers\oerh\models", "oerh__mlong_accuracy__la12__th-0.02000__ttany_half_B__twr0.9529__sd0.2469__dsday__cdb1__^GSPC__20260905_183245.pkl"),
                             },
                     "rip": {"name": "rip", "version": 1,
                             "filepath": os.path.join(TAURUS_V1_BASE_DIRECTORY, r"2026.08.20\optimizers\oerh\models", "oerh__mlong_accuracy__la5__th-0.01000__ttany_half_B__twr0.9192__sd0.1230__dsday__cdb2__^GSPC__20260821_091918.pkl"),
                             },
                     "fox": {"name": "fox", "version": 1,
                             "filepath": os.path.join(TAURUS_V1_BASE_DIRECTORY, r"2026.08.20\optimizers\oerh\models", "oerh__mlong_accuracy__la5__th-0.01000__ttany_half_B__twr0.9394__sd0.0849__dsday__cdb5__^GSPC__20260820_113002.pkl"),
                             },
                     },
             "autotune": {"rainbow": {"name": 'rainbow', "version": 1, "filepath": os.path.join(TAURUS_V1_BASE_DIRECTORY, r"2026.08.20\optimizers\autotune\models", "autotune__la10__opfinish_above__wth-0.0__trainsc0.5694__trainwr0.5996__twr0.6211.pkl"),},
                         },
             "apcs": {},
             "dgdr": {},
            }
    for a_file in os.listdir(os.path.join(TAURUS_V1_BASE_DIRECTORY, r"2026.08.20\optimizers\autotune\models")):
        model_name = Path(a_file).stem
        result['autotune'][model_name] = {"name": model_name, "version": 1, "filepath": os.path.join(TAURUS_V1_BASE_DIRECTORY, r"2026.08.20\optimizers\autotune\models", a_file),}
    for a_file in os.listdir(os.path.join(TAURUS_V1_BASE_DIRECTORY, r"2026.08.20\optimizers\apcs\models")):
        model_name = Path(a_file).stem
        result['apcs'][model_name] = {"name": model_name, "version": 1, "filepath": os.path.join(TAURUS_V1_BASE_DIRECTORY, r"2026.08.20\optimizers\apcs\models", a_file),}
    for a_file in os.listdir(os.path.join(TAURUS_V1_BASE_DIRECTORY, r"2026.08.20\optimizers\dgdr\models")):
        model_name = Path(a_file).stem
        result['dgdr'][model_name] = {"name": model_name, "version": 1, "filepath": os.path.join(TAURUS_V1_BASE_DIRECTORY, r"2026.08.20\optimizers\dgdr\models", a_file),}
    return result


def get_taurus_v2_models():
    result= {"oerh": {},
             "autotune": {},
             "apcs": {},
             "dgdr": {},
            }
    autotune_dir = os.path.join(TAURUS_V2_BASE_DIRECTORY, r"autotune")
    if os.path.isdir(autotune_dir):
        for a_file in os.listdir(autotune_dir):
            model_name = Path(a_file).stem
            result['autotune'][model_name] = {"name": model_name, "version": 1,
                                              "filepath": os.path.join(autotune_dir, a_file),}

    oerh_dir = os.path.join(TAURUS_V2_BASE_DIRECTORY, r"oerh")
    if os.path.isdir(oerh_dir):
        for a_file in os.listdir(oerh_dir):
            model_name = Path(a_file).stem
            result['oerh'][model_name] = {"name": model_name, "version": 1,
                                          "filepath": os.path.join(oerh_dir, a_file),}

    apcs_dir = os.path.join(TAURUS_V2_BASE_DIRECTORY, r"apcs")
    if os.path.isdir(apcs_dir):
        for a_file in os.listdir(apcs_dir):
            model_name = Path(a_file).stem
            result['apcs'][model_name] = {"name": model_name, "version": 1,
                                          "filepath": os.path.join(apcs_dir, a_file),}

    dgdr_dir = os.path.join(TAURUS_V2_BASE_DIRECTORY, r"dgdr")
    if os.path.isdir(apcs_dir):
        for a_file in os.listdir(apcs_dir):
            model_name = Path(a_file).stem
            result['dgdr'][model_name] = {"name": model_name, "version": 1,
                                          "filepath": os.path.join(apcs_dir, a_file),}
    return result


def round_price_for_put_credit_spread(price):
    return float(math.floor(price / 5) * 5)  # Put section: round down to nearest 5


def round_price_for_call_credit_spread(price):
    return float(math.ceil(price / 5) * 5)  # Call section: round up to nearest 5


def compute_break_even_credit(win_rate, spread_width):
    # Core Math
    loss_rate = 1.0 - win_rate
    breakeven_credit = loss_rate * spread_width
    return breakeven_credit


def minutes_jusqua_16h() -> int:
    maintenant = datetime.now()
    minutes_actuelles = maintenant.hour * 60 + maintenant.minute
    minutes_cible = 16 * 60
    restant = minutes_cible - minutes_actuelles
    return max(0, restant)


def is_market_open(current_dt=None):
    # Par défaut, prend l'heure actuelle à New York (heure des marchés US)
    if current_dt is None:
        current_dt = datetime.now(ZoneInfo("America/New_York"))

    # 1. Vérifier le jour de la semaine (0 = Lundi, ..., 4 = Vendredi, 5 = Samedi, 6 = Dimanche)
    est_jour_semaine = current_dt.weekday() < 5

    # 2. Vérifier l'heure (entre 09:30 et 16:00 inclusivement)
    heure_actuelle = current_dt.time()
    est_heure_ouverture = dt_time(9, 30) <= heure_actuelle <= dt_time(16, 0)

    return est_jour_semaine and est_heure_ouverture