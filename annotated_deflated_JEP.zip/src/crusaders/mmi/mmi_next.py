try:
    from version import sys__name, sys__version
except ImportError:
    import sys
    import pathlib

    current_dir = pathlib.Path(__file__).resolve()
    parent_dir = current_dir.parent.parent.parent
    sys.path.insert(0, str(parent_dir))
    from version import sys__name, sys__version

from datetime import datetime, timedelta
from runners.MMI_realtime import main as MMI_realtime
from utils import get_weekday_name, next_weekday


def main(configuration, lookahead=1):
    result = MMI_realtime(configuration)
    prediction_date = None
    if configuration.dataset_id == "day":
        prediction_date = result['date'].strftime('%Y-%m-%d')
        for _ in range(lookahead):
            prediction_date = next_weekday(datetime.strptime(prediction_date, "%Y-%m-%d")).strftime('%Y-%m-%d')
    elif configuration.dataset_id == "week":
        assert lookahead==1
        prediction_date = (result['date'] + timedelta(weeks=1)).strftime('%Y-%m-%d')
    elif configuration.dataset_id == "month":
        assert lookahead == 1
        prediction_date = (result['date'] + timedelta(weeks=4)).strftime('%Y-%m-%d')
    else:
        assert False
    if result['signal'] == "Choppy":
        lower, upper = result['prices_threshold'][0], result['prices_threshold'][1]
        result["date_prediction_step"] = prediction_date
        if configuration.verbose:
            if configuration.dataset_id == "day":
                print(f"Last date in data frame: {result['date'].strftime('%Y-%m-%d')}  ({get_weekday_name(result['date'])})      Price of last time step: {result['prices']:0.0f}")
            else:
                print(f"Last date in data frame: {result['date'].strftime('%Y-%m-%d')}   Price of last time step: {result['prices']:0.0f}")
            print(f"[{result['signal']}] For the closing price on {prediction_date}, price should be between {lower:0.0f} and {upper:0.0f}.")
    else:
        print("TODO")
        print(f"[{result['signal']}]")
    return result

