try:
    from version import sys__name, sys__version
except ImportError:
    import sys
    import pathlib

    current_dir = pathlib.Path(__file__).resolve()
    parent_dir = current_dir.parent.parent.parent
    sys.path.insert(0, str(parent_dir))
    from version import sys__name, sys__version
import argparse
from argparse import Namespace
from utils import get_filename_for_dataset, DATASET_AVAILABLE, str2bool
import copy
import numpy as np
from datetime import datetime, timedelta
from crusaders.mmi.mmi_next import main as MMI_next


# (PY312_HT) D:\PyCharmProjects\webear\src\runners>python MMI_hyperparameter_search_optuna.py --n_trials=5000 --step_back_range=10000 --return_threshold_min=0.015 --return_threshold_max=0.015 --lookahead_min=1 --lookahead_max=1 --dataset_id=day
    # 🔧 Arguments:
    #     ticker.................................. ^GSPC
    #     col..................................... Close
    #     dataset_id.............................. day
    #     step_back_range......................... 10000
    #     n_trials................................ 5000
    #     return_threshold_min.................... 0.015
    #     return_threshold_max.................... 0.015
    #     mmi_trend_max_min....................... 1
    #     mmi_trend_max_max....................... 500
    #     mmi_period_min.......................... 1
    #     mmi_period_max.......................... 500
    #     sma_period_min.......................... 1
    #     sma_period_max.......................... 500
    #     lookahead_min........................... 1
    #     lookahead_max........................... 1
    # --------------------------------------------------------------------------------
    # Best trial: 2. Best value: 0.8711: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| 5000/5000 [102:48:05<00:00, 74.02s/it]
    #
    # ===== BEST PARAMETERS =====
    # {'LOOKAHEAD': 1, 'RETURN_THRESHOLD': 0.015, 'MMI_TREND_MAX': 26, 'MMI_PERIOD': 456, 'SMA_PERIOD': 347}
    # Best Score: 0.87110000
CONFIGURATION_FOR_MMI_NEXT_DAY = Namespace(
        dataset_id="day", older_dataset=None,
        mmi_period=456,
        mmi_trend_max=26,
        sma_period=347,
        return_threshold=0.015,
        use_ema=False,
        verbose=False,
        filter_open_gaps=False,
    )


def main(args):
    if args.verbose:
        print("\n" + "=" * 80)
        print(f"Historical performance of 87.11% (overall accuracy)")
        print("=" * 80)
    config_dict = vars(CONFIGURATION_FOR_MMI_NEXT_DAY)
    config_dict.update({'ticker': args.ticker,'col': args.col,'verbose': args.verbose, 'keep_last_step': args.keep_last_step,})
    configuration = Namespace(**config_dict)
    return MMI_next(configuration)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="")
    parser.add_argument("--ticker", type=str, default='^GSPC')
    parser.add_argument("--col", type=str, default='Close')
    parser.add_argument('--keep_last_step', type=str2bool, default=True)
    parser.add_argument('--verbose', type=str2bool, default=True)
    args = parser.parse_args()
    main(args)
