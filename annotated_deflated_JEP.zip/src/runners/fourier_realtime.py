try:
    from version import sys__name, sys__version
except:
    import sys
    import os
    import pathlib

    # Get the current working directory
    current_dir = pathlib.Path(__file__).resolve()
    parent_dir = current_dir.parent.parent
    # print(parent_dir)
    # Add the current directory to sys.path
    sys.path.insert(0, str(parent_dir))
    from version import sys__name, sys__version
from optimizers.fourier_decomposition import entry as entry_of__fourier_decomposition
import pickle
import copy
from constants import FYAHOO__OUTPUTFILENAME_WEEK, OUTPUT_DIR_FOURIER_BASED_STOCK_FORECAST
import numpy as np
import matplotlib.pyplot as plt
from multiprocessing import freeze_support
from datetime import datetime
import argparse
import json
import os
from utils import str2bool, transform_path, get_filename_for_dataset
import copy


def get_prediction_for_the_future_with_fourier_algo(_best_setup, _length_prediction, _data_cache=None, _col=None, _ticker=None, prices=None):
    if prices is None:
        assert _data_cache is not None and _col is not None and _ticker is not None
        tmp_df = _data_cache[_ticker]
        tmp_df = tmp_df.sort_index()
        prices = copy.deepcopy(tmp_df[(_col, _ticker)].values.astype(np.float64))
    else:
        assert _data_cache is None and _col is None and _ticker is None
        prices = copy.deepcopy(prices)
    length_train_data = _best_setup['length_train_data']
    length_step_back = 0
    n_pred = _length_prediction
    energy_threshold = _best_setup['energy_threshold']
    the_algo = _best_setup['the_algo']

    import algorithms.fourier
    the_function = getattr(algorithms.fourier, the_algo)

    assert len(prices) > length_train_data + length_step_back + n_pred
    x_series = prices[len(prices) - length_train_data - length_step_back:]
    assert len(x_series) == length_train_data
    y_series = prices[len(prices) - length_step_back:len(prices) - length_step_back + n_pred]
    assert len(y_series) == 0  # because length_step_back=0

    forecast, lower, upper, diag = the_function(x_series, n_predict=n_pred, energy_threshold=energy_threshold, conf_level=0.95)

    prediction = forecast[-n_pred:].copy()
    assert len(prediction) == n_pred
    if lower is not None:
        assert len(upper) == n_pred
        assert len(lower) == n_pred
    x = forecast[:-n_pred].copy()
    assert len(x) == length_train_data
    # prediction: prediction
    # x_series: ground truth data
    # x: prediction on "x_series"
    assert x.shape == x_series.shape
    return prediction, x_series, lower, upper, x


def main(args):
    older_dataset = None if args.older_dataset == "None" else args.older_dataset
    one_dataset_filename = get_filename_for_dataset(dataset_choice=args.dataset_id, older_dataset=older_dataset)
    close_results, _, all_results = entry_of__fourier_decomposition(
        multi_threaded=True,
        ticker=args.ticker,
        col=args.col,
        fast_result=False,
        length_step_back=args.length_step_back,
        one_dataset_filename=one_dataset_filename,
        one_dataset_id=args.dataset_id,
        selected_algo=[int(num) for num in args.algorithms_to_run.split(",")],
        use_this_df=args.use_this_df,
        print_result=not args.quiet,
    )

    # Get base historical series from the top forecast
    all_sorted = list(all_results.values())
    if len(all_sorted) == 0:
        raise ValueError("No results found in all_results.")
    if args.n_forecasts > len(all_sorted):
        print(f"Warning: requested {args.n_forecasts} forecasts, but only {len(all_sorted)} available. Using all.")
        n_forecasts = len(all_sorted)
        assert False, "use n_forecasts"

    first_best = all_sorted[0]

    if args.use_this_df is None or 0 == len(args.use_this_df):
        # Load full data_cache from file (needed for get_prediction_for_the_future)
        with open(one_dataset_filename, 'rb') as f:
            data_cache = pickle.load(f)

        _, base_close_values, _, _, _ = get_prediction_for_the_future_with_fourier_algo(
            _best_setup=first_best,
            _data_cache=copy.deepcopy(data_cache),
            _col=args.col,
            _length_prediction=args.length_prediction_for_the_future,
            _ticker=args.ticker
        )
    else:
        _, base_close_values, _, _, _ = get_prediction_for_the_future_with_fourier_algo(
            _best_setup=first_best,
            _length_prediction=args.length_prediction_for_the_future,
            prices = args.use_this_df[(args.col, args.ticker)].values.astype(np.float64)
        )

    # Generate N forecasts
    forecasts = []
    pred_indices = None

    for i in range(args.n_forecasts):
        setup = all_sorted[i]
        if args.use_this_df is None or 0 == len(args.use_this_df):
            pred, _, _, _, _ = get_prediction_for_the_future_with_fourier_algo(
                _best_setup=setup,
                _data_cache=copy.deepcopy(data_cache),
                _col=args.col,
                _length_prediction=args.length_prediction_for_the_future,
                _ticker=args.ticker
            )
        else:
            pred, _, _, _, _ = get_prediction_for_the_future_with_fourier_algo(
                _best_setup=setup,
                _length_prediction=args.length_prediction_for_the_future,
                prices=args.use_this_df[(args.col, args.ticker)].values.astype(np.float64)
            )
        forecasts.append(pred)
        if pred_indices is None:
            pred_indices = np.arange(len(base_close_values), len(base_close_values) + len(pred))

    forecasts = np.array(forecasts)  # Shape: (n_forecasts, n_pred)

    # Compute args.q_min_filter and args.q_max_filter% percentiles for each time step (along axis=0)
    lower = np.percentile(forecasts, args.q_min_filter, axis=0, keepdims=True)  # Shape: (1, n_pred)
    upper = np.percentile(forecasts, args.q_max_filter, axis=0, keepdims=True)  # Shape: (1, n_pred)

    # Mask values outside the [args.q_min_filter, args.q_max_filter] range
    masked_forecasts = np.where((forecasts >= lower) & (forecasts <= upper), forecasts, np.nan)
    assert masked_forecasts.shape == forecasts.shape
    # Compute mean ignoring NaNs
    mean_forecast = np.nanmean(masked_forecasts, axis=0)

    assert len(mean_forecast) == args.length_prediction_for_the_future
    # forecasts = np.array(forecasts)  # Shape: (n_forecasts, n_pred)
    # mean_forecast = np.mean(forecasts, axis=0)
    assert len(mean_forecast) == args.length_prediction_for_the_future
    if not args.quiet:
        print(f"{mean_forecast.astype(int)=}")
    if args.plot_graph:
        # --- Plotting ---
        fig, ax = plt.subplots(figsize=(16, 9))

        # Historical data
        n_train_plot = min(30, len(base_close_values))
        start_idx = len(base_close_values) - n_train_plot
        train_idx = np.arange(start_idx, len(base_close_values))
        hist_vals = base_close_values[start_idx:]

        ax.plot(train_idx, hist_vals, label='Historical Close', color='black',
                marker='o', markersize=6, linewidth=2, zorder=10)

        # Individual forecasts (faint)
        for f in forecasts:
            ax.plot(pred_indices, f, color='red', linestyle='--', linewidth=1, alpha=0.4)

        # Mean tendency (bold)
        ax.plot(pred_indices, mean_forecast, color='blue', linestyle='-', linewidth=3,
                marker='o', markersize=7, label=f'Mean Forecast (n={args.n_forecasts})', zorder=20)

        # Vertical separator
        ax.axvline(x=len(base_close_values) - 0.5, color='gray', linestyle='--',
                   linewidth=2, label='Train / Prediction Boundary')

        # Y-limits
        all_ys = np.concatenate([hist_vals, mean_forecast, forecasts.flatten()])
        y_margin = (all_ys.max() - all_ys.min()) * 0.03
        ax.set_ylim(all_ys.min() - y_margin, all_ys.max() + y_margin)

        # Labels
        ax.set_title(f'Fourier Real Time - Mean Tendency of Top {args.n_forecasts} Forecasts for {args.ticker} ({args.dataset_id})', fontsize=16)
        ax.set_xlabel('Time Index (Relative)')
        ax.set_ylabel('Close Price')
        ax.grid(True, linestyle='--', alpha=0.6)
        ax.legend()

        # --- Slope annotation ---
        if len(mean_forecast) > 1:
            slope = (mean_forecast[-1] - mean_forecast[0]) / (len(mean_forecast) - 1)
            total_change = mean_forecast[-1] - mean_forecast[0]
            slope_text = (
                f"Slope per step: {slope:+.4f}\n"
                f"Total Δ over {len(mean_forecast)} steps: {total_change:+.4f}"
            )
            # print(f"\n{slope_text}")
            # Place nicely on the plot (bottom-left, inside a box)
            ax.text(
                0.02, 0.02, slope_text,
                transform=fig.transFigure,
                fontsize=11,
                ha='left', va='bottom',
                bbox=dict(facecolor='white', alpha=0.85, edgecolor='navy', boxstyle='round,pad=0.4')
            )
        else:
            msg = "Prediction horizon = 1 → slope undefined"
            # print(f"\n{msg}")
            ax.text(
                0.02, 0.02, msg,
                transform=fig.transFigure,
                fontsize=11,
                ha='left', va='bottom',
                bbox=dict(facecolor='white', alpha=0.85, edgecolor='gray', boxstyle='round,pad=0.4')
            )

        plt.tight_layout()

        # Save and show AFTER adding text
        if older_dataset is not None:
            today_str = datetime.today().strftime('%Y-%m-%d')
            os.makedirs(os.path.join(OUTPUT_DIR_FOURIER_BASED_STOCK_FORECAST, args.older_dataset), exist_ok=True)
            figure_filename = os.path.join(OUTPUT_DIR_FOURIER_BASED_STOCK_FORECAST, args.older_dataset, f"forecast_mean_slope_{args.ticker}_{args.dataset_id}__.png")
            plt.savefig(figure_filename, dpi=300, bbox_inches='tight')
        plt.show()
    return forecasts, mean_forecast


if __name__ == "__main__":
    freeze_support()
    parser = argparse.ArgumentParser(description="Run Fourier-based stock forecast.")
    parser.add_argument("--ticker", type=str, default='^GSPC')
    parser.add_argument("--col", type=str, default='Close')
    parser.add_argument("--older_dataset", type=str, default="")
    parser.add_argument("--dataset_id", type=str, default='month')
    parser.add_argument("--length_step_back", type=int, default=4)
    parser.add_argument("--length_prediction_for_the_future", type=int, default=4)
    parser.add_argument("--algorithms_to_run", type=str, default="0,1,2")
    parser.add_argument("--n_forecasts", type=int, default=19)
    parser.add_argument("--q_min_filter", type=int, default=3)
    parser.add_argument("--q_max_filter", type=int, default=97)
    parser.add_argument("--use_this_df", type=json.loads, default={})
    parser.add_argument("--plot_graph", type=str2bool, default=True)
    parser.add_argument("--quiet", type=str2bool, default=False)
    args = parser.parse_args()
    # --- Nicely print the arguments ---
    print("🔧 Arguments:")
    for arg, value in vars(args).items():
        if 'use_this_df' in arg:
            print(f"    {arg:.<40} ...")
            continue
        print(f"    {arg:.<40} {value}")
    print("-" * 80, flush=True)
    main(args)